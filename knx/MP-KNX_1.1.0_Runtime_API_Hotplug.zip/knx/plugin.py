"""KNX routes.

These routes delegate to the app core handlers during the migration.
"""

from datetime import datetime

from flask import Blueprint, current_app, jsonify, redirect, request
from dataclasses import dataclass, field
from typing import ClassVar, Any
from app.services.object_adapter_engine import BaseAdapter

@dataclass
class KNXAdapter(BaseAdapter):
    protocol: ClassVar[str] = "knx"
    group_address: str = ""
    dpt: str = ""
    source_enabled: bool = False
    source_group_address: str = ""
    source_dpt: str = ""
    targets: list[dict[str, Any]] = field(default_factory=list)

    @classmethod
    def deserialize(cls, data: dict[str, Any]) -> "KNXAdapter":
        payload=dict(data or {})
        direction=str(payload.get("direction","both") or "both").strip().lower()
        legacy_ga=str(payload.get("group_address") or "").strip(); legacy_dpt=str(payload.get("dpt") or "").strip()
        if "source_enabled" not in payload:
            payload["source_enabled"] = direction in {"in","both"} and bool(legacy_ga)
        payload["source_group_address"] = str(payload.get("source_group_address") or (legacy_ga if payload.get("source_enabled") else "")).strip()
        payload["source_dpt"] = str(payload.get("source_dpt") or (legacy_dpt if payload.get("source_enabled") else "")).strip()
        raw=payload.get("targets") if isinstance(payload.get("targets"),list) else []
        targets=[]
        for i,target in enumerate(raw):
            if not isinstance(target,dict): continue
            ga=str(target.get("group_address") or target.get("ga") or "").strip(); dpt=str(target.get("dpt") or "").strip()
            if not ga or not dpt: continue
            targets.append({"id":str(target.get("id") or f"knx_target_{i+1}"),"enabled":bool(target.get("enabled",True)),"group_address":ga,"dpt":dpt,
                            "value_path":str(target.get("value_path") or target.get("target_value_path") or "").strip()})
        if not targets and legacy_ga and legacy_dpt and direction in {"out","both"}:
            targets.append({"id":"knx_target_1","enabled":bool(payload.get("enabled",True)),"group_address":legacy_ga,"dpt":legacy_dpt,
                            "value_path":str(payload.get("target_value_path") or "").strip()})
        payload["targets"]=targets
        if payload.get("source_enabled"):
            payload["group_address"]=payload["source_group_address"]; payload["dpt"]=payload["source_dpt"]
        elif targets:
            payload["group_address"]=targets[0]["group_address"]; payload["dpt"]=targets[0]["dpt"]
        adapter=super().deserialize(payload)
        has_enabled_targets=any(bool(t.get("enabled")) for t in adapter.targets)
        adapter.enabled=bool(adapter.source_enabled or has_enabled_targets)
        adapter.direction="both" if adapter.source_enabled and has_enabled_targets else ("in" if adapter.source_enabled else "out")
        return adapter

    def validate(self) -> list[str]:
        errors = BaseAdapter.validate(self)
        if self.source_enabled and (not self.source_group_address or not self.source_dpt): errors.append("KNX: Quell-Gruppenadresse oder DPT fehlt")
        return errors



try:
    from app.services import knx as knx_service
except ModuleNotFoundError:
    from services import knx as knx_service


bp = Blueprint("plugin_knx", __name__)


def _core():
    return current_app.extensions["app_core"]


def _knx_test_error_response(exc, status_code=500):
    group_address = knx_service.normalize_knx_ga(request.form.get("group_address", ""))
    selected_dpt = str(request.form.get("dpt", "auto") or "auto").strip() or "auto"
    raw_value = str(request.form.get("value", "") or "").strip()
    in_monitor = str(request.form.get("show_in_monitor", "1")) == "1"
    resolved_dpt = "9.001" if selected_dpt.lower() == "auto" else selected_dpt
    payload = {
        "ok": False,
        "error": str(exc),
        "diagnostic": {
            "time": datetime.now().strftime("%H:%M:%S"),
            "telegram_type": "GroupValueWrite",
            "group_address": group_address,
            "dpt": resolved_dpt,
            "resolved_dpt": resolved_dpt,
            "raw_value": raw_value,
            "converted_value": "-",
            "apdu": "-",
            "status": "FEHLER",
            "in_monitor": in_monitor,
            "show_in_monitor": in_monitor,
            "http_status": int(status_code),
        },
    }
    return jsonify(payload), int(status_code)


@bp.route("/knx")
def knx_hub():
    return _core().knx_hub()


@bp.route("/knx_settings_embed")
def knx_settings_embed():
    return _core().knx_settings_embed()


@bp.route("/knx/save", methods=["POST"])
def knx_save():
    return _core().knx_save()


@bp.route("/knx/test", methods=["POST"])
def knx_test():
    try:
        return _core().knx_test()
    except Exception as exc:
        current_app.logger.exception("KNX test route failed")
        return _knx_test_error_response(exc, 500)


@bp.route("/knx_test/send", methods=["POST"])
def knx_test_send():
    try:
        return _core().knx_test_send()
    except Exception as exc:
        current_app.logger.exception("KNX test send failed")
        return _knx_test_error_response(exc, 500)


@bp.route("/knx_test/repeat", methods=["POST"])
def knx_test_repeat():
    try:
        return _core().knx_test_repeat()
    except Exception as exc:
        current_app.logger.exception("KNX test repeat failed")
        return _knx_test_error_response(exc, 500)


@bp.route("/knx_test/clear_monitor", methods=["POST"])
def knx_test_clear_monitor():
    try:
        return _core().knx_test_clear_monitor()
    except Exception as exc:
        current_app.logger.exception("KNX test clear monitor failed")
        return _knx_test_error_response(exc, 500)


@bp.route("/mqtt2knx")
def mqtt2knx():
    # Legacy Mapping-Explorer entfernt. Bestehende Laufzeitkonfiguration bleibt kompatibel.
    return redirect("/objects_v33")


@bp.route("/mqtt2knx/save", methods=["POST"])
def mqtt2knx_save():
    return redirect("/objects_v33")


@bp.route("/mqtt2knx/test/<int:index>", methods=["POST"])
def mqtt2knx_test(index):
    return redirect("/objects_v33")


@bp.route("/mqtt2knx_data")
def mqtt2knx_data():
    return redirect("/objects_v33")


@bp.route("/udp2knx")
def udp2knx():
    # Legacy Mapping-Explorer entfernt. Bestehende Laufzeitkonfiguration bleibt kompatibel.
    return redirect("/objects_v33")


@bp.route("/udp2knx/save", methods=["POST"])
def udp2knx_save():
    return redirect("/objects_v33")


@bp.route("/udp2knx/test/<int:index>", methods=["POST"])
def udp2knx_test(index):
    return redirect("/objects_v33")


@bp.route("/udp2knx_data")
def udp2knx_data():
    return redirect("/objects_v33")


@bp.route("/knx2mqtt")
def knx2mqtt():
    # Legacy Mapping-Explorer entfernt. Bestehende Laufzeitkonfiguration bleibt kompatibel.
    return redirect("/objects_v33")


@bp.route("/knx2mqtt/save", methods=["POST"])
def knx2mqtt_save():
    return redirect("/objects_v33")


@bp.route("/knx2mqtt_data")
def knx2mqtt_data():
    return redirect("/objects_v33")


@bp.route("/knx2lox")
def knx2lox():
    # Legacy Mapping-Explorer entfernt. Bestehende Laufzeitkonfiguration bleibt kompatibel.
    return redirect("/objects_v33")


@bp.route("/knx2lox/save", methods=["POST"])
def knx2lox_save():
    return redirect("/objects_v33")


@bp.route("/knx2lox_data")
def knx2lox_data():
    return redirect("/objects_v33")


@bp.route("/knx_monitor")
def knx_monitor():
    return _core().knx_monitor()


@bp.route("/knx_monitor_data")
def knx_monitor_data():
    return _core().knx_monitor_data()


@bp.route("/knx_monitor/influx", methods=["POST"])
def knx_monitor_influx():
    return _core().knx_monitor_influx()


@bp.route("/knx_monitor/influx_type", methods=["POST"])
def knx_monitor_influx_type():
    return _core().knx_monitor_influx_type()


@bp.route("/knx_monitor/influx_topic", methods=["POST"])
def knx_monitor_influx_topic():
    return _core().knx_monitor_influx_topic()


@bp.route("/knx_listener_start", methods=["POST"])
def knx_listener_start():
    return _core().knx_listener_start()



def _runtime_status(core):
    state = core.get_knx_runtime_state()
    enabled = bool(knx_service.knx_plugin_enabled())
    connected = bool(
        enabled
        and state.get("connection_status") == "connected"
        and state.get("listener_running")
        and state.get("xknx") is not None
        and state.get("loop") is not None
    )
    return {
        "enabled": enabled,
        "connected": connected,
        "connection": "connected" if connected else ("waiting" if enabled else "disabled"),
        "connection_status": str(state.get("connection_status") or ""),
        "listener_running": bool(state.get("listener_running")),
        "gateway_ip": str(state.get("gateway_ip") or ""),
        "gateway_port": state.get("gateway_port") or 3671,
        "last_error": str(state.get("last_error") or ""),
    }


def _runtime_start(core):
    knx_service.set_knx_plugin_runtime_enabled(True)
    core.add_log_entry("MP-KNX lifecycle start()")
    if not bool(core.load_knx_config().get("enabled", False)):
        core.add_log_entry("MP-KNX aktiv, KNX ist in den KNX-Einstellungen jedoch deaktiviert")
        return True
    ok = core.ensure_knx_listener_started("MP-KNX lifecycle start")
    return bool(ok)


def _runtime_stop(core):
    knx_service.set_knx_plugin_runtime_enabled(False)
    core.add_log_entry("MP-KNX lifecycle stop()")
    # The KNX listener checks the live plugin gate on every loop iteration and
    # closes its own xknx connection cleanly. Do not touch the shared bridge.
    return True


def _target_handler_factory(core):
    def _handler(item, target_adapter, value, original_source, source_ref, route_entry, metadata):
        if not knx_service.knx_plugin_enabled():
            core.add_log_entry(
                f"KNX TX blockiert: MP-KNX Plugin deaktiviert object_id={getattr(item, 'id', '')}"
            )
            return False

        raw_targets = core._adapter_targets(target_adapter)
        if not raw_targets:
            ga = str(getattr(target_adapter, "group_address", "") or "").strip()
            dpt = str(getattr(target_adapter, "dpt", "") or "").strip()
            if ga and dpt:
                raw_targets = [{
                    "enabled": True,
                    "group_address": ga,
                    "dpt": dpt,
                    "value_path": getattr(target_adapter, "target_value_path", ""),
                }]

        if not bool(core.load_knx_config().get("enabled", False)):
            return False

        sent = False
        for cfg in raw_targets:
            if not bool(cfg.get("enabled", True)):
                continue
            ga = str(cfg.get("group_address") or "").strip()
            dpt = str(cfg.get("dpt") or "").strip()
            if not ga or not dpt:
                continue
            target_value = core._target_value_or_skip(
                item, "knx", value, cfg.get("value_path", "")
            )
            if target_value is core._VALUE_PATH_MISSING:
                continue
            core.add_log_entry(
                f"OBJECT KNX TX object_id={getattr(item, 'id', '')} "
                f"target=knx ga={ga} dpt={dpt} raw={target_value}"
            )
            if knx_service.send_knx_value(
                ga,
                dpt,
                target_value,
                core.load_knx_config,
                core.add_log_entry,
                add_monitor_entry=core.add_knx_monitor_entry,
            ):
                sent = True
        return sent
    return _handler


def _runtime_send_factory(core):
    handler = _target_handler_factory(core)
    def _send(item, target_adapter, value, original_source="", source_ref="", route_entry=None, metadata=None):
        return handler(
            item,
            target_adapter,
            value,
            original_source,
            source_ref,
            route_entry or {},
            metadata or {},
        )
    return _send


def register_adapter():
    from app.services.object_adapter_engine import register_adapter as reg
    reg(KNXAdapter, template_name="objects_v33/adapters/knx.html")

def register(app, core, manager):
    if bp.name not in app.blueprints:
        app.register_blueprint(bp)

    # Passive registration happens even while the Runtime-API plugin is
    # disabled. This keeps routes/explorer available for live reactivation.
    rec = manager.records.get("knx")
    knx_service.set_knx_plugin_runtime_enabled(bool(rec.enabled) if rec is not None else True)

    from app.plugins.runtime import registry
    runtime = registry.register(
        "knx",
        start=lambda: _runtime_start(core),
        stop=lambda: _runtime_stop(core),
        status=lambda: _runtime_status(core),
        send=_runtime_send_factory(core),
    )

    def _generic_target(item, target_adapter, value, original_source, source_ref, route_entry, metadata):
        if not knx_service.knx_plugin_enabled():
            core.add_log_entry(
                f"KNX TX blockiert: MP-KNX Plugin deaktiviert object_id={getattr(item, 'id', '')}"
            )
            return False
        return runtime.send(
            item, target_adapter, value, original_source, source_ref, route_entry, metadata
        )

    core.register_plugin_target_handler("knx", _generic_target)
    core.add_log_entry("MP-KNX an generischer Plugin-Runtime-API registriert")
