from __future__ import annotations


def register(app, core, manager) -> None:
    from .routes import bp
    from .services.mqtt import OpenCcuMqttRuntime
    from .services.rest import OpenCcuRestCache
    from .services.config import as_runtime_config

    # Always use the exact object-service singleton owned by the running core.
    object_service = core.object_core_service

    if bp.name not in app.blueprints:
        app.register_blueprint(bp)

    # OpenCCU is a semantic source. CCU-Jack MQTT is only its transport.
    try:
        object_service.SUPPORTED_ROUTE_PAIRS.update({
            ("openccu", "mqtt"), ("openccu", "loxone"),
            ("openccu", "knx"), ("openccu", "udp"),
            ("openccu", "influx"),
        })
    except Exception:
        app.logger.exception("OpenCCU Plugin routing registration failed")

    try:
        config_loader = lambda: as_runtime_config(core)
        metadata = OpenCcuRestCache(config_loader, app.logger)
        app.extensions["openccu_metadata_cache"] = metadata
        metadata.ensure_fresh()

        def on_value(topic, value, timestamp):
            # Keep the proven 36.7.21 ingress/routing path unchanged: the
            # central object service records the value and invokes the normal
            # MP-Gateway router itself. This is intentionally NOT wrapped in a
            # plugin-owned routing queue.
            live_items = object_service.record_live_value(
                "openccu", value, topic=topic, timestamp=timestamp,
                original_source="openccu", route_after_record=True,
            )

            # Proven safety net from the former core integration: directly
            # after editing/creating an object, an endpoint-index lookup can
            # briefly miss. Match the persisted OpenCCU topic directly and
            # update the central live cache by object ID.
            direct_updates = []
            if not live_items:
                normalized_topic = str(topic or "").strip()
                for item in object_service.list_objects():
                    meta = dict(getattr(item, "meta", {}) or {})
                    semantic_source = str(meta.get("source") or meta.get("origin_source") or "").strip().lower()
                    stored_topic = str(meta.get("openccu_topic") or "").strip()
                    if semantic_source != "openccu" or not normalized_topic or stored_topic != normalized_topic:
                        continue
                    live = object_service.update_object_live_value(
                        item.id, value, source="openccu", endpoint="openccu.topic",
                        source_address=normalized_topic, timestamp=timestamp, status="aktiv",
                    )
                    if live:
                        direct_updates.append({"object": item.to_dict(), "live": live})

            # Only fallback updates bypassed record_live_value and therefore
            # still need explicit routing, exactly as in 36.7.21.
            if direct_updates:
                core._dispatch_object_routes(
                    direct_updates, "openccu", topic, value,
                    metadata={"topic": topic, "gateway_origin": "openccu", "use_event_value": False},
                )

        runtime = OpenCcuMqttRuntime(config_loader, app.logger, on_value=on_value, metadata=metadata)
        app.extensions["openccu_mqtt_runtime"] = runtime
        runtime.start()
        core.add_log_entry("OpenCCU Plugin Runtime gestartet")
    except Exception:
        app.logger.exception("OpenCCU Plugin runtime could not be started")
