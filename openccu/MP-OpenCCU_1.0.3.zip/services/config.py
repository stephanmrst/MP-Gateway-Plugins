from __future__ import annotations

from pathlib import Path

from app.engine import port
from app.services.config import safe_load_json_file, safe_save_json_file

DATA_DIR = Path(str(port.CONFIG_DIR)) / "plugin_data" / "openccu"
CONFIG_FILE = DATA_DIR / "config.json"

DEFAULT_CONFIG = {
    "enabled": False,
    "host": "",
    "http_port": 80,
    "https": False,
    "api_user": "",
    "api_password": "",
    "mqtt_host": "",
    "mqtt_port": 1883,
    "mqtt_user": "",
    "mqtt_password": "",
    "mqtt_tls": False,
    "topic_prefix": "device/status/#",
    "last_test": {},
}


def load_openccu_config(core=None) -> dict:
    data = safe_load_json_file(str(CONFIG_FILE), None)
    if not isinstance(data, dict):
        # One-time migration from the former core config keeps existing setups
        # working across the 36.8.x -> 36.9.x plugin migration.
        legacy = {}
        if core is not None:
            try:
                legacy = dict((core.load_config() or {}).get("openccu", {}) or {})
            except Exception:
                legacy = {}
        data = legacy
    merged = dict(DEFAULT_CONFIG)
    merged.update(data or {})
    if not CONFIG_FILE.exists() and any(v not in (None, "", False, {}, []) for v in merged.values()):
        save_openccu_config(merged)
    return merged


def save_openccu_config(data: dict) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    payload = dict(DEFAULT_CONFIG)
    payload.update(data if isinstance(data, dict) else {})
    safe_save_json_file(str(CONFIG_FILE), payload, indent=2)


def as_runtime_config(core=None) -> dict:
    return {"openccu": load_openccu_config(core)}
