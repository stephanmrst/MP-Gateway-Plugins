"""MQTT routes.

These routes delegate to the app core handlers during the migration.
"""

from flask import Blueprint, current_app, redirect
from dataclasses import dataclass, field
from typing import ClassVar, Any
from app.services.object_adapter_engine import BaseAdapter

@dataclass
class MQTTAdapter(BaseAdapter):
    protocol: ClassVar[str] = "mqtt"
    topic: str = ""
    qos: int = 0
    retain: bool = False
    json_key: str = ""
    source_broker: str = "Hauptbroker"
    targets: list[dict[str, Any]] = field(default_factory=list)

    @classmethod
    def deserialize(cls, data: dict[str, Any]) -> "MQTTAdapter":
        payload = dict(data or {})
        payload["source_broker"] = str(payload.get("source_broker") or payload.get("broker") or "Hauptbroker").strip() or "Hauptbroker"
        targets = payload.get("targets")
        if not isinstance(targets, list):
            targets = []
        normalized = []
        for index, target in enumerate(targets):
            if not isinstance(target, dict):
                continue
            topic = str(target.get("topic") or "").strip()
            if not topic:
                continue
            try:
                qos = max(0, min(2, int(target.get("qos", 0) or 0)))
            except (TypeError, ValueError):
                qos = 0
            normalized.append({
                "id": str(target.get("id") or f"mqtt_target_{index+1}"),
                "enabled": bool(target.get("enabled", True)),
                "broker": str(target.get("broker") or "Hauptbroker").strip() or "Hauptbroker",
                "topic": topic,
                "qos": qos,
                "retain": bool(target.get("retain", False)),
                "payload_mode": str(target.get("payload_mode") or "raw").strip() or "raw",
                "value_path": str(target.get("value_path") or target.get("target_value_path") or "").strip(),
                "color_temp_min": int(target.get("color_temp_min", 153) or 153),
                "color_temp_max": int(target.get("color_temp_max", 454) or 454),
            })
        # Migration: bisheriges einzelnes MQTT-Ausgangsziel auf Hauptbroker übernehmen.
        direction = str(payload.get("direction", "both") or "both").lower()
        legacy_topic = str(payload.get("topic") or "").strip()
        if not normalized and legacy_topic and direction in {"out", "both"}:
            normalized.append({
                "id": "mqtt_target_1", "enabled": bool(payload.get("enabled", True)),
                "broker": "Hauptbroker", "topic": legacy_topic,
                "qos": max(0, min(2, int(payload.get("qos", 0) or 0))),
                "retain": bool(payload.get("retain", False)),
                "payload_mode": str(payload.get("payload_mode") or "raw").strip() or "raw",
                "value_path": str(payload.get("target_value_path") or "").strip(),
                "color_temp_min": int(payload.get("color_temp_min", 153) or 153),
                "color_temp_max": int(payload.get("color_temp_max", 454) or 454),
            })
        payload["targets"] = normalized
        return super().deserialize(payload)




bp = Blueprint("plugin_mqtt", __name__)


def _core():
    return current_app.extensions["app_core"]


@bp.route("/mqtt")
def mqtt_hub():
    # Legacy-Hub entfernt: direkter Einstieg in den MQTT Explorer.
    return redirect("/monitor")


@bp.route("/monitor")
def monitor():
    return _core().monitor()


@bp.route("/monitor_data")
def monitor_data():
    return _core().monitor_data()


@bp.route("/monitor_settings")
def monitor_settings():
    return _core().monitor_settings()


@bp.route("/monitor_topic_config")
def monitor_topic_config():
    return _core().monitor_topic_config()


@bp.route("/monitor/influx_topic", methods=["POST"])
def monitor_influx_topic():
    return _core().monitor_influx_topic()


@bp.route("/monitor/influx_json_key", methods=["POST"])
def monitor_influx_json_key():
    return _core().monitor_influx_json_key()


@bp.route("/monitor/influx_json_key_type", methods=["POST"])
def monitor_influx_json_key_type():
    return _core().monitor_influx_json_key_type()


@bp.route("/monitor/favorite", methods=["POST"])
def monitor_favorite():
    return _core().monitor_favorite()


@bp.route("/monitor/alias", methods=["POST"])
def monitor_alias():
    return _core().monitor_alias()


@bp.route("/topics")
def topics():
    return _core().topics()


@bp.route("/topics_data")
def topics_data():
    return _core().topics_data()


@bp.route("/topics/save", methods=["POST"])
def topics_save():
    return _core().topics_save()


@bp.route("/topics2")
def topics2_page():
    return _core().topics2_page()


@bp.route("/topics2/data")
def topics2_data():
    return _core().topics2_data()


@bp.route("/topics2/save", methods=["POST"])
def topics2_save():
    return _core().topics2_save()


@bp.route("/mqtt_brokers")
def mqtt_brokers_page():
    return _core().mqtt_brokers_page()


@bp.route("/mqtt_brokers/save", methods=["POST"])
def mqtt_brokers_save():
    return _core().mqtt_brokers_save()


@bp.route("/test/mqtt_broker/<int:index>", methods=["POST"])
def test_mqtt_broker(index):
    return _core().test_mqtt_broker(index)

def register_adapter():
    from app.services.object_adapter_engine import register_adapter as reg
    reg(MQTTAdapter, template_name="objects_v33/adapters/mqtt.html")

def register(app, core, manager):
    if bp.name not in app.blueprints:
        app.register_blueprint(bp)
