from __future__ import annotations

import base64
import hashlib
import hmac
import json
import socket
import ssl
import struct
import threading
import time
import urllib.parse
import urllib.request
import urllib.error
import uuid
from typing import Any, Callable

EU_ENDPOINT = "https://openapi.tuyaeu.com"
US_ENDPOINT = "https://openapi.tuyaus.com"
CN_ENDPOINT = "https://openapi.tuyacn.com"
IN_ENDPOINT = "https://openapi.tuyain.com"


def endpoint_for_country(country_code: str) -> str:
    code = str(country_code or "49").lstrip("+")
    if code == "86":
        return CN_ENDPOINT
    if code == "91":
        return IN_ENDPOINT
    if code in {"1", "52", "54", "55", "56", "57", "591", "593"}:
        return US_ENDPOINT
    return EU_ENDPOINT


class TuyaIoTError(RuntimeError):
    pass


class TuyaOpenAPI:
    def __init__(self, access_id: str, access_secret: str, username: str, password: str,
                 country_code: str = "49", app_schema: str = "smartlife", timeout: float = 12.0):
        self.access_id = str(access_id or "").strip()
        self.access_secret = str(access_secret or "").strip()
        self.username = str(username or "").strip()
        self.password = str(password or "")
        self.country_code = str(country_code or "49").lstrip("+")
        self.app_schema = str(app_schema or "smartlife").strip()
        if self.app_schema == "smart_life":
            self.app_schema = "smartlife"
        self.endpoint = endpoint_for_country(self.country_code)
        self.timeout = float(timeout)
        self.nonce = str(uuid.uuid1())
        self.token_info = {"access_token": "", "refresh_token": "", "uid": "", "expire": 0}

    @staticmethod
    def _json_body(body: Any) -> str:
        return json.dumps(body, ensure_ascii=False, separators=(",", ":")) if body is not None else ""

    def _sign_url(self, path: str, params: dict[str, Any] | None) -> str:
        if not params:
            return path
        # Keep insertion order, mirroring the adapter implementation.
        return path + "?" + "&".join(f"{k}={v}" for k, v in params.items())

    def _string_to_sign(self, method: str, path: str, params: dict[str, Any] | None, body: Any) -> str:
        body_stream = self._json_body(body)
        content_sha256 = hashlib.sha256(body_stream.encode()).hexdigest()
        headers = f"client_id:{self.access_id}\n"
        return f"{method.upper()}\n{content_sha256}\n{headers}\n{self._sign_url(path, params)}"

    def _signature(self, token: str, timestamp: int, string_to_sign: str) -> str:
        message = f"{self.access_id}{token}{timestamp}{self.nonce}{string_to_sign}"
        return hmac.new(self.access_secret.encode(), message.encode(), hashlib.sha256).hexdigest().upper()

    def _authorized_login(self) -> None:
        md5pwd = hashlib.md5(self.password.encode()).hexdigest()
        res = self.request("POST", "/v1.0/iot-01/associated-users/actions/authorized-login", body={
            "country_code": self.country_code,
            "username": self.username,
            "password": md5pwd,
            "schema": self.app_schema,
        }, skip_auth=True)
        result = (res or {}).get("result") if isinstance(res, dict) else None
        if not isinstance(result, dict) or not result.get("access_token"):
            raise TuyaIoTError("Tuya IoT Login fehlgeschlagen: " + self._error_text(res))
        platform_url = str(result.get("platform_url") or "").rstrip("/")
        if platform_url:
            self.endpoint = platform_url
        self.token_info = {
            "access_token": str(result.get("access_token") or ""),
            "refresh_token": str(result.get("refresh_token") or ""),
            "uid": str(result.get("uid") or ""),
            "expire": int(time.time() * 1000) + int(result.get("expire_time") or 3600) * 1000,
        }

    def _ensure_token(self, path: str) -> None:
        if path.startswith("/v1.0/iot-01/associated-users/actions/authorized-login"):
            return
        if self.token_info["access_token"] and self.token_info["expire"] - 60000 > int(time.time() * 1000):
            return
        self._authorized_login()

    @staticmethod
    def _error_text(payload: Any) -> str:
        if not isinstance(payload, dict):
            return str(payload or "Leere/ungültige Antwort")
        code = (
            payload.get("code") or payload.get("error_code") or
            payload.get("errorCode") or payload.get("errcode") or
            payload.get("error")
        )
        msg = (
            payload.get("msg") or payload.get("message") or
            payload.get("error_msg") or payload.get("errorMsg") or
            payload.get("description")
        )
        parts = []
        if code not in (None, ""):
            parts.append(f"Code {code}")
        if msg not in (None, ""):
            parts.append(str(msg))
        if parts:
            return " – ".join(parts)
        # Tuya occasionally returns a failure object with only nested/detail
        # fields. Keep it compact but do not hide the useful server response.
        try:
            raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        except Exception:
            raw = repr(payload)
        return raw[:1200] if raw else "Unbekannter Fehler (leere Antwort)"

    def request(self, method: str, path: str, params: dict[str, Any] | None = None,
                body: Any = None, *, skip_auth: bool = False) -> dict[str, Any]:
        if not skip_auth:
            self._ensure_token(path)
        timestamp = int(time.time() * 1000)
        token = "" if skip_auth else str(self.token_info.get("access_token") or "")
        string_to_sign = self._string_to_sign(method, path, params, body)
        headers = {
            "t": str(timestamp), "client_id": self.access_id, "nonce": self.nonce,
            "Signature-Headers": "client_id", "sign": self._signature(token, timestamp, string_to_sign),
            "sign_method": "HMAC-SHA256", "access_token": token, "lang": "de",
            "dev_lang": "python", "dev_channel": "mp-gateway", "devVersion": "1.2.0",
            "Content-Type": "application/json",
        }
        url = self.endpoint + path
        if params:
            url += "?" + urllib.parse.urlencode(params)
        data = self._json_body(body).encode() if body is not None else None
        req = urllib.request.Request(url, data=data, headers=headers, method=method.upper())
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                raw_body = response.read().decode("utf-8", errors="replace")
                payload = json.loads(raw_body)
        except urllib.error.HTTPError as exc:
            try:
                body = exc.read().decode("utf-8", errors="replace")
            except Exception:
                body = ""
            detail = body[:1200] if body else str(exc)
            raise TuyaIoTError(f"Tuya IoT HTTP {exc.code}: {detail}") from exc
        except urllib.error.URLError as exc:
            raise TuyaIoTError(f"Tuya IoT API nicht erreichbar: {exc.reason}") from exc
        except Exception as exc:
            raise TuyaIoTError(f"Tuya IoT API Fehler: {type(exc).__name__}: {exc}") from exc
        if not isinstance(payload, dict):
            raise TuyaIoTError(f"Ungültige Tuya-IoT-Antwort: {str(payload)[:800]}")
        if payload.get("success") is False:
            raise TuyaIoTError(self._error_text(payload))
        return payload

    def get_mqtt_config(self, link_id: str, encrypted_version: str = "2.0") -> dict[str, Any]:
        res = self.request("POST", "/v1.0/iot-03/open-hub/access-config", body={
            "uid": self.token_info.get("uid"), "link_id": link_id, "link_type": "mqtt",
            "topics": "device", "msg_encrypted_version": encrypted_version,
        })
        result = res.get("result") if isinstance(res, dict) else None
        if not isinstance(result, dict):
            raise TuyaIoTError("Tuya lieferte keine MQTT-Zugangsdaten")
        return result


def _enc_utf8(value: str) -> bytes:
    raw = str(value).encode()
    return struct.pack("!H", len(raw)) + raw


def _remaining_length(length: int) -> bytes:
    out = bytearray()
    while True:
        digit = length % 128
        length //= 128
        if length:
            digit |= 0x80
        out.append(digit)
        if not length:
            return bytes(out)


def _mqtt_packet(packet_type_flags: int, payload: bytes) -> bytes:
    return bytes([packet_type_flags]) + _remaining_length(len(payload)) + payload


def _read_exact(sock: socket.socket, count: int) -> bytes:
    chunks = bytearray()
    while len(chunks) < count:
        chunk = sock.recv(count - len(chunks))
        if not chunk:
            raise ConnectionError("MQTT-Verbindung geschlossen")
        chunks.extend(chunk)
    return bytes(chunks)


def _read_packet(sock: socket.socket) -> tuple[int, bytes]:
    first = _read_exact(sock, 1)[0]
    multiplier = 1
    remaining = 0
    while True:
        digit = _read_exact(sock, 1)[0]
        remaining += (digit & 127) * multiplier
        if not digit & 128:
            break
        multiplier *= 128
        if multiplier > 128 ** 3:
            raise TuyaIoTError("Ungültiges MQTT Remaining Length")
    return first, _read_exact(sock, remaining)


class OpenHubMQTT:
    """Tuya OpenHub MQTT client backed by paho-mqtt.

    Tuya returns short-lived broker credentials and the exact device topic.
    This mirrors the transport behavior used by ioBroker's mqtt.js client
    instead of maintaining a partial MQTT implementation ourselves.
    """
    def __init__(self, url: str, client_id: str, username: str, password: str, topic: str,
                 on_message: Callable[[str, bytes], None], logger=None):
        self.url = str(url or "")
        self.client_id = str(client_id or "")
        self.username = str(username or "")
        self.password = str(password or "")
        self.topic = str(topic or "")
        self.on_message_cb = on_message
        self.logger = logger
        self.client = None
        self.connected = threading.Event()
        self.failed = threading.Event()
        self.last_error = ""
        self.packet_count = 0

    def _log(self, level: str, msg: str, *args) -> None:
        try: getattr(self.logger, level)(msg, *args)
        except Exception: pass

    def connect(self) -> None:
        try:
            import paho.mqtt.client as mqtt
        except Exception as exc:
            raise TuyaIoTError("Python-Paket 'paho-mqtt' fehlt") from exc

        parsed = urllib.parse.urlparse(self.url if "://" in self.url else "mqtt://" + self.url)
        scheme = parsed.scheme.lower()
        host = parsed.hostname or ""
        if not host:
            raise TuyaIoTError(f"Ungültige Tuya MQTT URL: {self.url}")
        tls = scheme in {"mqtts", "ssl", "tls"}
        port = parsed.port or (8883 if tls else 1883)

        # VERSION1 keeps callback signatures stable across paho 1.x/2.x.
        callback_api = getattr(mqtt, "CallbackAPIVersion", None)
        kwargs = {"client_id": self.client_id, "protocol": mqtt.MQTTv311}
        if callback_api is not None:
            kwargs["callback_api_version"] = callback_api.VERSION1
        client = mqtt.Client(**kwargs)
        client.username_pw_set(self.username, self.password)
        if tls:
            client.tls_set(cert_reqs=ssl.CERT_REQUIRED)
            client.tls_insecure_set(False)

        def on_connect(_client, _userdata, _flags, rc, *extra):
            if int(rc) != 0:
                self.last_error = f"MQTT CONNACK {rc}"
                self.failed.set()
                return
            result, _mid = _client.subscribe(self.topic, qos=0)
            if int(result) != int(mqtt.MQTT_ERR_SUCCESS):
                self.last_error = f"MQTT Subscribe Fehler {result}"
                self.failed.set()
                return
            self.connected.set()
            self._log("info", "MP-Tuya OpenHub MQTT verbunden: %s topic=%s", self.url, self.topic)

        def on_disconnect(_client, _userdata, rc, *extra):
            if int(rc) != 0 and not self.failed.is_set():
                self.last_error = f"MQTT getrennt rc={rc}"
                self.failed.set()

        def on_message(_client, _userdata, message):
            self.packet_count += 1
            try:
                self.on_message_cb(str(message.topic), bytes(message.payload))
            except Exception as exc:
                # A malformed Tuya message must not tear down the MQTT transport.
                self._log("warning", "MP-Tuya Cloud-Nachricht verworfen: %s", exc)

        client.on_connect = on_connect
        client.on_disconnect = on_disconnect
        client.on_message = on_message
        self.client = client

        client.connect(host, port, keepalive=60)
        client.loop_start()
        deadline = time.monotonic() + 15
        while not self.connected.is_set():
            if self.failed.is_set():
                raise TuyaIoTError(self.last_error or "MQTT-Verbindung fehlgeschlagen")
            if time.monotonic() >= deadline:
                raise TuyaIoTError("MQTT-Verbindungsaufbau Timeout")
            time.sleep(0.05)

    def loop_once(self) -> None:
        if self.failed.is_set():
            raise TuyaIoTError(self.last_error or "MQTT-Verbindung getrennt")
        time.sleep(0.1)

    def close(self) -> None:
        client = self.client
        self.client = None
        if client is not None:
            try: client.disconnect()
            except Exception: pass
            try: client.loop_stop()
            except Exception: pass


def _decrypt_message(data_b64: str, mqtt_password: str, timestamp: int, version: str) -> str:
    """Decrypt Tuya OpenHub MQTT payload exactly like ioBroker.tuya.

    OpenHub encryption v2.0 is NOT the same envelope as Tuya Pulsar:
      base64 -> [4-byte IV length][IV][ciphertext][16-byte GCM tag]
      key = mqtt_password[8:24]
      AAD = timestamp encoded as unsigned 6-byte big-endian
    """
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        from cryptography.hazmat.primitives import padding
    except Exception as exc:
        raise TuyaIoTError("Python-Modul 'cryptography' fehlt für Tuya Cloud-Echtzeit") from exc

    password = str(mqtt_password or "")
    key = password[8:24].encode("utf-8")
    if len(key) != 16:
        raise TuyaIoTError(f"MQTT-Passwort liefert keinen 16-Byte AES-Key ({len(key)} B)")

    try:
        blob = base64.b64decode(str(data_b64), validate=True)
    except Exception as exc:
        raise TuyaIoTError(f"Base64 ungültig: {exc}") from exc

    if str(version) == "2.0":
        if len(blob) < 4 + 1 + 16:
            raise TuyaIoTError(f"OpenHub-GCM Paket zu kurz: {len(blob)} B")

        iv_len = int.from_bytes(blob[:4], "big")
        if iv_len <= 0 or 4 + iv_len + 16 > len(blob):
            raise TuyaIoTError(f"OpenHub-GCM IV-Länge ungültig: {iv_len} bei {len(blob)} B")

        iv = blob[4:4 + iv_len]
        ciphertext = blob[4 + iv_len:-16]
        tag = blob[-16:]

        try:
            aad = int(timestamp).to_bytes(6, "big", signed=False)
        except Exception as exc:
            raise TuyaIoTError(f"OpenHub-GCM Timestamp/AAD ungültig: {timestamp}") from exc

        try:
            # ioBroker.tuya macht bei OpenHub absichtlich nur cipher.update()
            # und KEIN cipher.final(). Dadurch wird der GCM-Auth-Tag nicht
            # abschließend verifiziert. Wir spiegeln dieses Verhalten exakt.
            decryptor = Cipher(
                algorithms.AES(key),
                modes.GCM(iv, tag),
            ).decryptor()
            decryptor.authenticate_additional_data(aad)
            plain = decryptor.update(ciphertext)
            return plain.decode("utf-8")
        except Exception as exc:
            raise TuyaIoTError(
                f"OpenHub-GCM/update fehlgeschlagen: {type(exc).__name__}: {exc} "
                f"(iv={iv_len}B, ct={len(ciphertext)}B, tag=16B, aad=6B)"
            ) from exc

    # Legacy OpenHub encryption 1.0: AES-128-ECB with PKCS7.
    if not blob or len(blob) % 16:
        raise TuyaIoTError(f"OpenHub-ECB Ciphertext-Länge ungültig: {len(blob)}")
    try:
        decryptor = Cipher(algorithms.AES(key), modes.ECB()).decryptor()
        padded = decryptor.update(blob) + decryptor.finalize()
        unpadder = padding.PKCS7(128).unpadder()
        return (unpadder.update(padded) + unpadder.finalize()).decode("utf-8")
    except Exception as exc:
        raise TuyaIoTError(f"OpenHub-ECB fehlgeschlagen: {type(exc).__name__}: {exc}") from exc


def _extract_updates(data: Any) -> list[tuple[str, str, Any]]:
    updates: list[tuple[str, str, Any]] = []
    seen = set()

    def walk(node: Any, inherited_device: str = "") -> None:
        if isinstance(node, list):
            for item in node: walk(item, inherited_device)
            return
        if not isinstance(node, dict):
            return
        device = inherited_device
        for key in ("devId", "deviceId", "device_id", "dev_id"):
            if node.get(key):
                device = str(node[key]); break
        dps = node.get("dps")
        if device and isinstance(dps, dict):
            for dp, value in dps.items():
                sig = (device, str(dp), json.dumps(value, sort_keys=True, default=str))
                if sig not in seen:
                    seen.add(sig); updates.append((device, str(dp), value))
        status = node.get("status")
        if device and isinstance(status, list):
            for item in status:
                if not isinstance(item, dict): continue
                code = item.get("dpId") or item.get("dp_id") or item.get("code") or item.get("id")
                if code is None or "value" not in item: continue
                sig = (device, str(code), json.dumps(item.get("value"), sort_keys=True, default=str))
                if sig not in seen:
                    seen.add(sig); updates.append((device, str(code), item.get("value")))
        # Some event formats carry code/value directly.
        if device and "code" in node and "value" in node:
            sig = (device, str(node["code"]), json.dumps(node["value"], sort_keys=True, default=str))
            if sig not in seen:
                seen.add(sig); updates.append((device, str(node["code"]), node["value"]))
        for value in node.values():
            if isinstance(value, (dict, list)):
                walk(value, device)
    walk(data)
    return updates


class TuyaIoTRealtime:
    def __init__(self, config_loader: Callable[[], dict[str, Any]], runtime, logger):
        self.config_loader, self.runtime, self.logger = config_loader, runtime, logger
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._generation = 0
        self._lock = threading.RLock()
        self.link_id = str(uuid.uuid1())
        self.status = {
            "enabled": False, "connected": False, "state": "disabled",
            "message": "Deaktiviert", "last_message": "", "message_count": 0,
            "last_extracted": 0, "last_updates": 0, "last_unmatched": [],
            "transport": "Tuya OpenHub MQTT", "broker": "", "topic": "",
            "raw_packets": 0, "decode_errors": 0, "last_decode_error": "", "decode_stage": "", "outer_keys": [], "encrypted_version_seen": "", "payload_length": 0, "decoded_length": 0, "error": ""
        }

    def _set(self, **changes) -> None:
        with self._lock: self.status.update(changes)

    def snapshot(self) -> dict[str, Any]:
        with self._lock: return dict(self.status)

    def reload(self, cfg: dict[str, Any] | None = None) -> None:
        self._generation += 1
        gen = self._generation
        cfg = dict(cfg or self.config_loader() or {})
        rt = dict(cfg.get("iot_realtime") or {})
        if not rt.get("enabled"):
            self._set(enabled=False, connected=False, state="disabled", message="Deaktiviert", error="")
            return
        self._set(enabled=True, connected=False, state="starting", message="Tuya IoT Verbindung wird aufgebaut", error="")
        self._thread = threading.Thread(target=self._run, args=(gen,), daemon=True, name="mp-tuya-iot-realtime")
        self._thread.start()

    def start(self) -> None: self.reload()

    def _run(self, generation: int) -> None:
        while generation == self._generation and not self._stop.is_set():
            mqtt = None
            try:
                cfg = self.config_loader() or {}
                rt = dict(cfg.get("iot_realtime") or {})
                cloud = dict(cfg.get("cloud") or {})
                username = str(rt.get("username") or cloud.get("username") or "")
                password = str(rt.get("password") or cloud.get("password") or "")
                if not all([rt.get("access_id"), rt.get("access_secret"), username, password]):
                    raise TuyaIoTError("Access ID, Access Secret, App-Benutzer und App-Passwort werden benötigt")
                api = TuyaOpenAPI(rt.get("access_id"), rt.get("access_secret"), username, password,
                                  rt.get("country_code", "49"), rt.get("app_schema", "smartlife"))
                self._set(state="login", message="Tuya IoT: App-Konto am Cloud-Projekt anmelden", error="")
                # Forces associated-user login before asking for MQTT credentials.
                api._ensure_token("/v1.0/iot-03/open-hub/access-config")
                self._set(state="mqtt_config", message="Tuya IoT: MQTT-Zugangsdaten abrufen", error="")
                link_id = str(uuid.uuid1())
                version = str(rt.get("encrypted_version") or "2.0")
                mqcfg = api.get_mqtt_config(link_id, version)
                topic = str(((mqcfg.get("source_topic") or {}).get("device")) or "")
                if not topic:
                    raise TuyaIoTError("Tuya MQTT Device-Topic fehlt")

                def on_mqtt(_topic: str, payload: bytes) -> None:
                    now = time.strftime("%Y-%m-%d %H:%M:%S")
                    with self._lock:
                        self.status["raw_packets"] = int(self.status.get("raw_packets") or 0) + 1
                        self.status["last_message"] = now
                        self.status["decode_stage"] = "outer_json"
                        self.status["payload_length"] = len(payload or b"")
                        self.status["decoded_length"] = 0
                        self.status["last_decode_error"] = ""

                    try:
                        raw_text = payload.decode("utf-8", errors="replace").strip()
                        if not raw_text:
                            raise TuyaIoTError("leere MQTT-Nachricht")
                        outer = json.loads(raw_text)
                        if not isinstance(outer, dict):
                            raise TuyaIoTError(f"äußeres JSON ist {type(outer).__name__}, erwartet dict")
                        with self._lock:
                            self.status["outer_keys"] = sorted(str(k) for k in outer.keys())[:20]
                            self.status["encrypted_version_seen"] = str(
                                outer.get("version")
                                or outer.get("protocol")
                                or outer.get("msg_encrypted_version")
                                or version
                            )

                        with self._lock:
                            self.status["decode_stage"] = "decrypt"
                        encoded = str(outer.get("data") or "")
                        if not encoded:
                            raise TuyaIoTError("Feld 'data' fehlt oder ist leer")

                        decoded = _decrypt_message(
                            encoded,
                            str(mqcfg.get("password") or ""),
                            int(outer.get("t") or 0),
                            str(outer.get("pv") or version)
                        )
                        if decoded is None:
                            raise TuyaIoTError("Entschlüsselung lieferte None")
                        decoded = str(decoded).strip()
                        with self._lock:
                            self.status["decoded_length"] = len(decoded)

                        if not decoded:
                            raise TuyaIoTError("entschlüsselte Nachricht ist leer")

                        with self._lock:
                            self.status["decode_stage"] = "inner_json"
                        data = json.loads(decoded)

                        with self._lock:
                            self.status["decode_stage"] = "extract"
                        count = 0
                        extracted = _extract_updates(data)
                        unmatched = []
                        for dev_id, dp_or_code, value in extracted:
                            if self.runtime.handle_cloud_update(dev_id, dp_or_code, value):
                                count += 1
                            else:
                                unmatched.append(f"{dev_id}/{dp_or_code}")

                        with self._lock:
                            self.status["message_count"] = int(self.status.get("message_count") or 0) + 1
                            self.status["last_updates"] = count
                            self.status["last_extracted"] = len(extracted)
                            self.status["last_unmatched"] = unmatched[:10]
                            self.status["decode_stage"] = "ok"
                            self.status["last_decode_error"] = ""

                    except Exception as exc:
                        with self._lock:
                            stage = str(self.status.get("decode_stage") or "unknown")
                            self.status["decode_errors"] = int(self.status.get("decode_errors") or 0) + 1
                            self.status["last_decode_error"] = f"{stage}: {type(exc).__name__}: {exc}"
                        raise

                broker_url = str(mqcfg.get("url") or "")
                mqtt = OpenHubMQTT(broker_url, str(mqcfg.get("client_id") or ""),
                                   str(mqcfg.get("username") or ""), str(mqcfg.get("password") or ""),
                                   topic, on_mqtt, self.logger)
                self._set(
                    state="mqtt_connect", message="Tuya OpenHub MQTT wird aufgebaut",
                    transport="Tuya OpenHub MQTT", broker=broker_url, topic=topic, error=""
                )
                mqtt.connect()
                self._set(connected=True, state="connected", message="Cloud-Echtzeit verbunden", error="")
                expire = max(120, int(mqcfg.get("expire_time") or 7200))
                deadline = time.monotonic() + max(60, expire - 60)
                while generation == self._generation and not self._stop.is_set() and time.monotonic() < deadline:
                    mqtt.loop_once()
            except Exception as exc:
                current = self.snapshot()
                stage = str(current.get("message") or "Tuya IoT")
                self._set(connected=False, state="error", message="Cloud-Echtzeit getrennt", error=f"{stage}: {exc}")
                try: self.logger.warning("MP-Tuya IoT Echtzeit: %s", exc)
                except Exception: pass
                time.sleep(10)
            finally:
                if mqtt: mqtt.close()
        self._set(connected=False)
