from __future__ import annotations
import json
from copy import deepcopy
from pathlib import Path
from app.engine import port

PLUGIN_DATA_DIR = Path(str(port.CONFIG_DIR)) / "plugin_data" / "unifi"
CONFIG_FILE = PLUGIN_DATA_DIR / "config.json"

DEFAULT_CONFIG={"enabled":True,"controller":{"url":"https://192.168.1.1:8443","username":"","password":"","site":"default","verify_ssl":False,"poll_interval":60.0,"detected_mode":"","detected_url":""}}

def load_config():
    cfg=deepcopy(DEFAULT_CONFIG)
    try:
        raw=json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        if isinstance(raw,dict):
            cfg["enabled"]=bool(raw.get("enabled",True))
            if isinstance(raw.get("controller"),dict):
                cfg["controller"].update(raw["controller"])
    except FileNotFoundError:
        pass
    except Exception:
        pass
    return cfg

def save_config(cfg):
    PLUGIN_DATA_DIR.mkdir(parents=True,exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(cfg,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
