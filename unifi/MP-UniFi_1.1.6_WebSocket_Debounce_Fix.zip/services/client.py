from __future__ import annotations
import json,ssl,urllib.request,urllib.error,http.cookiejar,urllib.parse,threading,time
class UniFiError(RuntimeError):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status=status

class UniFiClient:
    def __init__(self,url,username,password,site="default",verify_ssl=False,timeout=8,preferred_mode="",preferred_url=""):
        self.url=str(url or "").rstrip("/"); self.username=str(username or ""); self.password=str(password or "")
        self.site=str(site or "default"); self.timeout=timeout; self.os=True; self.logged_in=False
        self.preferred_mode=str(preferred_mode or "")
        self.preferred_url=str(preferred_url or "").rstrip("/")
        self.detected_mode=""
        self.detected_url=""
        self.ws_app=None
        self.ws_thread=None
        self.ws_connected=False
        self.ws_error=""
        self.ws_last_message=0
        self.ws_url=""
        self.ws_http_status=""
        self.ws_cookie_present=False
        self.ws_lock=threading.RLock()
        self.ws_generation=0
        self.ws_stop_requested=False
        ctx=ssl.create_default_context() if verify_ssl else ssl._create_unverified_context()
        self.jar=http.cookiejar.CookieJar()
        self.opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar),urllib.request.HTTPSHandler(context=ctx))
    def req(self,path,method="GET",data=None):
        body=json.dumps(data).encode() if data is not None else None
        r=urllib.request.Request(self.url+path,data=body,method=method,headers={"Accept":"application/json","Content-Type":"application/json"})
        try:
            with self.opener.open(r,timeout=self.timeout) as x:
                raw=x.read().decode("utf-8",errors="replace"); return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as e:
            detail=e.read().decode("utf-8",errors="replace")
            raise UniFiError(f"HTTP {e.code}: {detail[:500]}", status=e.code) from e
        except Exception as e: raise UniFiError(str(e)) from e
    def _try_login(self, base_url, endpoint, is_os):
        old_url=self.url
        self.url=str(base_url).rstrip("/")
        try:
            # Match ioBroker.unifi-network: UniFi OS uses rememberMe.
            payload={"username":self.username,"password":self.password,"rememberMe":True}
            self.req(endpoint,"POST",payload)
            self.os=bool(is_os)
            self.logged_in=True
            return True
        except Exception:
            self.url=old_url
            raise

    def login(self):
        parsed=urllib.parse.urlsplit(self.url)
        host=parsed.hostname or ""
        configured=self.url.rstrip("/")
        os_base=f"https://{host}"

        # Once a mode has worked, use only that endpoint. No fallback storm.
        if self.preferred_mode=="unifi_os" and self.preferred_url:
            self._try_login(self.preferred_url,"/api/auth/login",True)
            self.detected_mode="unifi_os"; self.detected_url=self.preferred_url
            return
        if self.preferred_mode=="classic" and self.preferred_url:
            self._try_login(self.preferred_url,"/api/login",False)
            self.detected_mode="classic"; self.detected_url=self.preferred_url
            return

        # Auto-detection. A 401/403/429 is a real auth response: stop immediately
        # instead of trying more login endpoints with the same credentials.
        attempts=[]
        if parsed.port:
            attempts.append(("classic",configured,"/api/login",False))
        attempts.append(("unifi_os",os_base,"/api/auth/login",True))
        if not parsed.port:
            attempts.append(("classic",configured,"/api/login",False))

        errors=[]
        for mode,base,endpoint,is_os in attempts:
            try:
                self._try_login(base,endpoint,is_os)
                self.detected_mode=mode; self.detected_url=base
                return
            except UniFiError as exc:
                errors.append(f"{mode} {base}{endpoint}: {exc}")
                if exc.status in (401,403,429):
                    raise UniFiError("Anmeldung fehlgeschlagen: "+errors[-1],status=exc.status)
            except Exception as exc:
                errors.append(f"{mode} {base}{endpoint}: {exc}")
        raise UniFiError("Anmeldung fehlgeschlagen: "+" | ".join(errors))

    def path(self,suffix):
        prefix="/proxy/network" if self.os else ""
        return f"{prefix}/api/s/{urllib.parse.quote(self.site)}/{suffix}"
    def _cookie_header(self):
        parts=[]
        for c in self.jar:
            parts.append(f"{c.name}={c.value}")
        return "; ".join(parts)

    def stop_events(self, join_timeout=5.0):
        with self.ws_lock:
            self.ws_stop_requested=True
            self.ws_generation += 1
            app=self.ws_app
            thread=self.ws_thread
            self.ws_app=None
            self.ws_connected=False
        if app is not None:
            try: app.close()
            except Exception: pass
        if thread is not None and thread.is_alive() and thread is not threading.current_thread():
            try: thread.join(timeout=join_timeout)
            except Exception: pass
        with self.ws_lock:
            if self.ws_thread is thread and (thread is None or not thread.is_alive()):
                self.ws_thread=None
            self.ws_stop_requested=False

    def events_alive(self):
        with self.ws_lock:
            return bool(self.ws_app is not None and self.ws_thread is not None and self.ws_thread.is_alive())

    def start_events(self,on_event,on_state=None):
        with self.ws_lock:
            if self.ws_thread is not None and self.ws_thread.is_alive():
                return True
            self.ws_app=None
            self.ws_thread=None
            self.ws_stop_requested=False
            self.ws_generation += 1
            generation=self.ws_generation

        try:
            import websocket
        except Exception as exc:
            self.ws_error=f"websocket-client fehlt: {exc}"
            return False

        base=self.url.rstrip("/")
        wsbase=("wss://"+base.split("://",1)[1]) if "://" in base else ("wss://"+base)
        prefix="/proxy/network" if self.os else ""
        url=f"{wsbase}{prefix}/wss/s/{urllib.parse.quote(self.site)}/events?clients=v2&next_ai_notifications=true&critical_notifications=true"
        cookie=self._cookie_header()
        self.ws_url=url
        self.ws_cookie_present=bool(cookie)
        self.ws_http_status=""

        def current():
            with self.ws_lock:
                return generation == self.ws_generation and not self.ws_stop_requested

        def state(connected,error="",http_status=""):
            if not current(): return
            self.ws_connected=bool(connected)
            self.ws_error=str(error or "")
            if http_status not in (None,""): self.ws_http_status=str(http_status)
            if on_state:
                try:on_state(self.ws_connected,self.ws_error)
                except Exception:pass

        def on_open(ws):
            if not current():
                try: ws.close()
                except Exception: pass
                return
            state(True,"")

        def on_message(ws,message):
            if not current(): return
            self.ws_last_message=int(time.time())
            try: payload=json.loads(message) if isinstance(message,(str,bytes,bytearray)) else message
            except Exception: payload=message
            try:on_event(payload)
            except Exception:pass

        def on_error(ws,error):
            if not current(): return
            text=str(error); status=""
            import re
            m=re.search(r"\\b(401|403|404|429|500|502|503)\\b",text)
            if m: status=m.group(1)
            state(False,text,status)

        def on_close(ws,code,msg):
            if current(): state(False,f"close {code or ''} {msg or ''}".strip())

        headers=["User-Agent: MP-UniFi/1.1.6"]
        if cookie: headers.append("Cookie: "+cookie)
        app=websocket.WebSocketApp(url,header=headers,on_open=on_open,on_message=on_message,on_error=on_error,on_close=on_close)

        def runner():
            try:
                app.run_forever(sslopt={"cert_reqs": ssl.CERT_NONE},ping_interval=30,ping_timeout=10)
            except Exception as exc:
                if current(): state(False,str(exc))
            finally:
                with self.ws_lock:
                    if generation == self.ws_generation:
                        self.ws_connected=False
                        if self.ws_app is app: self.ws_app=None
                        if self.ws_thread is threading.current_thread(): self.ws_thread=None

        thread=threading.Thread(target=runner,daemon=True,name=f"mp-unifi-events-{generation}")
        with self.ws_lock:
            if self.ws_thread is not None and self.ws_thread.is_alive():
                return True
            self.ws_app=app
            self.ws_thread=thread
        thread.start()
        return True

    def websocket_status(self):
        return {
            "connected": bool(self.ws_connected),
            "error": str(self.ws_error or ""),
            "url": str(self.ws_url or ""),
            "http_status": str(self.ws_http_status or ""),
            "cookie_present": bool(self.ws_cookie_present),
            "last_message": int(self.ws_last_message or 0),
        }

    def clients(self):
        if not self.logged_in:
            self.login()
        try:
            a=self.req(self.path("stat/sta")); active=a.get("data",[]) if isinstance(a,dict) else []
        except UniFiError as exc:
            if exc.status in (401,403):
                self.logged_in=False
            raise
        try:k=self.req(self.path("stat/alluser")); known=k.get("data",[]) if isinstance(k,dict) else []
        except Exception:known=[]
        by={}
        for r in known:
            if isinstance(r,dict) and r.get("mac"):by[str(r["mac"]).lower()]=dict(r)
        for r in active:
            if isinstance(r,dict) and r.get("mac"):
                mac=str(r["mac"]).lower(); old=by.get(mac,{}); old.update(r); old["_active"]=True; by[mac]=old
        for r in by.values():r.setdefault("_active",False)
        return list(by.values())
