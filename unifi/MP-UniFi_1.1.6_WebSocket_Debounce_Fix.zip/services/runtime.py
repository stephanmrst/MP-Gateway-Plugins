from __future__ import annotations
import threading,datetime,time,socket,urllib.parse
from .client import UniFiClient
from .config import save_config
class UniFiRuntime:
    def __init__(self,load_config,logger,on_value=None):
        self.load_config=load_config;self.logger=logger;self.on_value=on_value;self.lock=threading.RLock();self.stop_evt=threading.Event();self.thread=None;self.clients={};self.status={};self.client=None;self.client_sig=None;self.retry_after=0;self.auth_latched=False;self.was_connected=False;self.outage_since=0;self.refresh_evt=threading.Event();self.realtime_connected=False;self.realtime_error="";self.realtime_events=0;self.ws_refresh_pending=False;self.last_ws_refresh=0.0;self.ws_refresh_min_interval=2.0
    def start(self):
        if self.thread and self.thread.is_alive():return
        self.stop_evt.clear();self.thread=threading.Thread(target=self._run,daemon=True,name="mp-unifi-runtime");self.thread.start()
    def stop(self):
        self.stop_evt.set()
        if self.client is not None:
            try:self.client.stop_events()
            except Exception:pass
    def reload(self,cfg=None):
        # Config save is an explicit user action: allow exactly one fresh login.
        if self.client is not None:
            try:self.client.stop_events()
            except Exception:pass
        self.client=None
        self.client_sig=None
        self.retry_after=0
        self.realtime_connected=False
        self.realtime_error=""
        self.auth_latched=False
        self.stop_evt.set()
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=1.5)
        self.stop_evt=threading.Event()
        self.thread=None
        self.start()
    def manual_retry(self):
        self.auth_latched=False
        self.retry_after=0
        self.client=None
        self.client_sig=None
        with self.lock:
            self.status["error"]=""
            self.status["retry_in"]=0
            self.status["manual_retry_required"]=False

    def snapshot(self):
        with self.lock:
            status=dict(self.status)
            ws=self.client.websocket_status() if self.client is not None and hasattr(self.client,"websocket_status") else {}
            status.update({
                "realtime_connected":bool(self.realtime_connected),
                "realtime_error":self.realtime_error or ws.get("error",""),
                "realtime_events":int(self.realtime_events),
                "realtime_url":ws.get("url",""),
                "realtime_http_status":ws.get("http_status",""),
                "realtime_cookie_present":bool(ws.get("cookie_present",False)),
                "realtime_last_message":ws.get("last_message",0),
            })
            return {"status":status,"devices":[dict(x) for x in self.clients.values()]}
    @staticmethod
    def normalize(r):
        mac=str(r.get("mac") or "").lower()
        return {"name":str(r.get("name") or r.get("hostname") or mac or "Unbekannt"),"mac":mac,"ip":str(r.get("ip") or r.get("last_ip") or ""),"online":bool(r.get("_active")),"connection":"LAN" if r.get("is_wired") else "WLAN","ssid":str(r.get("essid") or ""),"ap":str(r.get("ap_name") or r.get("ap_mac") or r.get("sw_mac") or ""),"rssi":r.get("rssi") if r.get("rssi") is not None else r.get("signal"),"last_seen":int(r.get("last_seen") or 0)}
    def _on_ws_event(self,payload):
        # UniFi can emit large event bursts. Never translate every event into
        # a complete REST client refresh.
        self.realtime_events+=1
        self.ws_refresh_pending=True
        self.refresh_evt.set()

    def _on_ws_state(self,connected,error=""):
        self.realtime_connected=bool(connected)
        self.realtime_error=str(error or "")

    def _controller_reachable(self,c):
        try:
            u=urllib.parse.urlsplit(str(c.get("url") or ""))
            host=u.hostname
            if not host:return False
            port=443 if c.get("detected_mode")=="unifi_os" else (u.port or 443)
            with socket.create_connection((host,port),timeout=2):
                return True
        except Exception:
            return False

    def _run(self):
        while not self.stop_evt.is_set():
            cfg=self.load_config();c=cfg.get("controller") or {};wait=max(2,float(c.get("poll_interval",60) or 60))
            if not cfg.get("enabled",True):
                self.client=None; self.client_sig=None
                self.stop_evt.wait(wait); continue
            # Never touch UniFi until the user has actually configured credentials.
            if not str(c.get("url") or "").strip() or not str(c.get("username") or "").strip() or not str(c.get("password") or "").strip():
                self.client=None
                self.client_sig=None
                self.auth_latched=False
                self.retry_after=0
                with self.lock:
                    self.status={
                        "connected":False,
                        "error":"",
                        "updated_at":datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
                        "count":len(self.clients),
                        "not_configured":True,
                        "retry_in":0,
                    }
                self.stop_evt.wait(wait)
                continue

            now_epoch=time.time()
            if self.auth_latched:
                with self.lock:
                    self.status["connected"]=False
                    self.status["manual_retry_required"]=True
                    self.status["retry_in"]=0
                self.stop_evt.wait(wait)
                continue
            if self.retry_after and now_epoch < self.retry_after:
                remaining=max(1,int(self.retry_after-now_epoch))
                with self.lock:
                    self.status["connected"]=False
                    self.status["retry_in"]=remaining
                self.stop_evt.wait(min(wait,remaining)); continue

            sig=(str(c.get("url") or ""),str(c.get("username") or ""),str(c.get("password") or ""),str(c.get("site","default") or "default"),bool(c.get("verify_ssl",False)))
            if self.outage_since:
                if not self._controller_reachable(c):
                    with self.lock:
                        self.status["connected"]=False
                        self.status["error"]="UniFi Controller noch nicht erreichbar"
                        self.status["reconnect_state"]="warte_auf_controller"
                    self.stop_evt.wait(10)
                    continue
                if time.time()-self.outage_since < 60:
                    remain=max(1,int(60-(time.time()-self.outage_since)))
                    with self.lock:
                        self.status["connected"]=False
                        self.status["error"]="UniFi wieder erreichbar – warte auf vollständigen Start"
                        self.status["retry_in"]=remain
                        self.status["reconnect_state"]="boot_grace"
                    self.stop_evt.wait(min(10,remain))
                    continue
                self.outage_since=0
                self.client=None
                self.client_sig=None
            if self.client is None or self.client_sig != sig:
                if self.client is not None:
                    try:self.client.stop_events()
                    except Exception:pass
                self.client=UniFiClient(c.get("url"),c.get("username"),c.get("password"),c.get("site","default"),bool(c.get("verify_ssl",False)),preferred_mode=c.get("detected_mode",""),preferred_url=c.get("detected_url",""))
                self.client_sig=sig

            try:
                # Debounce websocket-triggered full refreshes. Safety polling
                # still happens normally, but realtime bursts can cause at most
                # one /stat/sta request every ws_refresh_min_interval seconds.
                now_mono=time.monotonic()
                if self.ws_refresh_pending and (now_mono-self.last_ws_refresh) < self.ws_refresh_min_interval:
                    wait_for=max(0.05,self.ws_refresh_min_interval-(now_mono-self.last_ws_refresh))
                    self.stop_evt.wait(min(wait_for,0.5))
                    continue

                rows=[self.normalize(x) for x in self.client.clients()]
                self.last_ws_refresh=time.monotonic()
                self.ws_refresh_pending=False
                rows=[x for x in rows if x["mac"]]
                # Persist the endpoint that actually authenticated successfully.
                if self.client.detected_mode and (c.get("detected_mode")!=self.client.detected_mode or c.get("detected_url")!=self.client.detected_url):
                    cfg["controller"]["detected_mode"]=self.client.detected_mode
                    cfg["controller"]["detected_url"]=self.client.detected_url
                    save_config(cfg)
                now=datetime.datetime.now().astimezone().isoformat(timespec="seconds")
                with self.lock:
                    self.clients={x["mac"]:x for x in rows}
                    self.status={"connected":True,"error":"","updated_at":now,"count":len(rows),"retry_in":0}
                self.retry_after=0
                self.was_connected=True
                self.outage_since=0
                # WebSocket reuses the authenticated session; no additional login.
                if self.client is not None and not self.client.events_alive():
                    self.client.start_events(self._on_ws_event,self._on_ws_state)
                if self.on_value:
                    for x in rows:
                        for field in ("online","ip","connection","ssid","ap","rssi","last_seen"):
                            try:self.on_value(f"{x['mac']}/{field}",x.get(field),now,{"device":x,"field":field})
                            except Exception:self.logger.exception("MP-UniFi live publish failed")
            except Exception as e:
                status=getattr(e,"status",None)
                # Never hammer the controller login endpoint.
                if status==429:
                    delay=0
                    self.auth_latched=True
                elif status in (401,403):
                    delay=120
                    if self.client is not None:
                        try:self.client.stop_events()
                        except Exception:pass
                    self.client=None
                    self.client_sig=None
                elif status is not None and 500 <= int(status) <= 599:
                    # A transient UniFi OS 5xx does not mean the controller
                    # rebooted. Keep the current session/websocket and retry
                    # REST gently after a short pause.
                    delay=15
                else:
                    delay=30
                    if self.was_connected:
                        self.outage_since=time.time()
                        if self.client is not None:
                            try:self.client.stop_events()
                            except Exception:pass
                        self.client=None
                        self.client_sig=None
                self.retry_after=(time.time()+delay) if delay else 0
                with self.lock:
                    self.status={"connected":False,"error":str(e),"updated_at":datetime.datetime.now().astimezone().isoformat(timespec="seconds"),"count":len(self.clients),"retry_in":delay,"manual_retry_required":bool(self.auth_latched)}
            # Safety polling remains, but a realtime event wakes us immediately.
            deadline=time.time()+wait
            while not self.stop_evt.is_set():
                remaining=deadline-time.time()
                if remaining<=0:break
                if self.refresh_evt.wait(min(remaining,1.0)):
                    self.refresh_evt.clear()
                    break

