from __future__ import annotations
def register(app,core,manager):
    from .routes import bp
    from .services.config import load_config
    from .services.runtime import UniFiRuntime
    if bp.name not in app.blueprints:app.register_blueprint(bp)
    svc=core.object_core_service
    def on_value(endpoint,value,timestamp,entry):
        svc.record_live_value("unifi",value,topic=endpoint,source_endpoint=endpoint,timestamp=timestamp,original_source="unifi",route_after_record=True)
    runtime=UniFiRuntime(load_config,app.logger,on_value=on_value);app.extensions["unifi_runtime"]=runtime;runtime.start()
    core.add_log_entry("MP-UniFi Plugin Runtime gestartet")
