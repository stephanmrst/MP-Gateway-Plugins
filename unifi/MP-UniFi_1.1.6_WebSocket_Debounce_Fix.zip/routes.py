from __future__ import annotations
from flask import Blueprint,current_app,request,jsonify,redirect
from .services.config import load_config,save_config
bp=Blueprint("unifi",__name__)
def _core():return current_app.extensions["app_core"]
def _runtime():return current_app.extensions.get("unifi_runtime")
def _e(v):return _core().escape(str(v or ""))
def _ck(v):return "checked" if v else ""

@bp.get("/unifi_settings_embed")
def settings():
    cfg=load_config();c=cfg.get("controller") or {};st=(_runtime().snapshot().get("status") or {}) if _runtime() else {}
    if st.get("not_configured"):
        status="○ nicht konfiguriert"
    else:
        status="● verbunden" if st.get("connected") else "○ getrennt"
        if st.get("error"):status+=" · "+_e(st["error"])
    if st.get("manual_retry_required"):status+=" · automatische Anmeldung gesperrt – bitte manuell verbinden"
    elif st.get("reconnect_state")=="warte_auf_controller":status+=" · warte auf UniFi"
    elif st.get("reconnect_state")=="boot_grace":status+=f" · UniFi startet · Anmeldung in {int(st.get('retry_in',0))} s"
    elif st.get("retry_in"):status+=f" · neuer Versuch in {int(st.get('retry_in'))} s"
    if c.get("detected_mode"):status+=" · API: "+_e(c.get("detected_mode"))+" "+_e(c.get("detected_url"))
    content=f"""<div class="card"><h1>MP-UniFi</h1><p class="small">UniFi Network als Datenquelle. Anwesenheitslogik bleibt im Zielsystem.</p></div>
<form method="post" action="/unifi_save"><div class="card"><h2 class="section-title">Verbindung</h2>
<label><input type="checkbox" name="enabled" {_ck(cfg.get('enabled',True))}> Plugin aktiv</label>
<div style="display:grid;grid-template-columns:2fr 1fr 1fr 110px;gap:12px;margin-top:12px">
<div><label>Controller URL</label><input name="url" value="{_e(c.get('url'))}"></div><div><label>Benutzer</label><input name="username" value="{_e(c.get('username'))}"></div>
<div><label>Passwort</label><input type="password" name="password" value="{_e(c.get('password'))}"></div><div><label>Site</label><input name="site" value="{_e(c.get('site','default'))}"></div>
<div><label>Sicherheits-Polling (s)</label><input name="poll_interval" value="{_e(c.get('poll_interval',60))}"></div><div><label><input type="checkbox" name="verify_ssl" {_ck(c.get('verify_ssl',False))}> SSL-Zertifikat prüfen</label></div></div>
<p><b>Status:</b> {status}</p><p><b>Echtzeit:</b> {"● WebSocket verbunden" if st.get("realtime_connected") else "○ WebSocket getrennt"} · Events: {int(st.get("realtime_events") or 0)}{(" · HTTP "+_e(st.get("realtime_http_status"))) if st.get("realtime_http_status") else ""}{(" · "+_e(st.get("realtime_error"))) if st.get("realtime_error") else ""}</p>
<p class="small"><b>WebSocket URL:</b> {_e(st.get("realtime_url") or "-")} · <b>Session-Cookie:</b> {"vorhanden" if st.get("realtime_cookie_present") else "fehlt"}</p><div class="button-row"><button>Speichern</button><button type="submit" formaction="/unifi_retry" formmethod="post">Jetzt verbinden</button><a class="button-link" href="/unifi_explorer">UniFi Explorer öffnen</a></div></div></form>"""
    return _core().embedded_page("MP-UniFi",content)

@bp.post("/unifi_save")
def save():
    old=load_config();oc=old.get("controller") or {}
    try:poll=max(2,float(request.form.get("poll_interval",60)))
    except:poll=60
    new_url=request.form.get("url","").strip()
    new_user=request.form.get("username","").strip()
    new_site=request.form.get("site","default").strip() or "default"
    same_identity=(new_url==oc.get("url","") and new_user==oc.get("username","") and new_site==oc.get("site","default"))
    cfg={"enabled":"enabled" in request.form,"controller":{"url":new_url,"username":new_user,"password":request.form.get("password","") or oc.get("password",""),"site":new_site,"verify_ssl":"verify_ssl" in request.form,"poll_interval":poll,"detected_mode":oc.get("detected_mode","") if same_identity else "","detected_url":oc.get("detected_url","") if same_identity else ""}}
    save_config(cfg)
    runtime=_runtime()
    if runtime is not None:
        runtime.reload(cfg)
    _core().add_log_entry("MP-UniFi Konfiguration gespeichert")
    return redirect("/unifi_settings_embed")

@bp.post("/unifi_retry")
def retry():
    runtime=_runtime()
    if runtime is not None:
        runtime.manual_retry()
    return redirect("/unifi_settings_embed")

@bp.get("/api/unifi/discovery")
def discovery():return jsonify(_runtime().snapshot() if _runtime() else {"devices":[],"status":{"connected":False,"error":"Runtime fehlt"}})

@bp.get("/unifi_explorer")
def explorer():
    content=r"""
<style>.us{height:calc(100vh - 118px);min-height:620px;display:flex;flex-direction:column;gap:14px;overflow:hidden}.ug{min-height:0;flex:1;display:grid;grid-template-columns:minmax(330px,38%) minmax(0,1fr);gap:14px;overflow:hidden}.ul,.ud{min-height:0;height:100%;overflow:hidden;display:flex;flex-direction:column}.ui,.usc{min-height:0;flex:1;overflow:auto}.dev{width:100%;text-align:left;border:1px solid var(--border-color,#3a414f);border-radius:9px;padding:11px;margin:0 0 8px;background:var(--panel2,#1d212b);color:var(--text,#eef2ff);cursor:pointer}.dev.active{border-color:#2b8a3e}.led{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:8px;background:#e03131}.led.on{background:#2f9e44}.sub{opacity:.65;font-size:.82rem;margin:5px 0 0 18px}.rw{display:grid;grid-template-columns:34px minmax(130px,1fr) minmax(130px,1fr) auto;gap:10px;align-items:center;padding:11px 6px;border-bottom:1px solid rgba(127,127,127,.15)}.val{font-family:monospace;font-weight:700}@media(max-width:850px){.us{height:auto}.ug{grid-template-columns:1fr}}</style>
<div class="us"><div class="card compact-card"><div style="display:flex;justify-content:space-between"><div><h1>UniFi Explorer</h1><p class="small">Clients und Livewerte – Einzelobjekt oder Composite.</p><div class="small"><span id="dot" class="led"></span><b id="status">Runtime wird geprüft …</b></div></div><div class="button-row"><a class="button-link" href="/unifi_settings_embed">Verbindung konfigurieren</a><button id="refresh">Aktualisieren</button></div></div></div><div class="ug"><div class="card ul"><h2 class="section-title">Clients</h2><input id="search" placeholder="Client suchen …">
<div style="display:flex;gap:6px;align-items:center;margin-top:8px;flex-wrap:wrap"><span class="small">Sortieren:</span><button id="sort-name" type="button">Name ↕</button><button id="sort-ip" type="button">IP ↕</button><button id="sort-online" type="button">Online ↕</button></div>
<div id="list" class="ui" style="margin-top:12px"></div></div><div class="card ud"><div id="detail" class="usc"><div style="padding:40px;text-align:center"><h2>Client auswählen</h2></div></div></div></div></div>
<script>(()=>{const $=x=>document.getElementById(x),esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));let devices=[],selected='',selection=new Map(),sortKey='name',sortAsc=true;const nav=url=>{if(window.parent&&window.parent!==window)window.parent.postMessage({type:'mqtt2lox:navigateFrame',url,activeHref:'/objects_v33'},window.location.origin);else location.href=url};const fs=[['online','Online','boolean'],['ip','IP-Adresse','string'],['connection','Verbindung','string'],['ssid','SSID','string'],['ap','Access Point / Switch','string'],['rssi','RSSI','number'],['last_seen','Letzter Kontakt','number']];const ep=(d,k)=>d.mac+'/'+k;const cf=(d,k)=>({key:k,protocol:'unifi',address:ep(d,k),value_path:''});function cu(d,k,n,t){const e=ep(d,k),p=new URLSearchParams({explorer:'unifi',source:'unifi',source_type:'unifi',origin_source:'unifi',name:d.name+' · '+n,suggested_name:d.name+' · '+n,topic:e,source_topic:e,source_endpoint:e,source_address:e,datatype:t,value:String(d[k]??''),explorer_action:'create'});return '/objects_v33/create_from_explorer?'+p}
async function api(u,b=null){const o=b===null?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)},r=await fetch(u,o),j=await r.json().catch(()=>({}));if(!r.ok||j.success===false)throw Error(j.error||`HTTP ${r.status}`);return j}async function comp(){if(!selection.size)return alert('Bitte zuerst Werte auswählen.');const d=devices.find(x=>x.mac===selected),n=prompt('Name des Composite-Objekts:',d?.name||'UniFi Client');if(!n)return;try{const r=await api('/api/objects_v33/composites',{name:n,fields:[...selection.values()]});selection.clear();nav('/objects_v33?selected='+encodeURIComponent(r.id)+'&tab=general')}catch(e){alert(e.message)}}async function append(){if(!selection.size)return alert('Bitte zuerst Werte auswählen.');try{const r=await api('/api/objects_v33/composites'),it=r.items||[];if(!it.length)return alert('Noch kein Composite vorhanden.');const n=Number(prompt('Zu welchem Composite hinzufügen?\\n'+it.map((x,i)=>`${i+1}: ${x.name}`).join('\\n'),'1'));if(!n||!it[n-1])return;await api('/api/objects_v33/composites/'+encodeURIComponent(it[n-1].id)+'/fields',{fields:[...selection.values()]});selection.clear();nav('/objects_v33?selected='+encodeURIComponent(it[n-1].id)+'&tab=general')}catch(e){alert(e.message)}}
function ipn(ip){const p=String(ip||'').split('.').map(Number);return p.length===4&&p.every(Number.isFinite)?(((p[0]*256+p[1])*256+p[2])*256+p[3]):Number.MAX_SAFE_INTEGER}
function sb(){[['name','Name'],['ip','IP'],['online','Online']].forEach(([k,n])=>{const b=$('sort-'+k);if(b)b.textContent=n+(sortKey===k?(sortAsc?' ↑':' ↓'):' ↕')})}
function ss(k){if(sortKey===k)sortAsc=!sortAsc;else{sortKey=k;sortAsc=k!=='online'}sb();rl()}
function rl(){const q=$('search').value.toLowerCase().trim();let v=devices.filter(d=>!q||[d.name,d.mac,d.ip,d.ssid].join(' ').toLowerCase().includes(q));v=[...v].sort((a,b)=>{let c=0;if(sortKey==='ip')c=ipn(a.ip)-ipn(b.ip);else if(sortKey==='online')c=Number(a.online)-Number(b.online);else c=String(a.name||'').localeCompare(String(b.name||''),'de',{numeric:true,sensitivity:'base'});if(!c)c=String(a.name||'').localeCompare(String(b.name||''),'de',{numeric:true,sensitivity:'base'});return sortAsc?c:-c});$('list').innerHTML=v.length?v.map(d=>`<button class="dev ${d.mac===selected?'active':''}" data-id="${esc(d.mac)}"><div><span class="led ${d.online?'on':''}"></span><b>${esc(d.name)}</b></div><div class="sub">${esc(d.ip)} · ${esc(d.mac)} · ${d.online?'online':'offline'}</div></button>`).join(''):'<div class="small">Keine Clients gefunden.</div>';$('list').querySelectorAll('button').forEach(b=>b.onclick=()=>{selected=b.dataset.id;rl();rd()})}function rd(){const d=devices.find(x=>x.mac===selected);if(!d){$('detail').innerHTML='<div style="padding:40px;text-align:center"><h2>Client auswählen</h2></div>';return}$('detail').innerHTML=`<h2>${esc(d.name)}</h2><div class="small">${esc(d.mac)} · ${esc(d.ip)}</div><div class="button-row" style="margin:12px 0"><button id="comp">Composite aus Auswahl</button><button id="append">Zu Composite hinzufügen</button><span class="small">${selection.size} Werte ausgewählt</span></div>${fs.map(([k,n,t])=>`<div class="rw"><input class="pick" data-k="${k}" type="checkbox" ${selection.has(ep(d,k))?'checked':''}><div><b>${n}</b><div class="small">${esc(ep(d,k))}</div></div><div class="val">${esc(d[k])}</div><button class="create" data-k="${k}">Objekt erstellen</button></div>`).join('')}`;$('detail').querySelectorAll('.create').forEach(b=>b.onclick=()=>{const f=fs.find(x=>x[0]===b.dataset.k);nav(cu(d,...f))});$('detail').querySelectorAll('.pick').forEach(x=>x.onchange=()=>{const f=fs.find(y=>y[0]===x.dataset.k),e=ep(d,f[0]);if(x.checked)selection.set(e,cf(d,f[0]));else selection.delete(e);rd()});$('comp').onclick=comp;$('append').onclick=append}async function refresh(){try{const r=await fetch('/api/unifi/discovery',{cache:'no-store'}),j=await r.json();devices=j.devices||[];const st=j.status||{};$('dot').className='led '+(st.connected?'on':'');$('status').textContent=st.connected?`${devices.filter(x=>x.online).length}/${devices.length} Clients online · Echtzeit ${st.realtime_connected?'●':'○'} · Events ${st.realtime_events||0}`:'Getrennt: '+(st.error||'')+(st.manual_retry_required?' · automatische Anmeldung gesperrt':(st.retry_in?` · neuer Versuch in ${st.retry_in}s`:''));if(selected&&!devices.some(x=>x.mac===selected))selected='';rl();rd()}catch(e){$('status').textContent='Runtime nicht erreichbar'}}$('search').oninput=rl;$('sort-name').onclick=()=>ss('name');$('sort-ip').onclick=()=>ss('ip');$('sort-online').onclick=()=>ss('online');sb();$('refresh').onclick=refresh;refresh();setInterval(refresh,2000)})();</script>"""
    return _core().embedded_page("UniFi Explorer",content)
