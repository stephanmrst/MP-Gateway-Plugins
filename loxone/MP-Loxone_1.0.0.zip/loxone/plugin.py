from __future__ import annotations

from dataclasses import dataclass, field
from typing import ClassVar, Any
from flask import Blueprint, current_app, redirect, request
from markupsafe import escape

from app.services.object_adapter_engine import BaseAdapter

@dataclass
class LoxoneAdapter(BaseAdapter):
    protocol: ClassVar[str] = "loxone"
    uuid: str = ""
    io_address: str = ""
    control_type: str = ""
    visu_name: str = ""
    room: str = ""
    unit: str = ""
    source_uuid: str = ""
    source_io: str = ""
    source_name: str = ""
    source_room: str = ""
    source_category: str = ""
    source_enabled: bool = True
    target_uuid: str = ""
    target_name: str = ""
    target_room: str = ""
    target_category: str = ""
    target_type: str = ""
    target_enabled: bool = False
    active: bool = False
    targets: list[dict[str, Any]] = field(default_factory=list)

    @classmethod
    def deserialize(cls, data: dict[str, Any]) -> "LoxoneAdapter":
        payload = dict(data or {})
        payload.setdefault("source_uuid", payload.get("uuid", ""))
        payload.setdefault("source_io", payload.get("source_io", payload.get("io_address", "")))
        payload.setdefault("source_name", payload.get("source_name", payload.get("visu_name", payload.get("name", ""))))
        payload.setdefault("source_room", payload.get("source_room", payload.get("room", "")))
        payload.setdefault("source_category", payload.get("source_category", payload.get("control_type", payload.get("category", payload.get("type", "")))))
        if "source_enabled" not in payload and any(str(payload.get(f, "") or "").strip() for f in ("source_uuid","source_io","source_name","uuid","io_address","visu_name")):
            payload["source_enabled"] = payload.get("enabled", True)

        raw = payload.get("targets") if isinstance(payload.get("targets"), list) else []
        targets = []
        for i, target in enumerate(raw):
            if not isinstance(target, dict):
                continue
            uuid = str(target.get("uuid") or target.get("target_uuid") or "").strip()
            if not uuid:
                continue
            targets.append({
                "id": str(target.get("id") or f"loxone_target_{i+1}"),
                "enabled": bool(target.get("enabled", True)),
                "uuid": uuid,
                "name": str(target.get("name") or target.get("target_name") or "").strip(),
                "room": str(target.get("room") or target.get("target_room") or "").strip(),
                "category": str(target.get("category") or target.get("target_category") or "").strip(),
                "type": str(target.get("type") or target.get("target_type") or "").strip(),
                "value_path": str(target.get("value_path") or target.get("target_value_path") or "").strip(),
                "color_temp_min": int(target.get("color_temp_min", 153) or 153),
                "color_temp_max": int(target.get("color_temp_max", 454) or 454),
            })
        legacy_uuid = str(payload.get("target_uuid") or "").strip()
        if not targets and legacy_uuid:
            targets.append({
                "id":"loxone_target_1", "enabled": bool(payload.get("target_enabled", payload.get("active", True))),
                "uuid": legacy_uuid, "name": str(payload.get("target_name") or "").strip(),
                "room": str(payload.get("target_room") or payload.get("room") or "").strip(),
                "category": str(payload.get("target_category") or "").strip(),
                "type": str(payload.get("target_type") or payload.get("control_type") or "").strip(),
                "value_path": str(payload.get("target_value_path") or "").strip(),
                "color_temp_min": int(payload.get("color_temp_min", 153) or 153),
                "color_temp_max": int(payload.get("color_temp_max", 454) or 454),
            })
        payload["targets"] = targets
        first = next((t for t in targets if t.get("enabled")), targets[0] if targets else None)
        if first:
            payload["target_uuid"] = first["uuid"]
            payload["target_name"] = first["name"]
            payload["target_room"] = first["room"]
            payload["target_category"] = first["category"]
            payload["target_type"] = first["type"]
            payload["target_enabled"] = bool(first.get("enabled", True))
            payload["target_value_path"] = first.get("value_path", "")
            payload["active"] = bool(payload.get("source_enabled", False) or payload["target_enabled"])
        else:
            payload["target_enabled"] = False
            payload["active"] = bool(payload.get("source_enabled", False))
        adapter = super().deserialize(payload)
        if not adapter.uuid and adapter.source_uuid: adapter.uuid = adapter.source_uuid
        if not adapter.io_address and adapter.source_io: adapter.io_address = adapter.source_io
        if not adapter.visu_name and adapter.source_name: adapter.visu_name = adapter.source_name
        if not adapter.room and adapter.source_room: adapter.room = adapter.source_room
        if not adapter.control_type and adapter.source_category: adapter.control_type = adapter.source_category
        has_enabled_targets = any(bool(t.get("enabled")) for t in adapter.targets)
        adapter.enabled = bool(adapter.source_enabled or has_enabled_targets)
        adapter.direction = "both" if adapter.source_enabled and has_enabled_targets else ("in" if adapter.source_enabled else "out")
        return adapter



bp = Blueprint("plugin_loxone", __name__)


def _core():
    return current_app.extensions["app_core"]


def _settings_content(notice=""):
    core = _core()
    cfg = core.load_config()
    lox = cfg.get("loxone", {})
    return f"""
{notice or ""}
<form method="post" action="/loxone/settings/save">
  <div class="card">
    <h2 class="section-title">Loxone Miniserver</h2>
    <p class="small">Verbindung des MP-Loxone Plugins zum Miniserver.</p>
    <label>IP / Host</label>
    <input name="loxone_host" value="{escape(str(lox.get('host', '')))}">
    <label>Benutzer</label>
    <input name="loxone_user" value="{escape(str(lox.get('user', '')))}">
    <label>Passwort</label>
    <input name="loxone_password" type="password" value="{escape(str(lox.get('password', '')))}">
    <div class="button-row" style="margin-top:14px;">
      <button type="submit">Speichern</button>
      <button type="submit" formaction="/loxone/settings/test" formmethod="post">Loxone testen</button>
    </div>
  </div>
</form>
<div class="card">
  <h2 class="section-title">Runtime</h2>
  <p class="small">Phase 1 der Plugin-Migration: Explorer, Einstellungen, Source und Objektadapter liegen bereits im Plugin. Die bewährte WebSocket-/Bridge-Runtime bleibt für diesen Teststand noch unverändert im Core.</p>
</div>
"""


@bp.route("/topics2")
def topics2_page():
    return _core().topics2_page()


@bp.route("/topics2/data")
def topics2_data():
    return _core().topics2_data()


@bp.route("/topics2/save", methods=["POST"])
def topics2_save():
    return _core().topics2_save()


@bp.route("/loxone_settings_embed")
def loxone_settings_embed():
    return _core().embedded_page("Loxone", _settings_content())


@bp.route("/loxone/settings/save", methods=["POST"])
def loxone_settings_save():
    core = _core()
    cfg = core.load_config()
    cfg["loxone"] = {
        "host": request.form.get("loxone_host", cfg.get("loxone", {}).get("host", "")),
        "user": request.form.get("loxone_user", cfg.get("loxone", {}).get("user", "")),
        "password": request.form.get("loxone_password", cfg.get("loxone", {}).get("password", "")),
    }
    core.save_config(cfg)
    core.add_log_entry("MP-Loxone Konfiguration gespeichert")
    core.restart_bridge_async()
    return redirect("/loxone_settings_embed")


@bp.route("/loxone/settings/test", methods=["POST"])
def loxone_settings_test():
    core = _core()
    try:
        cfg = core.load_config()
        cfg["loxone"] = {
            "host": request.form.get("loxone_host", cfg.get("loxone", {}).get("host", "")),
            "user": request.form.get("loxone_user", cfg.get("loxone", {}).get("user", "")),
            "password": request.form.get("loxone_password", cfg.get("loxone", {}).get("password", "")),
        }
        data = core.load_mapping(cfg)
        project = data.get("msInfo", {}).get("projectName", "unbekannt")
        controls = len(data.get("controls", {}))
        notice = f'<div class="card ok">✅ Loxone OK<br>Projekt: {escape(str(project))}<br>Controls: {controls}</div>'
        return core.embedded_page("Loxone", _settings_content(notice))
    except Exception as exc:
        notice = f'<div class="card bad">❌ Loxone Fehler: {escape(str(exc))}</div>'
        return core.embedded_page("Loxone", _settings_content(notice))


# Historical mapping URLs remain harmless and lead to the object manager.
@bp.route("/mqtt2lox")
@bp.route("/mqtt2lox/save", methods=["GET", "POST"])
def legacy_mqtt2lox():
    return redirect("/objects_v33")


def register_adapter():
    from app.services.object_adapter_engine import register_adapter as reg
    reg(LoxoneAdapter, template_name="objects_v33/adapters/loxone.html")


def register(app, core, manager):
    if bp.name not in app.blueprints:
        app.register_blueprint(bp)
