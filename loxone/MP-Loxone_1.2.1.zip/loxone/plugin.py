from __future__ import annotations

from dataclasses import dataclass, field
from typing import ClassVar, Any
from flask import Blueprint, current_app, redirect, request
from markupsafe import escape

from app.services.object_adapter_engine import BaseAdapter

@dataclass
class LoxoneAdapter(BaseAdapter):
    protocol: ClassVar[str] = "loxone"
    uuid: str = ""
    io_address: str = ""
    control_type: str = ""
    visu_name: str = ""
    room: str = ""
    unit: str = ""
    source_uuid: str = ""
    source_io: str = ""
    source_name: str = ""
    source_room: str = ""
    source_category: str = ""
    source_enabled: bool = True
    target_uuid: str = ""
    target_name: str = ""
    target_room: str = ""
    target_category: str = ""
    target_type: str = ""
    target_enabled: bool = False
    active: bool = False
    targets: list[dict[str, Any]] = field(default_factory=list)

    @classmethod
    def deserialize(cls, data: dict[str, Any]) -> "LoxoneAdapter":
        payload = dict(data or {})
        payload.setdefault("source_uuid", payload.get("uuid", ""))
        payload.setdefault("source_io", payload.get("source_io", payload.get("io_address", "")))
        payload.setdefault("source_name", payload.get("source_name", payload.get("visu_name", payload.get("name", ""))))
        payload.setdefault("source_room", payload.get("source_room", payload.get("room", "")))
        payload.setdefault("source_category", payload.get("source_category", payload.get("control_type", payload.get("category", payload.get("type", "")))))
        if "source_enabled" not in payload and any(str(payload.get(f, "") or "").strip() for f in ("source_uuid","source_io","source_name","uuid","io_address","visu_name")):
            payload["source_enabled"] = payload.get("enabled", True)

        raw = payload.get("targets") if isinstance(payload.get("targets"), list) else []
        targets = []
        for i, target in enumerate(raw):
            if not isinstance(target, dict):
                continue
            uuid = str(target.get("uuid") or target.get("target_uuid") or "").strip()
            if not uuid:
                continue
            targets.append({
                "id": str(target.get("id") or f"loxone_target_{i+1}"),
                "enabled": bool(target.get("enabled", True)),
                "uuid": uuid,
                "name": str(target.get("name") or target.get("target_name") or "").strip(),
                "room": str(target.get("room") or target.get("target_room") or "").strip(),
                "category": str(target.get("category") or target.get("target_category") or "").strip(),
                "type": str(target.get("type") or target.get("target_type") or "").strip(),
                "value_path": str(target.get("value_path") or target.get("target_value_path") or "").strip(),
                "color_temp_min": int(target.get("color_temp_min", 153) or 153),
                "color_temp_max": int(target.get("color_temp_max", 454) or 454),
            })
        legacy_uuid = str(payload.get("target_uuid") or "").strip()
        if not targets and legacy_uuid:
            targets.append({
                "id":"loxone_target_1", "enabled": bool(payload.get("target_enabled", payload.get("active", True))),
                "uuid": legacy_uuid, "name": str(payload.get("target_name") or "").strip(),
                "room": str(payload.get("target_room") or payload.get("room") or "").strip(),
                "category": str(payload.get("target_category") or "").strip(),
                "type": str(payload.get("target_type") or payload.get("control_type") or "").strip(),
                "value_path": str(payload.get("target_value_path") or "").strip(),
                "color_temp_min": int(payload.get("color_temp_min", 153) or 153),
                "color_temp_max": int(payload.get("color_temp_max", 454) or 454),
            })
        payload["targets"] = targets
        first = next((t for t in targets if t.get("enabled")), targets[0] if targets else None)
        if first:
            payload["target_uuid"] = first["uuid"]
            payload["target_name"] = first["name"]
            payload["target_room"] = first["room"]
            payload["target_category"] = first["category"]
            payload["target_type"] = first["type"]
            payload["target_enabled"] = bool(first.get("enabled", True))
            payload["target_value_path"] = first.get("value_path", "")
            payload["active"] = bool(payload.get("source_enabled", False) or payload["target_enabled"])
        else:
            payload["target_enabled"] = False
            payload["active"] = bool(payload.get("source_enabled", False))
        adapter = super().deserialize(payload)
        if not adapter.uuid and adapter.source_uuid: adapter.uuid = adapter.source_uuid
        if not adapter.io_address and adapter.source_io: adapter.io_address = adapter.source_io
        if not adapter.visu_name and adapter.source_name: adapter.visu_name = adapter.source_name
        if not adapter.room and adapter.source_room: adapter.room = adapter.source_room
        if not adapter.control_type and adapter.source_category: adapter.control_type = adapter.source_category
        has_enabled_targets = any(bool(t.get("enabled")) for t in adapter.targets)
        adapter.enabled = bool(adapter.source_enabled or has_enabled_targets)
        adapter.direction = "both" if adapter.source_enabled and has_enabled_targets else ("in" if adapter.source_enabled else "out")
        return adapter



bp = Blueprint("plugin_loxone", __name__)


def _core():
    return current_app.extensions["app_core"]


def _settings_content(notice=""):
    core = _core()
    cfg = core.load_config()
    lox = cfg.get("loxone", {})
    return f"""
{notice or ""}
<form method="post" action="/loxone/settings/save">
  <div class="card">
    <h2 class="section-title">Loxone Miniserver</h2>
    <p class="small">Verbindung des MP-Loxone Plugins zum Miniserver.</p>
    <label>IP / Host</label>
    <input name="loxone_host" value="{escape(str(lox.get('host', '')))}">
    <label>Benutzer</label>
    <input name="loxone_user" value="{escape(str(lox.get('user', '')))}">
    <label>Passwort</label>
    <input name="loxone_password" type="password" value="{escape(str(lox.get('password', '')))}">
    <div class="button-row" style="margin-top:14px;">
      <button type="submit">Speichern</button>
      <button type="submit" formaction="/loxone/settings/test" formmethod="post">Loxone testen</button>
    </div>
  </div>
</form>
<div class="card">
  <h2 class="section-title">Runtime</h2>
  <p class="small">MP-Loxone besitzt jetzt auch die Runtime-Freigabe. Deaktiviert oder gelöscht bedeutet nach dem Neustart: keine Loxone-Verbindung, kein RX und kein TX; die übrigen MP-Gateway Protokolle laufen weiter.</p>
</div>
"""


@bp.route("/topics2")
def topics2_page():
    return _core().topics2_page()


@bp.route("/topics2/data")
def topics2_data():
    return _core().topics2_data()


@bp.route("/topics2/save", methods=["POST"])
def topics2_save():
    return _core().topics2_save()


@bp.route("/loxone_settings_embed")
def loxone_settings_embed():
    return _core().embedded_page("Loxone", _settings_content())


@bp.route("/loxone/settings/save", methods=["POST"])
def loxone_settings_save():
    core = _core()
    cfg = core.load_config()
    cfg["loxone"] = {
        "host": request.form.get("loxone_host", cfg.get("loxone", {}).get("host", "")),
        "user": request.form.get("loxone_user", cfg.get("loxone", {}).get("user", "")),
        "password": request.form.get("loxone_password", cfg.get("loxone", {}).get("password", "")),
    }
    core.save_config(cfg)
    core.add_log_entry("MP-Loxone Konfiguration gespeichert")
    core.restart_bridge_async()
    return redirect("/loxone_settings_embed")


@bp.route("/loxone/settings/test", methods=["POST"])
def loxone_settings_test():
    core = _core()
    try:
        cfg = core.load_config()
        cfg["loxone"] = {
            "host": request.form.get("loxone_host", cfg.get("loxone", {}).get("host", "")),
            "user": request.form.get("loxone_user", cfg.get("loxone", {}).get("user", "")),
            "password": request.form.get("loxone_password", cfg.get("loxone", {}).get("password", "")),
        }
        data = core.load_mapping(cfg)
        project = data.get("msInfo", {}).get("projectName", "unbekannt")
        controls = len(data.get("controls", {}))
        notice = f'<div class="card ok">✅ Loxone OK<br>Projekt: {escape(str(project))}<br>Controls: {controls}</div>'
        return core.embedded_page("Loxone", _settings_content(notice))
    except Exception as exc:
        notice = f'<div class="card bad">❌ Loxone Fehler: {escape(str(exc))}</div>'
        return core.embedded_page("Loxone", _settings_content(notice))


# Historical mapping URLs remain harmless and lead to the object manager.
@bp.route("/mqtt2lox")
@bp.route("/mqtt2lox/save", methods=["GET", "POST"])
def legacy_mqtt2lox():
    return redirect("/objects_v33")



def _target_handler_factory(core):
    def _handler(item, target_adapter, value, original_source, source_ref, route_entry, metadata):
        raw_targets = core._adapter_targets(target_adapter)
        if not raw_targets:
            legacy_uuid = str(
                getattr(target_adapter, "target_uuid", "")
                or getattr(target_adapter, "io_address", "")
                or getattr(target_adapter, "uuid", "")
                or ""
            ).strip()
            if legacy_uuid:
                raw_targets = [{
                    "enabled": True,
                    "uuid": legacy_uuid,
                    "value_path": getattr(target_adapter, "target_value_path", ""),
                }]
        sent = False
        for cfg in raw_targets:
            loxone_io = str(cfg.get("uuid") or "").strip()
            if not loxone_io:
                continue
            target_value = core._target_value_or_skip(item, "loxone", value, cfg.get("value_path", ""))
            if target_value is core._VALUE_PATH_MISSING:
                continue
            if core.loxone_service.send_loxone_value(
                core.load_config(), loxone_io, target_value, core.add_log_entry, core.requests
            ):
                sent = True
        return sent
    return _handler


def _runtime_status(core):
    enabled = core.plugin_protocol_enabled("loxone")
    bridge_thread = getattr(core.runtime_context.bridge, "thread", None)
    bridge_alive = bool(bridge_thread is not None and bridge_thread.is_alive())
    websocket_present = bool(getattr(core, "ws", None) is not None)
    loop_present = bool(getattr(core, "main_loop", None) is not None)
    connected = bool(enabled and bridge_alive and websocket_present and loop_present)
    return {
        "enabled": enabled,
        "connected": connected,
        "connection": "connected" if connected else ("waiting" if enabled else "disabled"),
        "bridge_alive": bridge_alive,
        "websocket_present": websocket_present,
        "loop_present": loop_present,
    }


def _runtime_start(core):
    core.add_log_entry("MP-Loxone lifecycle start() - Transport wartet auf zentralen Gateway-Start")
    # IMPORTANT: A protocol plugin must never restart the shared gateway bridge
    # from its start hook. Plugin activation happens before the one central
    # bridge autostart, preventing duplicate bridge/websocket runtimes.
    return True


def _runtime_stop(core):
    core.add_log_entry("MP-Loxone lifecycle stop()")
    # Current plugin enable/disable model is restart based. This hook exists now
    # so future live disable can close the transport without changing the API.
    return True


def _runtime_send_factory(core):
    handler = _target_handler_factory(core)
    def _send(item, target_adapter, value, original_source="", source_ref="", route_entry=None, metadata=None):
        return handler(item, target_adapter, value, original_source, source_ref, route_entry or {}, metadata or {})
    return _send

def register_adapter():
    from app.services.object_adapter_engine import register_adapter as reg
    reg(LoxoneAdapter, template_name="objects_v33/adapters/loxone.html")


def register(app, core, manager):
    if bp.name not in app.blueprints:
        app.register_blueprint(bp)

    from app.plugins.runtime import registry
    runtime = registry.register(
        "loxone",
        start=lambda: _runtime_start(core),
        stop=lambda: _runtime_stop(core),
        status=lambda: _runtime_status(core),
        send=_runtime_send_factory(core),
    )

    def _generic_target(item, target_adapter, value, original_source, source_ref, route_entry, metadata):
        return runtime.send(item, target_adapter, value, original_source, source_ref, route_entry, metadata)

    core.register_plugin_target_handler("loxone", _generic_target)
    core.add_log_entry("MP-Loxone an generischer Plugin-Runtime-API registriert")
