"""HomeKit bridge runtime for MP-Gateway.

MP-HomeKit 1.0.0 is based on the 36.7.21 clean rebuild based on the independently verified HAP-python
minimal bridge.  It intentionally avoids protocol monkey patches, custom
event delivery, connection watchdogs and compatibility heartbeats.
"""

from __future__ import annotations

import ipaddress
import colorsys
import math
import json
import logging
import socket
import threading
import time
from typing import Any
from types import SimpleNamespace

from plugins.homekit.services.config import HOMEKIT_STATE_FILE, load_homekit_config
from app.services import object_service as object_service_module
from app.services import loxone as loxone_service

LOGGER = logging.getLogger(__name__)

try:
    from pyhap.accessory import Accessory, Bridge
    from pyhap.accessory_driver import AccessoryDriver
    from pyhap.const import CATEGORY_LIGHTBULB, CATEGORY_SENSOR, CATEGORY_SWITCH
    PYHAP_AVAILABLE = True
    PYHAP_ERROR = ""
except Exception as exc:
    Accessory = object
    Bridge = object
    AccessoryDriver = None
    CATEGORY_LIGHTBULB = 5
    CATEGORY_SENSOR = 10
    CATEGORY_SWITCH = 8
    PYHAP_AVAILABLE = False
    PYHAP_ERROR = str(exc)


def _valid_ipv4(value: str) -> bool:
    try:
        ip = ipaddress.ip_address(str(value or "").strip())
        return ip.version == 4 and not ip.is_loopback and not ip.is_unspecified
    except Exception:
        return False


def _detect_lan_ipv4() -> str:
    for destination in (("1.1.1.1", 80), ("192.0.2.1", 80)):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.connect(destination)
            candidate = str(sock.getsockname()[0] or "").strip()
            if _valid_ipv4(candidate):
                return candidate
        except OSError:
            pass
        finally:
            sock.close()
    return ""


def _as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return float(value) != 0.0
    text = str(value or "").strip().lower()
    if text in {"true", "on", "yes", "ja", "ein", "active", "aktiv"}:
        return True
    if text in {"false", "off", "no", "nein", "aus", "inactive", "inaktiv", ""}:
        return False
    try:
        return float(text.replace(",", ".")) != 0.0
    except (TypeError, ValueError):
        return False


def _as_number(value: Any, default=0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _parse_path(path: str):
    path = str(path or "").strip()
    if not path:
        return []
    tokens = []
    buf = ""
    index = 0
    while index < len(path):
        char = path[index]
        if char == ".":
            if buf:
                tokens.append(buf)
                buf = ""
            index += 1
            continue
        if char == "[":
            if buf:
                tokens.append(buf)
                buf = ""
            end = path.find("]", index + 1)
            if end < 0:
                return []
            raw = path[index + 1:end].strip()
            try:
                tokens.append(int(raw))
            except ValueError:
                return []
            index = end + 1
            continue
        buf += char
        index += 1
    if buf:
        tokens.append(buf)
    return tokens



def _as_mapping(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return dict(value)
    if isinstance(value, str):
        text = value.strip()
        if text.startswith("{"):
            try:
                parsed = json.loads(text)
                if isinstance(parsed, dict):
                    return parsed
            except Exception:
                pass
    return {}


def _map_first(data: dict[str, Any], *keys, default=None):
    lowered = {str(k).lower(): v for k, v in dict(data or {}).items()}
    for key in keys:
        if str(key).lower() in lowered:
            return lowered[str(key).lower()]
    return default


def _mired_to_kelvin(mired: Any) -> int:
    try:
        m = max(100.0, min(500.0, float(mired)))
        return max(2000, min(10000, round(1000000.0 / m)))
    except Exception:
        return 4000


def _kelvin_to_mired(kelvin: Any) -> int:
    try:
        k = max(2000.0, min(10000.0, float(kelvin)))
        return max(100, min(500, round(1000000.0 / k)))
    except Exception:
        return 250



def _mired_to_hs_approx(mired):
    """Approximate CT as Hue/Saturation for stable HS-only HomeKit profile."""
    try:
        m = max(140.0, min(500.0, float(mired)))
    except Exception:
        m = 250.0
    kelvin = max(2000.0, min(7143.0, 1000000.0 / m))
    temp = kelvin / 100.0
    if temp <= 66:
        r = 255.0
        g = 99.4708025861 * math.log(max(temp, 1.0)) - 161.1195681661
        b = 0.0 if temp <= 19 else 138.5177312231 * math.log(max(temp - 10.0, 1.0)) - 305.0447927307
    else:
        r = 329.698727446 * ((temp - 60.0) ** -0.1332047592)
        g = 288.1221695283 * ((temp - 60.0) ** -0.0755148492)
        b = 255.0
    r=max(0.0,min(255.0,r))/255.0
    g=max(0.0,min(255.0,g))/255.0
    b=max(0.0,min(255.0,b))/255.0
    h,s,_=colorsys.rgb_to_hsv(r,g,b)
    return round(h*360.0,1), round(s*100.0,1)

def _decode_loxone_lumitech(value: Any) -> dict[str, Any]:
    try:
        number = int(round(float(str(value).strip().replace(",", "."))))
    except Exception:
        return {"on": False, "brightness": 0, "hue": 0.0, "saturation": 0.0, "color_temp": 250, "color_model": "off"}

    if number <= 0:
        return {"on": False, "brightness": 0, "hue": 0.0, "saturation": 0.0, "color_temp": 250, "color_model": "off"}

    if number >= 200000000:
        encoded = number - 200000000
        brightness = max(0, min(100, encoded // 10000))
        kelvin = encoded % 10000
        return {
            "on": brightness > 0,
            "brightness": brightness,
            "hue": 0.0,
            "saturation": 0.0,
            "color_temp": _kelvin_to_mired(kelvin),
            "color_model": "temperature",
        }

    blue = max(0, min(100, number // 1000000))
    rest = number - blue * 1000000
    green = max(0, min(100, rest // 1000))
    red = max(0, min(100, rest - green * 1000))
    r, g, b = red / 100.0, green / 100.0, blue / 100.0
    h, sat, val = colorsys.rgb_to_hsv(r, g, b)
    return {
        "on": max(red, green, blue) > 0,
        "brightness": round(val * 100),
        "hue": round(h * 360.0, 1),
        "saturation": round(sat * 100.0, 1),
        "color_temp": 250,
        "color_model": "rgb",
    }


def _encode_loxone_rgb(hue: Any, saturation: Any, brightness: Any) -> int:
    h = (float(hue or 0.0) % 360.0) / 360.0
    s = max(0.0, min(100.0, float(saturation or 0.0))) / 100.0
    v = max(0.0, min(100.0, float(brightness or 0.0))) / 100.0
    r, g, b = colorsys.hsv_to_rgb(h, s, v)
    rp, gp, bp = (round(r * 100), round(g * 100), round(b * 100))
    return int(rp + gp * 1000 + bp * 1000000)


def _encode_loxone_white(brightness: Any, color_temp_mired: Any) -> int:
    bri = max(0, min(100, round(float(brightness or 0))))
    if bri <= 0:
        return 0
    kelvin = _mired_to_kelvin(color_temp_mired)
    return int(200000000 + bri * 10000 + kelvin)


def _extract_path(value: Any, path: str):
    if not path:
        return value
    if isinstance(value, str):
        import json
        try:
            value = json.loads(value)
        except Exception:
            return None
    current = value
    for token in _parse_path(path):
        if isinstance(token, int):
            if not isinstance(current, list) or token < 0 or token >= len(current):
                return None
            current = current[token]
        else:
            if not isinstance(current, dict) or token not in current:
                return None
            current = current[token]
    return current


class _ObjectAccessoryBase(Accessory):
    category = CATEGORY_SENSOR

    def __init__(self, driver, display_name, runtime, object_id,
                 writable=True, value_path="", aid=None, adapter=None):
        super().__init__(driver, display_name, aid=aid)
        self.runtime = runtime
        self.object_id = object_id
        self.writable = bool(writable)
        self.value_path = str(value_path or "").strip()
        self.adapter = adapter
        self._syncing = False
        self._immediate_push_count = 0
        self._last_hap_prepare_perf = None
        self._last_hap_publish_perf = None

        endpoint_id = str(getattr(adapter, "id", "") or "").replace("-", "")
        identity_tag = str(getattr(adapter, "identity_tag", "") or "").replace("-", "")
        is_primary_endpoint = bool(getattr(adapter, "is_primary_endpoint", False))
        serial_base = str(object_id or "").replace("-", "")

        # Preserve the proven legacy serial only for unchanged endpoint 1.
        # As soon as its HomeKit service type changes, identity_tag is set and
        # Apple receives a genuinely new accessory identity instead of reusing
        # the previous RGB/Switch service tree.
        if is_primary_endpoint and not identity_tag:
            serial = serial_base[:64] or f"mpg-{aid or 0}"
        else:
            suffix = identity_tag or endpoint_id or str(aid or 0)
            serial = f"{serial_base}-{suffix}"[:64] or f"mpg-{aid or 0}"
        self.homekit_serial_number = serial
        self.set_info_service(
            manufacturer="MP-Gateway",
            model="MP-Gateway Object",
            serial_number=serial,
            firmware_revision="1.0.0",
        )

    def current_value(self):
        value = self.runtime.read_object_value(self.object_id)
        return _extract_path(value, self.value_path)

    def write_value(self, value):
        if self.writable:
            endpoint_id = str(getattr(self, "homekit_endpoint_id", "") or getattr(self.adapter, "id", "") or "")
            self.runtime.write_object_value(
                self.object_id,
                value,
                homekit_endpoint_id=endpoint_id,
            )

    def _native_set(self, char, value, force=False):
        """Update a HAP characteristic and push the event immediately.

        HAP-python normally marks only button-style event characteristics as
        immediate. Regular On/Brightness/CurrentTemperature notifications are
        queued/coalesced by the HAP protocol. MP-Gateway already performs its
        own change suppression, so externally sourced object changes can be
        sent directly as immediate HAP events without an extra queue delay.
        """
        try:
            target = char.to_valid_value(value)
        except Exception:
            target = value

        before = getattr(char, "value", None)
        if before == target and not force:
            return False

        latency_hap_prepare_perf = time.perf_counter()

        # Update the characteristic cache without triggering HAP-python's
        # default non-immediate notification path.
        char.set_value(target, should_notify=False)

        # Then publish the exact same characteristic change as an immediate
        # event. Fall back to normal notify if the broker API differs.
        try:
            broker = getattr(char, "broker", None)
            if broker is not None:
                broker.publish(char.value, char, None, True)
                self._immediate_push_count += 1
                self._last_hap_publish_perf = time.perf_counter()
                self._last_hap_prepare_perf = latency_hap_prepare_perf
            else:
                char.notify()
        except Exception:
            self.runtime.logger.exception(
                "HomeKit immediate characteristic publish failed object=%s char=%s",
                self.object_id,
                getattr(char, "_display_name", ""),
            )
            try:
                char.notify()
            except Exception:
                pass
        return True


class ObjectSwitch(_ObjectAccessoryBase):
    category = CATEGORY_SWITCH

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        initial = _as_bool(self.current_value())
        service = self.add_preload_service("Switch")
        try:
            self.set_primary_service(service)
        except Exception:
            pass
        self.char_on = service.configure_char(
            "On",
            value=initial,
            setter_callback=self._set_on if self.writable else None,
        )

    def _set_on(self, value):
        if self._syncing:
            return
        self.write_value(1 if _as_bool(value) else 0)

    def sync_from_object(self):
        raw = self.current_value()
        value = _as_bool(raw)
        self._syncing = True
        try:
            self._native_set(self.char_on, value)
        finally:
            self._syncing = False
        return raw, value


class ObjectLight(_ObjectAccessoryBase):
    category = CATEGORY_LIGHTBULB

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        current = max(0, min(100, round(_as_number(self.current_value(), 0))))
        self._last_nonzero = current if current > 0 else 100
        service = self.add_preload_service("Lightbulb", chars=["Brightness"])
        try:
            self.set_primary_service(service)
        except Exception:
            pass
        self.char_on = service.configure_char(
            "On",
            value=current > 0,
            setter_callback=self._set_on if self.writable else None,
        )
        self.char_brightness = service.configure_char(
            "Brightness",
            value=current,
            setter_callback=self._set_brightness if self.writable else None,
        )

    def _set_on(self, value):
        if self._syncing:
            return
        if _as_bool(value):
            target = self._last_nonzero if self._last_nonzero > 0 else 100
        else:
            target = 0
        self.write_value(target)

    def _set_brightness(self, value):
        if self._syncing:
            return
        target = max(0, min(100, round(_as_number(value, 0))))
        if target > 0:
            self._last_nonzero = target
        self.write_value(target)

    def sync_from_object(self):
        raw = self.current_value()
        value = max(0, min(100, round(_as_number(raw, 0))))
        if value > 0:
            self._last_nonzero = value
        self._syncing = True
        try:
            self._native_set(self.char_on, value > 0)
            self._native_set(self.char_brightness, value)
        finally:
            self._syncing = False
        return raw, value



class ObjectColorLight(_ObjectAccessoryBase):
    category = CATEGORY_LIGHTBULB

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.color_mode = str(getattr(self.adapter, "color_mode", "auto") or "auto").lower()
        self._state = self._read_state()
        self._last_color_model = str(self._state.get("color_model") or "")
        self._ct_to_rgb_transition_count = 0
        self.hs_only_profile = self.color_mode == "loxone_lumitech_hs"
        preload_chars = ["Brightness", "Hue", "Saturation"]
        if not self.hs_only_profile:
            preload_chars.append("ColorTemperature")
        service = self.add_preload_service("Lightbulb", chars=preload_chars)
        try:
            self.set_primary_service(service)
        except Exception:
            pass
        self.char_on = service.configure_char(
            "On",
            value=bool(self._state["on"]),
            setter_callback=self._set_on if self.writable else None,
        )
        self.char_brightness = service.configure_char(
            "Brightness",
            value=int(self._state["brightness"]),
            setter_callback=self._set_brightness if self.writable else None,
        )
        self.char_hue = service.configure_char(
            "Hue",
            value=float(self._state["hue"]),
            setter_callback=self._set_hue if self.writable else None,
        )
        self.char_saturation = service.configure_char(
            "Saturation",
            value=float(self._state["saturation"]),
            setter_callback=self._set_saturation if self.writable else None,
        )
        self.char_color_temp = None
        if not self.hs_only_profile:
            self.char_color_temp = service.configure_char(
                "ColorTemperature",
                value=int(self._state["color_temp"]),
                setter_callback=self._set_color_temp if self.writable else None,
            )

    def _read_state(self):
        raw = self.current_value()
        mode = self.color_mode
        mapping = _as_mapping(raw)
        if mode in {"loxone_lumitech", "loxone_lumitech_hs"} or (mode == "auto" and not mapping):
            state = _decode_loxone_lumitech(raw)
            if mode == "loxone_lumitech_hs" and state.get("color_model") == "temperature":
                # Keep Lumitech white-mode On/Brightness exactly as decoded.
                # Only translate the white color itself into a stable HS color
                # representation for HomeKit.
                hue, saturation = _mired_to_hs_approx(state.get("color_temp", 250))
                state["hue"] = hue
                state["saturation"] = saturation
                state["source_color_model"] = "temperature"
                state["color_model"] = "rgb"
            elif mode == "loxone_lumitech_hs":
                state["source_color_model"] = state.get("color_model")
            return state

        brightness = max(0, min(100, round(_as_number(
            _map_first(mapping, "brightness", "bri", "level", default=0), 0
        ))))
        on = _as_bool(_map_first(mapping, "on", "state", default=brightness > 0))
        hue = max(0.0, min(360.0, _as_number(_map_first(mapping, "hue", "h", default=0), 0)))
        saturation = max(0.0, min(100.0, _as_number(
            _map_first(mapping, "saturation", "sat", "s", default=0), 0
        )))
        ct = _map_first(mapping, "color_temp", "color_temperature", "ct", "mired", default=250)
        ct = max(100, min(500, round(_as_number(ct, 250))))
        return {
            "on": on,
            "brightness": brightness,
            "hue": hue,
            "saturation": saturation,
            "color_temp": ct,
        }

    def _write_state(self, changed="color"):
        state = dict(self._state)
        if not state.get("on"):
            state["brightness"] = 0

        if self.color_mode in {"loxone_lumitech", "loxone_lumitech_hs"} or (
            self.color_mode == "auto" and not _as_mapping(self.current_value())
        ):
            if not state.get("on") or state.get("brightness", 0) <= 0:
                self.write_value(0)
            elif (
                changed == "color_temp"
                or float(state.get("saturation", 0)) <= 0.5
            ):
                # HomeKit HS-only has no ColorTemperature characteristic, but
                # its "white" selection is still represented as saturation≈0.
                # Translate that back to a REAL Loxone Lumitech white-mode
                # number. This is essential: grayscale RGB is not equivalent to
                # Loxone white mode, and Brightness writes made while Home is
                # on the white palette would otherwise stay in RGB semantics.
                encoded = _encode_loxone_white(
                    state.get("brightness", 100),
                    state.get("color_temp", 250),
                )
                try:
                    self.runtime.core.add_log_entry(
                        f"HOMEKIT LUMITECH WRITE object_id={self.object_id} mode=white "
                        f"changed={changed} brightness={int(state.get('brightness', 0))} "
                        f"ct={int(state.get('color_temp', 250))} value={encoded}"
                    )
                except Exception:
                    pass
                self.write_value(encoded)
            else:
                encoded = _encode_loxone_rgb(
                    state.get("hue", 0),
                    state.get("saturation", 0),
                    state.get("brightness", 100),
                )
                try:
                    self.runtime.core.add_log_entry(
                        f"HOMEKIT LUMITECH WRITE object_id={self.object_id} mode=rgb "
                        f"changed={changed} brightness={int(state.get('brightness', 0))} "
                        f"hue={float(state.get('hue', 0)):.1f} "
                        f"sat={float(state.get('saturation', 0)):.1f} value={encoded}"
                    )
                except Exception:
                    pass
                self.write_value(encoded)
            return

        payload = {
            "state": "ON" if state.get("on") else "OFF",
            "on": bool(state.get("on")),
            "brightness": int(state.get("brightness", 0)),
            "hue": float(state.get("hue", 0.0)),
            "saturation": float(state.get("saturation", 0.0)),
            "color_temp": int(state.get("color_temp", 250)),
        }
        self.write_value(payload)

    def _set_on(self, value):
        if self._syncing:
            return
        self._state["on"] = _as_bool(value)
        if self._state["on"] and self._state.get("brightness", 0) <= 0:
            self._state["brightness"] = 100
        self._write_state("on")

    def _set_brightness(self, value):
        if self._syncing:
            return
        bri = max(0, min(100, round(_as_number(value, 0))))
        self._state["brightness"] = bri
        self._state["on"] = bri > 0
        self._write_state("brightness")

    def _set_hue(self, value):
        if self._syncing:
            return
        self._state["hue"] = max(0.0, min(360.0, _as_number(value, 0)))
        self._state["on"] = True
        # Keep the current saturation as the authoritative mode hint. Home
        # often sends Hue and Saturation as separate writes.
        self._last_color_model = (
            "temperature" if float(self._state.get("saturation", 0)) <= 0.5 else "rgb"
        )
        self._write_state("color")

    def _set_saturation(self, value):
        if self._syncing:
            return
        saturation = max(0.0, min(100.0, _as_number(value, 0)))
        self._state["saturation"] = saturation
        self._state["on"] = True
        self._last_color_model = "temperature" if saturation <= 0.5 else "rgb"
        self._write_state("color")

    def _set_color_temp(self, value):
        if self.hs_only_profile or self._syncing:
            return
        self._state["color_temp"] = max(100, min(500, round(_as_number(value, 250))))
        self._state["saturation"] = 0.0
        self._state["on"] = True
        self._last_color_model = "temperature"
        self._write_state("color_temp")

    def sync_from_object(self):
        raw = self.current_value()
        state = self._read_state()
        self._state.update(state)
        self._last_source_color_model = str(
            state.get("source_color_model") or state.get("color_model") or ""
        )

        if self.hs_only_profile:
            source_model = str(state.get("source_color_model") or state.get("color_model") or "")
            self._syncing = True
            try:
                # HS-only has no ColorTemperature characteristic. Therefore
                # every source update must explicitly publish all four visible
                # HomeKit characteristics. In particular Brightness and On are
                # forced during Lumitech white mode so they cannot be suppressed
                # by a stale local HAP cache.
                self._native_set(self.char_hue, float(state["hue"]), force=True)
                self._native_set(self.char_saturation, float(state["saturation"]), force=True)
                self._native_set(self.char_brightness, int(state["brightness"]), force=True)
                self._native_set(self.char_on, bool(state["on"]), force=True)
            finally:
                self._syncing = False

            self._last_color_model = "rgb"
            try:
                self.runtime.core.add_log_entry(
                    f"HOMEKIT HS-ONLY SYNC object_id={self.object_id} "
                    f"source_model={source_model or '-'} "
                    f"brightness={int(state['brightness'])} on={bool(state['on'])} "
                    f"hue={float(state['hue']):.1f} sat={float(state['saturation']):.1f}"
                )
            except Exception:
                pass

            result = dict(state)
            result.pop("color_model", None)
            result["profile"] = "lumitech_hs_only_v3"
            result["source_color_model"] = source_model
            result["identity_tag"] = str(getattr(self.adapter, "identity_tag", "") or "")
            return raw, result

        is_lumitech = self.color_mode == "loxone_lumitech" or (
            self.color_mode == "auto" and not _as_mapping(raw)
        )
        color_model = state.get("color_model") if is_lumitech else None
        previous_model = str(self._last_color_model or "")

        self._syncing = True
        try:
            if is_lumitech and color_model == "rgb":
                self._native_set(self.char_hue, float(state["hue"]), force=True)
                self._native_set(self.char_saturation, float(state["saturation"]), force=True)
                self._native_set(self.char_brightness, int(state["brightness"]))
                self._native_set(self.char_on, bool(state["on"]))
                if previous_model == "temperature":
                    self._ct_to_rgb_transition_count += 1
                self._last_color_model = "rgb"
            elif is_lumitech and color_model == "temperature":
                if self.char_color_temp is not None:
                    self._native_set(self.char_color_temp, int(state["color_temp"]), force=True)
                self._native_set(self.char_brightness, int(state["brightness"]))
                self._native_set(self.char_on, bool(state["on"]))
                self._last_color_model = "temperature"
            elif is_lumitech and color_model == "off":
                self._native_set(self.char_brightness, 0)
                self._native_set(self.char_on, False)
            else:
                self._native_set(self.char_on, bool(state["on"]))
                self._native_set(self.char_brightness, int(state["brightness"]))
                self._native_set(self.char_hue, float(state["hue"]))
                self._native_set(self.char_saturation, float(state["saturation"]))
                if self.char_color_temp is not None:
                    self._native_set(self.char_color_temp, int(state["color_temp"]))
        finally:
            self._syncing = False
        result = dict(state)
        result.pop("color_model", None)
        return raw, result


class _ReadOnlySensorBase(_ObjectAccessoryBase):
    category = CATEGORY_SENSOR

    def __init__(self, *args, **kwargs):
        kwargs["writable"] = False
        super().__init__(*args, **kwargs)
        self.sensor_invert = bool(getattr(self.adapter, "sensor_invert", False))


class _BoolSensorBase(_ReadOnlySensorBase):
    SERVICE_NAME = ""
    CHARACTERISTIC_NAME = ""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        active = _as_bool(self.current_value())
        if self.sensor_invert:
            active = not active
        service = self.add_preload_service(self.SERVICE_NAME)
        try:
            self.set_primary_service(service)
        except Exception:
            pass
        self.char_value = service.configure_char(
            self.CHARACTERISTIC_NAME,
            value=1 if active else 0,
        )

    def sync_from_object(self):
        raw = self.current_value()
        active = _as_bool(raw)
        if self.sensor_invert:
            active = not active
        value = 1 if active else 0
        self._native_set(self.char_value, value)
        return raw, value



class ObjectAirQuality(_ReadOnlySensorBase):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs); st=self._state()
        svc=self.add_preload_service("AirQualitySensor")
        try:self.set_primary_service(svc)
        except Exception:pass
        self.c_quality=svc.configure_char("AirQuality",value=st["quality"])
    def _state(self):
        raw=self.current_value(); d=_as_mapping(raw)
        q=int(max(0,min(5,round(_as_number(_map_first(d,"airquality","quality","aqi",default=raw if not d else 0),0)))))
        return {"quality":q}
    def sync_from_object(self):
        raw=self.current_value(); st=self._state(); self._native_set(self.c_quality,st["quality"]); return raw,st


class ObjectCarbonDioxide(_ReadOnlySensorBase):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs); st=self._state()
        svc=self.add_preload_service("CarbonDioxideSensor",chars=["CarbonDioxideLevel","CarbonDioxidePeakLevel"])
        try:self.set_primary_service(svc)
        except Exception:pass
        self.c_det=svc.configure_char("CarbonDioxideDetected",value=st["detected"])
        self.c_lvl=svc.configure_char("CarbonDioxideLevel",value=st["level"])
        self.c_peak=svc.configure_char("CarbonDioxidePeakLevel",value=st["peak"])
    def _state(self):
        raw=self.current_value(); d=_as_mapping(raw)
        if d:
            lvl=max(0.0,_as_number(_map_first(d,"co2","co2level","level",default=0),0))
            peak=max(lvl,_as_number(_map_first(d,"peak","co2peak",default=lvl),lvl))
            det=1 if _as_bool(_map_first(d,"detected","co2detected",default=False)) else 0
        else: lvl=max(0.0,_as_number(raw,0)); peak=lvl; det=0
        return {"detected":det,"level":lvl,"peak":peak}
    def sync_from_object(self):
        raw=self.current_value(); st=self._state()
        self._native_set(self.c_det,st["detected"]); self._native_set(self.c_lvl,st["level"]); self._native_set(self.c_peak,st["peak"])
        return raw,st


class ObjectCarbonMonoxide(_BoolSensorBase):
    SERVICE_NAME="CarbonMonoxideSensor"; CHARACTERISTIC_NAME="CarbonMonoxideDetected"


class ObjectContact(_ReadOnlySensorBase):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        active = _as_bool(self.current_value())
        if self.sensor_invert:
            active = not active
        service = self.add_preload_service("ContactSensor")
        try:
            self.set_primary_service(service)
        except Exception:
            pass
        self.char_value = service.configure_char("ContactSensorState", value=1 if active else 0)

    def sync_from_object(self):
        raw = self.current_value()
        active = _as_bool(raw)
        if self.sensor_invert:
            active = not active
        # HomeKit: 0 = contact detected/closed, 1 = contact not detected/open.
        value = 1 if active else 0
        self._native_set(self.char_value, value)
        return raw, value


class ObjectFan(_ObjectAccessoryBase):
    category=CATEGORY_SWITCH
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs); self.st=self._state(); svc=self.add_preload_service("Fanv2",chars=["RotationSpeed"])
        try:self.set_primary_service(svc)
        except Exception:pass
        self.c_active=svc.configure_char("Active",value=1 if self.st["active"] else 0,setter_callback=self._set_active if self.writable else None)
        self.c_speed=svc.configure_char("RotationSpeed",value=self.st["speed"],setter_callback=self._set_speed if self.writable else None)
    def _state(self):
        raw=self.current_value(); d=_as_mapping(raw)
        if d:
            speed=max(0,min(100,round(_as_number(_map_first(d,"speed","rotationspeed","level",default=0),0))))
            active=_as_bool(_map_first(d,"active","on","state",default=speed>0))
        else: speed=max(0,min(100,round(_as_number(raw,0)))); active=speed>0
        return {"active":active,"speed":speed}
    def _write(self):
        if _as_mapping(self.current_value()):self.write_value({"active":bool(self.st["active"]),"speed":int(self.st["speed"])})
        else:self.write_value(int(self.st["speed"]) if self.st["active"] else 0)
    def _set_active(self,v):
        if self._syncing:return
        self.st["active"]=_as_bool(v)
        if self.st["active"] and self.st["speed"]<=0:self.st["speed"]=100
        self._write()
    def _set_speed(self,v):
        if self._syncing:return
        self.st["speed"]=max(0,min(100,round(_as_number(v,0)))); self.st["active"]=self.st["speed"]>0; self._write()
    def sync_from_object(self):
        raw=self.current_value(); self.st=self._state(); self._syncing=True
        try:self._native_set(self.c_active,1 if self.st["active"] else 0); self._native_set(self.c_speed,self.st["speed"])
        finally:self._syncing=False
        return raw,dict(self.st)


class ObjectGarageDoor(_ObjectAccessoryBase):
    category=CATEGORY_SWITCH
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs); st=self._state(); svc=self.add_preload_service("GarageDoorOpener")
        try:self.set_primary_service(svc)
        except Exception:pass
        self.c_cur=svc.configure_char("CurrentDoorState",value=st["current"])
        self.c_tgt=svc.configure_char("TargetDoorState",value=st["target"],setter_callback=self._set if self.writable else None)
        self.c_obs=svc.configure_char("ObstructionDetected",value=st["obstruction"])
    def _state(self):
        raw=self.current_value(); d=_as_mapping(raw)
        if d:
            cur=int(max(0,min(4,round(_as_number(_map_first(d,"current","currentdoorstate",default=1),1)))))
            tgt=int(max(0,min(1,round(_as_number(_map_first(d,"target","targetdoorstate",default=1),1)))))
            obs=_as_bool(_map_first(d,"obstruction","obstructiondetected",default=False))
        else: opened=_as_bool(raw); cur=0 if opened else 1; tgt=cur; obs=False
        return {"current":cur,"target":tgt,"obstruction":obs}
    def _set(self,v):
        if self._syncing:return
        tgt=int(max(0,min(1,round(_as_number(v,1)))))
        if _as_mapping(self.current_value()):self.write_value({"target":tgt})
        else:self.write_value(1 if tgt==0 else 0)
    def sync_from_object(self):
        raw=self.current_value(); st=self._state(); self._syncing=True
        try:self._native_set(self.c_cur,st["current"]); self._native_set(self.c_tgt,st["target"]); self._native_set(self.c_obs,st["obstruction"])
        finally:self._syncing=False
        return raw,st


class ObjectHumidity(_ReadOnlySensorBase):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        value = max(0.0, min(100.0, _as_number(self.current_value(), 0.0)))
        service = self.add_preload_service("HumiditySensor")
        try:
            self.set_primary_service(service)
        except Exception:
            pass
        self.char_value = service.configure_char("CurrentRelativeHumidity", value=value)

    def sync_from_object(self):
        raw = self.current_value()
        value = max(0.0, min(100.0, _as_number(raw, self.char_value.value)))
        self._native_set(self.char_value, value)
        return raw, value


class ObjectLeak(_BoolSensorBase):
    SERVICE_NAME="LeakSensor"; CHARACTERISTIC_NAME="LeakDetected"


class ObjectLock(_ObjectAccessoryBase):
    category=CATEGORY_SWITCH
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs); val=1 if _as_bool(self.current_value()) else 0; svc=self.add_preload_service("LockMechanism")
        try:self.set_primary_service(svc)
        except Exception:pass
        self.c_cur=svc.configure_char("LockCurrentState",value=val)
        self.c_tgt=svc.configure_char("LockTargetState",value=val,setter_callback=self._set if self.writable else None)
    def _set(self,v):
        if not self._syncing:self.write_value(1 if int(_as_number(v,0))==1 else 0)
    def sync_from_object(self):
        raw=self.current_value(); val=1 if _as_bool(raw) else 0; self._syncing=True
        try:self._native_set(self.c_cur,val); self._native_set(self.c_tgt,val)
        finally:self._syncing=False
        return raw,val


class ObjectLux(_ReadOnlySensorBase):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        value = max(0.0001, min(100000.0, _as_number(self.current_value(), 0.0001)))
        service = self.add_preload_service("LightSensor")
        try:
            self.set_primary_service(service)
        except Exception:
            pass
        self.char_value = service.configure_char("CurrentAmbientLightLevel", value=value)

    def sync_from_object(self):
        raw = self.current_value()
        value = max(0.0001, min(100000.0, _as_number(raw, self.char_value.value)))
        self._native_set(self.char_value, value)
        return raw, value


class ObjectMotion(_ReadOnlySensorBase):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        active = _as_bool(self.current_value())
        if self.sensor_invert:
            active = not active
        service = self.add_preload_service("MotionSensor")
        try:
            self.set_primary_service(service)
        except Exception:
            pass
        self.char_value = service.configure_char("MotionDetected", value=active)

    def sync_from_object(self):
        raw = self.current_value()
        active = _as_bool(raw)
        if self.sensor_invert:
            active = not active
        self._native_set(self.char_value, active)
        return raw, active


class ObjectOccupancy(_BoolSensorBase):
    SERVICE_NAME="OccupancySensor"; CHARACTERISTIC_NAME="OccupancyDetected"


class ObjectOutlet(_ObjectAccessoryBase):
    category=CATEGORY_SWITCH
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs); on=_as_bool(self.current_value()); svc=self.add_preload_service("Outlet")
        try:self.set_primary_service(svc)
        except Exception:pass
        self.c_on=svc.configure_char("On",value=on,setter_callback=self._set if self.writable else None)
        try:self.c_use=svc.configure_char("OutletInUse",value=on)
        except Exception:self.c_use=None
    def _set(self,v):
        if not self._syncing:self.write_value(1 if _as_bool(v) else 0)
    def sync_from_object(self):
        raw=self.current_value(); on=_as_bool(raw); self._syncing=True
        try:
            self._native_set(self.c_on,on)
            if self.c_use is not None:self._native_set(self.c_use,on)
        finally:self._syncing=False
        return raw,on


class ObjectSmoke(_BoolSensorBase):
    SERVICE_NAME="SmokeSensor"; CHARACTERISTIC_NAME="SmokeDetected"


class ObjectThermostat(_ObjectAccessoryBase):
    category=CATEGORY_SENSOR
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs); st=self._state(); svc=self.add_preload_service("Thermostat",chars=["CurrentHeatingCoolingState","TargetHeatingCoolingState","TargetTemperature","TemperatureDisplayUnits"])
        try:self.set_primary_service(svc)
        except Exception:pass
        self.c_cur_t=svc.configure_char("CurrentTemperature",value=st["current_temperature"])
        self.c_tgt_t=svc.configure_char("TargetTemperature",value=st["target_temperature"],setter_callback=self._set_temp if self.writable else None)
        self.c_cur_s=svc.configure_char("CurrentHeatingCoolingState",value=st["current_state"])
        self.c_tgt_s=svc.configure_char("TargetHeatingCoolingState",value=st["target_state"],setter_callback=self._set_state if self.writable else None)
        self.c_units=svc.configure_char("TemperatureDisplayUnits",value=0)
    def _state(self):
        raw=self.current_value(); d=_as_mapping(raw)
        if d:
            cur=max(-100,min(100,_as_number(_map_first(d,"current_temperature","current","temperature",default=20),20)))
            tgt=max(5,min(35,_as_number(_map_first(d,"target_temperature","target","setpoint",default=cur),cur)))
            cs=int(max(0,min(2,round(_as_number(_map_first(d,"current_state","currentheatingcoolingstate",default=0),0)))))
            ts=int(max(0,min(3,round(_as_number(_map_first(d,"target_state","targetheatingcoolingstate","mode",default=0),0)))))
        else: cur=max(-100,min(100,_as_number(raw,20))); tgt=cur; cs=0; ts=0
        return {"current_temperature":cur,"target_temperature":tgt,"current_state":cs,"target_state":ts}
    def _patch(self,**patch):
        d=_as_mapping(self.current_value())
        if d:d.update(patch); self.write_value(d)
        elif "target_temperature" in patch:self.write_value(patch["target_temperature"])
    def _set_temp(self,v):
        if not self._syncing:self._patch(target_temperature=max(5,min(35,_as_number(v,20))))
    def _set_state(self,v):
        if not self._syncing:self._patch(target_state=int(max(0,min(3,round(_as_number(v,0))))))
    def sync_from_object(self):
        raw=self.current_value(); st=self._state(); self._syncing=True
        try:self._native_set(self.c_cur_t,st["current_temperature"]); self._native_set(self.c_tgt_t,st["target_temperature"]); self._native_set(self.c_cur_s,st["current_state"]); self._native_set(self.c_tgt_s,st["target_state"])
        finally:self._syncing=False
        return raw,st


class ObjectValve(_ObjectAccessoryBase):
    category=CATEGORY_SWITCH
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs); active=_as_bool(self.current_value()); svc=self.add_preload_service("Valve",chars=["InUse","ValveType"])
        try:self.set_primary_service(svc)
        except Exception:pass
        self.c_active=svc.configure_char("Active",value=1 if active else 0,setter_callback=self._set if self.writable else None)
        self.c_use=svc.configure_char("InUse",value=1 if active else 0); self.c_type=svc.configure_char("ValveType",value=0)
    def _set(self,v):
        if not self._syncing:self.write_value(1 if _as_bool(v) else 0)
    def sync_from_object(self):
        raw=self.current_value(); a=_as_bool(raw); self._syncing=True
        try:self._native_set(self.c_active,1 if a else 0); self._native_set(self.c_use,1 if a else 0)
        finally:self._syncing=False
        return raw,a


class ObjectWindowCovering(_ObjectAccessoryBase):
    category=CATEGORY_SWITCH
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs); st=self._state(); svc=self.add_preload_service("WindowCovering")
        try:self.set_primary_service(svc)
        except Exception:pass
        self.c_cur=svc.configure_char("CurrentPosition",value=st["current"])
        self.c_tgt=svc.configure_char("TargetPosition",value=st["target"],setter_callback=self._set if self.writable else None)
        self.c_state=svc.configure_char("PositionState",value=st["position_state"])
    def _state(self):
        raw=self.current_value(); d=_as_mapping(raw)
        if d:
            cur=max(0,min(100,round(_as_number(_map_first(d,"current","currentposition","position",default=0),0))))
            tgt=max(0,min(100,round(_as_number(_map_first(d,"target","targetposition",default=cur),cur))))
            state=int(max(0,min(2,round(_as_number(_map_first(d,"positionstate","state",default=2),2)))))
        else: cur=max(0,min(100,round(_as_number(raw,0)))); tgt=cur; state=2
        return {"current":cur,"target":tgt,"position_state":state}
    def _set(self,v):
        if self._syncing:return
        tgt=max(0,min(100,round(_as_number(v,0))))
        if _as_mapping(self.current_value()):self.write_value({"target":tgt})
        else:self.write_value(tgt)
    def sync_from_object(self):
        raw=self.current_value(); st=self._state(); self._syncing=True
        try:self._native_set(self.c_cur,st["current"]); self._native_set(self.c_tgt,st["target"]); self._native_set(self.c_state,st["position_state"])
        finally:self._syncing=False
        return raw,st


class ObjectTemperature(_ObjectAccessoryBase):
    category = CATEGORY_SENSOR

    def __init__(self, *args, **kwargs):
        kwargs["writable"] = False
        super().__init__(*args, **kwargs)

        raw = self.current_value()
        initial = 0.0 if raw is None else _as_number(raw, 0.0)
        try:
            initial = max(-100.0, min(100.0, float(initial)))
        except Exception:
            initial = 0.0

        service = self.add_preload_service("TemperatureSensor")
        try:
            self.set_primary_service(service)
        except Exception:
            pass

        self.char_temp = service.configure_char(
            "CurrentTemperature",
            value=initial,
        )

    def sync_from_object(self):
        raw = self.current_value()
        if raw is None:
            return raw, self.char_temp.value

        value = _as_number(raw, self.char_temp.value)
        try:
            value = max(-100.0, min(100.0, float(value)))
        except Exception:
            value = float(self.char_temp.value or 0.0)

        self._native_set(self.char_temp, value)
        return raw, value


class HomeKitRuntime:
    def __init__(self, core, logger=None):
        self.core = core
        self.logger = logger or LOGGER
        self.lock = threading.RLock()
        self.driver = None
        self.thread = None
        self.status = "stopped"
        self.last_error = ""
        self.started_at = ""
        self.advertised_ip = ""
        self.listen_address = ""
        self.accessory_count = 0
        # Compatibility invariant from the proven single-endpoint runtime:
        # object_accessories is ALWAYS keyed by MP object_id and contains the
        # primary HomeKit accessory. Multi-endpoints live in separate maps.
        self.object_accessories = {}
        self.endpoint_accessories = {}
        self.object_accessories_by_object = {}
        self.sync_state = {}
        self.last_write = {}
        self.sync_thread = None
        self.sync_stop = threading.Event()
        self.restart_lock = threading.Lock()
        self._live_listener_registered = False

    def read_object_value(self, object_id):
        live = self.core.object_core_service.get_object_live_status(object_id) or {}
        return live.get("value")

    def _write_back_to_configured_source(self, item, value, live_before=None):
        """Write HomeKit changes back to the object's real source.

        Prefer the live source that most recently supplied the object value.
        This is important for Loxone because the live endpoint is the actual
        /dev/sps/io path we must write back to. Fall back to persisted adapter
        configuration only if live metadata is not usable.
        """
        live_before = dict(live_before or {})
        live_source = str(live_before.get("source") or "").strip().lower()
        live_endpoint = str(
            live_before.get("source_address")
            or live_before.get("endpoint")
            or ""
        ).strip()

        # First choice: the source that actually produced the live object value.
        if live_source == "loxone" and live_endpoint:
            ok = bool(loxone_service.send_loxone_value(
                self.core.load_config(),
                live_endpoint,
                value,
                self.core.add_log_entry,
                self.core.requests,
            ))
            return {
                "sent": ok,
                "protocol": "loxone",
                "endpoint": live_endpoint,
                "resolution": "live-source",
            }

        adapters = self.core._object_adapter_map(item)

        # Loxone fallback. Do not require source_enabled here: old/imported
        # objects can have a valid source IO while that legacy flag is false.
        loxone = adapters.get("loxone")
        if loxone is not None:
            io_value = str(
                getattr(loxone, "source_io", "")
                or getattr(loxone, "io_address", "")
                or getattr(loxone, "source_name", "")
                or ""
            ).strip()
            if io_value:
                ok = bool(loxone_service.send_loxone_value(
                    self.core.load_config(),
                    io_value,
                    value,
                    self.core.add_log_entry,
                    self.core.requests,
                ))
                return {
                    "sent": ok,
                    "protocol": "loxone",
                    "endpoint": io_value,
                    "resolution": "adapter-fallback",
                }

        mqtt = adapters.get("mqtt")
        if mqtt is not None:
            direction = str(getattr(mqtt, "direction", "") or "").lower()
            topic = str(getattr(mqtt, "topic", "") or "").strip()
            if topic and direction in {"in", "both"}:
                broker = str(
                    getattr(mqtt, "source_broker", "") or "Hauptbroker"
                ).strip() or "Hauptbroker"
                payload = (
                    "true" if value is True
                    else "false" if value is False
                    else str(value)
                )
                ok = bool(self.core.mqtt_module.publish(
                    topic, payload, broker_name=broker
                ))
                return {
                    "sent": ok,
                    "protocol": "mqtt",
                    "endpoint": f"{broker}:{topic}",
                    "resolution": "adapter-fallback",
                }

        knx = adapters.get("knx")
        if knx is not None and bool(getattr(knx, "source_enabled", False)):
            ga = str(
                getattr(knx, "source_group_address", "")
                or getattr(knx, "group_address", "")
                or ""
            ).strip()
            dpt = str(
                getattr(knx, "source_dpt", "")
                or getattr(knx, "dpt", "")
                or ""
            ).strip()
            if ga and dpt:
                ok = bool(self.core.knx_service.send_knx_value(
                    ga,
                    dpt,
                    value,
                    self.core.load_knx_config,
                    self.core.add_log_entry,
                    add_monitor_entry=self.core.add_knx_monitor_entry,
                ))
                return {
                    "sent": ok,
                    "protocol": "knx",
                    "endpoint": f"{ga} ({dpt})",
                    "resolution": "adapter-fallback",
                }

        return {
            "sent": False,
            "protocol": "",
            "endpoint": "",
            "resolution": "none",
            "error": (
                "Kein beschreibbarer Quell-Endpunkt gefunden "
                f"(live source={live_source!r}, endpoint={live_endpoint!r})"
            ),
        }

    def write_object_value(self, object_id, value, homekit_endpoint_id=""):
        """HomeKit is a normal MP-Gateway object source.

        Apple Home changes the live object value with source=homekit.
        The existing object router then distributes it to the object's
        configured targets. No direct write-back to the previous source.
        """
        item = self.core.object_core_service.get_object(object_id)
        if item is None:
            return False
        try:
            live = self.core.object_core_service.update_object_live_value(
                object_id, value,
                source="homekit",
                endpoint="homekit",
                source_address="Apple Home",
                status="aktiv",
            )
            live_item = {
                "object_id": object_id,
                "object": item.to_dict(),
                "live": live,
            }
            routed = bool(self.core._dispatch_object_routes(
                [live_item],
                "homekit",
                "homekit",
                value,
                metadata={
                    "gateway_origin": "homekit",
                    "use_event_value": True,
                    "homekit_write": True,
                    "homekit_endpoint_id": str(homekit_endpoint_id or ""),
                },
            ))
            self.last_write[object_id] = {
                "sent": routed,
                "protocol": "object-router",
                "endpoint": "configured targets",
                "resolution": "homekit-source",
                "homekit_endpoint_id": str(homekit_endpoint_id or ""),
                "value": value,
                "time": time.strftime("%Y-%m-%d %H:%M:%S"),
            }
            self.core.add_log_entry(
                f"HOMEKIT OBJECT WRITE object_id={object_id} endpoint={homekit_endpoint_id or '-'} value={value!r} "
                f"source=homekit routed={'YES' if routed else 'NO'}"
            )
            return routed
        except Exception as exc:
            self.last_error = str(exc)
            self.logger.exception("HomeKit object write failed object=%s", object_id)
            return False

    def _homekit_adapter_for_object(self, item):
        try:
            adapters = self.core._object_adapter_map(item)
            return adapters.get("homekit")
        except Exception:
            return None


    def _ensure_homekit_endpoint_aid(self, item, adapter, endpoint, used_aids, hk_type):
        """Use the stable identity persisted when the adapter was saved.

        HAP bridge construction is deliberately read-only.
        """
        try:
            aid = int(endpoint.get("aid") or 0)
        except Exception:
            aid = 0

        stored_type = str(endpoint.get("aid_type") or "").strip().lower()
        hk_type = str(hk_type or "switch").strip().lower()

        if aid > 1 and aid != 7 and aid not in used_aids and stored_type == hk_type:
            used_aids.add(aid)
            return aid

        # Safety fallback for old configs. Temporary only: never persist here.
        next_aid = 100 if hk_type != "switch" else 2
        while next_aid in used_aids or next_aid == 7:
            next_aid += 1
        used_aids.add(next_aid)
        self.logger.warning(
            "HomeKit endpoint missing stable identity object=%s endpoint=%s "
            "configured_type=%s stored_type=%s stored_aid=%s temporary_aid=%s",
            getattr(item, "id", ""),
            endpoint.get("id"),
            hk_type,
            stored_type or "-",
            aid,
            next_aid,
        )
        return next_aid

    def _build_bridge(self, driver, config):
        bridge = Bridge(driver, "MP-Gateway HomeKit v2")
        bridge.set_info_service(
            firmware_revision="1.0.0",
            manufacturer="MP-Gateway",
            model="MP-Gateway HomeKit Bridge",
            serial_number="MP-Gateway-Bridge",
        )

        # Compatibility invariant from the proven single-endpoint runtime:
        # object_accessories is ALWAYS keyed by MP object_id and contains the
        # primary HomeKit accessory. Multi-endpoints live in separate maps.
        self.object_accessories = {}
        self.endpoint_accessories = {}
        self.object_accessories_by_object = {}
        self.sync_state = {}
        count = 0
        used_aids = {1, 7}
        allowed_types = {'switch', 'light', 'color_light', 'temperature', 'humidity', 'lux', 'contact', 'motion', 'occupancy', 'leak', 'smoke', 'carbon_monoxide', 'carbon_dioxide', 'air_quality', 'outlet', 'fan', 'valve', 'garage_door', 'lock', 'window_covering', 'thermostat'}
        sensor_types = {'air_quality', 'carbon_dioxide', 'carbon_monoxide', 'contact', 'humidity', 'leak', 'lux', 'motion', 'occupancy', 'smoke', 'temperature'}

        for item in self.core.object_core_service.list_objects():
            adapter = self._homekit_adapter_for_object(item)
            if adapter is None or not bool(getattr(adapter, "enabled", False)):
                continue

            endpoints = list(getattr(adapter, "endpoints", []) or [])
            if not endpoints:
                continue

            adapter.endpoints = endpoints

            for ep_index, endpoint in enumerate(endpoints):
                if not isinstance(endpoint, dict) or not bool(endpoint.get("enabled", False)):
                    continue

                endpoint_id = str(endpoint.get("id") or f"homekit_endpoint_{ep_index+1}")
                endpoint["id"] = endpoint_id

                direction = str(endpoint.get("direction") or "both").strip().lower()
                if direction not in {"in", "out", "both"}:
                    direction = "both"

                hk_type = str(endpoint.get("homekit_type") or "switch").strip().lower()
                if hk_type not in allowed_types:
                    hk_type = "switch"
                if hk_type in sensor_types:
                    direction = "out"
                    endpoint["direction"] = "out"

                display_name = str(
                    endpoint.get("homekit_name")
                    or getattr(item, "name", "")
                    or getattr(item, "id", "")
                ).strip()
                value_path = str(endpoint.get("value_path") or "").strip()
                aid = self._ensure_homekit_endpoint_aid(
                    item, adapter, endpoint, used_aids, hk_type
                )
                persisted_type = str(endpoint.get("aid_type") or "").strip().lower()
                if persisted_type and persisted_type != hk_type:
                    self.logger.error(
                        "HomeKit endpoint type mismatch object=%s endpoint=%s configured=%s persisted=%s",
                        getattr(item, "id", ""), endpoint_id, hk_type, persisted_type
                    )
                    continue
                writable = direction in {"in", "both"} and hk_type in {'color_light', 'fan', 'garage_door', 'light', 'lock', 'outlet', 'switch', 'thermostat', 'valve', 'window_covering'}
                endpoint_payload = dict(endpoint)
                endpoint_payload["is_primary_endpoint"] = (ep_index == 0)
                endpoint_adapter = SimpleNamespace(**endpoint_payload)
                state_key = f"{item.id}::{endpoint_id}"

                accessory = None
                try:
                    if hk_type == "switch":
                        accessory = ObjectSwitch(
                            driver, display_name, self, item.id,
                            writable=writable, value_path=value_path, aid=aid, adapter=endpoint_adapter,
                        )
                    elif hk_type == "light":
                        accessory = ObjectLight(
                            driver, display_name, self, item.id,
                            writable=writable, value_path=value_path, aid=aid, adapter=endpoint_adapter,
                        )
                    elif hk_type == "color_light":
                        accessory = ObjectColorLight(
                            driver, display_name, self, item.id,
                            writable=writable, value_path=value_path, aid=aid, adapter=endpoint_adapter,
                        )
                    elif hk_type == "temperature":
                        accessory = ObjectTemperature(
                            driver, display_name, self, item.id,
                            writable=False, value_path=value_path, aid=aid, adapter=endpoint_adapter,
                        )
                    elif hk_type == "humidity":
                        accessory = ObjectHumidity(
                            driver, display_name, self, item.id,
                            writable=False, value_path=value_path, aid=aid, adapter=endpoint_adapter,
                        )
                    elif hk_type == "lux":
                        accessory = ObjectLux(
                            driver, display_name, self, item.id,
                            writable=False, value_path=value_path, aid=aid, adapter=endpoint_adapter,
                        )
                    elif hk_type == "contact":
                        accessory = ObjectContact(
                            driver, display_name, self, item.id,
                            writable=False, value_path=value_path, aid=aid, adapter=endpoint_adapter,
                        )
                    elif hk_type == "motion":
                        accessory = ObjectMotion(
                            driver, display_name, self, item.id,
                            writable=False, value_path=value_path, aid=aid, adapter=endpoint_adapter,
                        )

                    elif hk_type == "occupancy":
                        accessory = ObjectOccupancy(driver, display_name, self, item.id, writable=False, value_path=value_path, aid=aid, adapter=endpoint_adapter)
                    elif hk_type == "leak":
                        accessory = ObjectLeak(driver, display_name, self, item.id, writable=False, value_path=value_path, aid=aid, adapter=endpoint_adapter)
                    elif hk_type == "smoke":
                        accessory = ObjectSmoke(driver, display_name, self, item.id, writable=False, value_path=value_path, aid=aid, adapter=endpoint_adapter)
                    elif hk_type == "carbon_monoxide":
                        accessory = ObjectCarbonMonoxide(driver, display_name, self, item.id, writable=False, value_path=value_path, aid=aid, adapter=endpoint_adapter)
                    elif hk_type == "carbon_dioxide":
                        accessory = ObjectCarbonDioxide(driver, display_name, self, item.id, writable=False, value_path=value_path, aid=aid, adapter=endpoint_adapter)
                    elif hk_type == "air_quality":
                        accessory = ObjectAirQuality(driver, display_name, self, item.id, writable=False, value_path=value_path, aid=aid, adapter=endpoint_adapter)
                    elif hk_type == "outlet":
                        accessory = ObjectOutlet(driver, display_name, self, item.id, writable=writable, value_path=value_path, aid=aid, adapter=endpoint_adapter)
                    elif hk_type == "fan":
                        accessory = ObjectFan(driver, display_name, self, item.id, writable=writable, value_path=value_path, aid=aid, adapter=endpoint_adapter)
                    elif hk_type == "valve":
                        accessory = ObjectValve(driver, display_name, self, item.id, writable=writable, value_path=value_path, aid=aid, adapter=endpoint_adapter)
                    elif hk_type == "garage_door":
                        accessory = ObjectGarageDoor(driver, display_name, self, item.id, writable=writable, value_path=value_path, aid=aid, adapter=endpoint_adapter)
                    elif hk_type == "lock":
                        accessory = ObjectLock(driver, display_name, self, item.id, writable=writable, value_path=value_path, aid=aid, adapter=endpoint_adapter)
                    elif hk_type == "window_covering":
                        accessory = ObjectWindowCovering(driver, display_name, self, item.id, writable=writable, value_path=value_path, aid=aid, adapter=endpoint_adapter)
                    elif hk_type == "thermostat":
                        accessory = ObjectThermostat(driver, display_name, self, item.id, writable=writable, value_path=value_path, aid=aid, adapter=endpoint_adapter)

                    if accessory is None:
                        continue

                    accessory.homekit_endpoint_id = endpoint_id
                    bridge.add_accessory(accessory)
                except Exception as exc:
                    self.logger.exception(
                        "HomeKit endpoint build failed object=%s endpoint=%s type=%s",
                        getattr(item, "id", ""), endpoint_id, hk_type
                    )
                    self.sync_state[state_key] = {
                        "object_id": item.id,
                        "endpoint_id": endpoint_id,
                        "name": display_name,
                        "type": hk_type,
                        "direction": direction,
                        "value_path": value_path,
                        "aid": aid,
                        "accessory_class": "",
                        "raw_value": None,
                        "homekit_value": None,
                        "last_sync": "",
                        "sync_count": 0,
                        "error": f"Accessory-Build: {exc}",
                    }
                    continue

                self.endpoint_accessories[state_key] = accessory
                self.object_accessories_by_object.setdefault(item.id, []).append((state_key, accessory))
                # Keep the first endpoint in the legacy/proven object_id map.
                if item.id not in self.object_accessories:
                    self.object_accessories[item.id] = accessory
                self.sync_state[state_key] = {
                    "object_id": item.id,
                    "endpoint_id": endpoint_id,
                    "name": display_name,
                    "type": hk_type,
                    "direction": direction,
                    "value_path": value_path,
                    "aid": int(accessory.aid or 0),
                    "accessory_class": accessory.__class__.__name__,
                    "serial_number": str(getattr(accessory, "homekit_serial_number", "") or ""),
                    "identity_tag": str(endpoint.get("identity_tag") or ""),
                    "configured_type": hk_type,
                    "aid_type": str(endpoint.get("aid_type") or ""),
                    "hap_services": [
                        str(getattr(service, "display_name", "") or "")
                        for service in list(getattr(accessory, "services", []) or [])
                    ],
                    "raw_value": None,
                    "homekit_value": None,
                    "last_sync": "",
                    "sync_count": 0,
                    "error": "",
                }
                try:
                    self.core.add_log_entry(
                        f"HOMEKIT BUILT object_id={item.id} endpoint={endpoint_id} "
                        f"configured_type={hk_type} class={accessory.__class__.__name__} "
                        f"aid={int(accessory.aid or 0)} serial={getattr(accessory,'homekit_serial_number','')} "
                        f"identity_tag={getattr(endpoint_adapter,'identity_tag','')}"
                    )
                except Exception:
                    pass
                count += 1

        self.accessory_count = count
        return bridge

    def _on_object_live_event(self, event):
        """Push one changed MP object to every HomeKit endpoint attached to it."""
        try:
            hk_callback_perf = time.perf_counter()
            object_id = str((event or {}).get("object_id") or "").strip()
            if not object_id:
                return

            accessories = list(self.object_accessories_by_object.get(object_id) or [])
            if not accessories:
                return

            source_rx_perf = (event or {}).get("latency_source_rx_perf")
            object_cache_perf = (event or {}).get("latency_object_cache_perf")

            def _ms(a, b):
                try:
                    if a is None or b is None:
                        return None
                    return round((float(b) - float(a)) * 1000.0, 1)
                except Exception:
                    return None

            for state_key, accessory in accessories:
                raw_value, hk_value = accessory.sync_from_object()
                state = self.sync_state.setdefault(
                    state_key,
                    {"object_id": object_id, "endpoint_id": getattr(accessory, "homekit_endpoint_id", "")},
                )

                hap_prepare_perf = getattr(accessory, "_last_hap_prepare_perf", None)
                hap_publish_perf = getattr(accessory, "_last_hap_publish_perf", None)

                state["latency_source"] = str(
                    (event or {}).get("latency_source_name")
                    or (event or {}).get("source")
                    or ""
                )
                state["latency_rx_to_object_ms"] = _ms(source_rx_perf, object_cache_perf)
                state["latency_object_to_hk_callback_ms"] = _ms(object_cache_perf, hk_callback_perf)
                state["latency_hk_callback_to_hap_prepare_ms"] = _ms(hk_callback_perf, hap_prepare_perf)
                state["latency_hap_prepare_to_publish_ms"] = _ms(hap_prepare_perf, hap_publish_perf)
                state["latency_rx_to_hap_publish_ms"] = _ms(source_rx_perf, hap_publish_perf)
                state["latency_trace_at"] = time.time()
                state["raw_value"] = raw_value
                state["homekit_value"] = hk_value
                if isinstance(accessory, ObjectColorLight):
                    state["color_model"] = str(getattr(accessory, "_last_color_model", "") or "")
                    state["source_color_model"] = str(
                        getattr(accessory, "_last_source_color_model", "") or ""
                    )
                    state["ct_to_rgb_transition_count"] = int(
                        getattr(accessory, "_ct_to_rgb_transition_count", 0) or 0
                    )
                state["last_sync"] = time.strftime("%Y-%m-%d %H:%M:%S")
                state["sync_count"] = int(state.get("sync_count") or 0) + 1
                state["last_event_source"] = str((event or {}).get("source") or "")
                state["last_event_endpoint"] = str(
                    (event or {}).get("source_address")
                    or (event or {}).get("endpoint")
                    or ""
                )
                state["last_event_push"] = time.time()
                state["latency_summary"] = (
                    f"RX→Obj={state.get('latency_rx_to_object_ms')}ms · "
                    f"Obj→HK={state.get('latency_object_to_hk_callback_ms')}ms · "
                    f"HK→HAP={state.get('latency_hk_callback_to_hap_prepare_ms')}ms · "
                    f"HAPpub={state.get('latency_hap_prepare_to_publish_ms')}ms · "
                    f"Gesamt={state.get('latency_rx_to_hap_publish_ms')}ms"
                )
                state["error"] = ""
        except Exception as exc:
            self.last_error = str(exc)
            self.logger.exception("HomeKit realtime multi-endpoint push failed")

    def _register_live_listener(self):
        if self._live_listener_registered:
            return
        if object_service_module.register_live_listener(self._on_object_live_event):
            self._live_listener_registered = True

    def _unregister_live_listener(self):
        if not self._live_listener_registered:
            return
        object_service_module.unregister_live_listener(self._on_object_live_event)
        self._live_listener_registered = False

    def _sync_once(self):
        for state_key, accessory in list(self.endpoint_accessories.items()):
            state = self.sync_state.setdefault(
                state_key,
                {
                    "object_id": getattr(accessory, "object_id", ""),
                    "endpoint_id": getattr(accessory, "homekit_endpoint_id", ""),
                },
            )
            try:
                raw_value, hk_value = accessory.sync_from_object()
                state["raw_value"] = raw_value
                state["homekit_value"] = hk_value
                state["last_sync"] = time.strftime("%Y-%m-%d %H:%M:%S")
                state["sync_count"] = int(state.get("sync_count") or 0) + 1
                state["error"] = ""
            except Exception as exc:
                state["error"] = str(exc)
                self.logger.exception(
                    "HomeKit sync failed endpoint=%s object=%s", state_key, getattr(accessory, "object_id", "")
                )

    def _start_sync_worker(self):
        self.sync_stop.clear()
        if self.sync_thread and self.sync_thread.is_alive():
            return

        def worker():
            while not self.sync_stop.is_set():
                self._sync_once()
                self.sync_stop.wait(0.5)

        self.sync_thread = threading.Thread(
            target=worker,
            name="mp-homekit-sync",
            daemon=True,
        )
        self.sync_thread.start()

    def _stop_sync_worker(self):
        self.sync_stop.set()
        thread = self.sync_thread
        if thread and thread.is_alive() and thread is not threading.current_thread():
            thread.join(timeout=2.0)
        self.sync_thread = None

    def start(self):
        with self.lock:
            if self.thread and self.thread.is_alive():
                return True

            config = load_homekit_config()
            if not config.get("enabled"):
                self.status = "disabled"
                return False
            if not PYHAP_AVAILABLE:
                self.status = "error"
                self.last_error = f"HAP-python nicht verfügbar: {PYHAP_ERROR}"
                return False

            try:
                configured_ip = str(config.get("advertise_ip") or "").strip()
                advertise_ip = (
                    configured_ip
                    if _valid_ipv4(configured_ip)
                    else _detect_lan_ipv4()
                )
                if not advertise_ip:
                    raise RuntimeError(
                        "Keine geeignete LAN-IPv4-Adresse für HomeKit gefunden."
                    )

                # Deliberately mirrors the independently proven minimal bridge:
                # address + port + persist_file (+ configured PIN), nothing else.
                kwargs = {
                    "address": advertise_ip,
                    "port": 51998,
                    "persist_file": HOMEKIT_STATE_FILE,
                }
                pincode = str(config.get("pincode") or "").strip()
                if pincode:
                    kwargs["pincode"] = bytearray(pincode.encode("ascii"))

                driver = AccessoryDriver(**kwargs)
                bridge = self._build_bridge(driver, config)
                driver.add_accessory(accessory=bridge)

                self.driver = driver
                self.advertised_ip = advertise_ip
                self.listen_address = advertise_ip
                self.status = "starting"
                self.last_error = ""

                def runner():
                    try:
                        self.status = "running"
                        self.started_at = time.strftime("%Y-%m-%d %H:%M:%S")
                        driver.start()
                    except Exception as exc:
                        self.last_error = str(exc)
                        self.status = "error"
                        self.logger.exception("HomeKit runtime failed")
                    finally:
                        if self.status != "error":
                            self.status = "stopped"

                self.thread = threading.Thread(
                    target=runner,
                    name="mp-homekit",
                    daemon=True,
                )
                self.thread.start()
                self._register_live_listener()
                self._start_sync_worker()

                self.core.add_log_entry(
                    f"MP-HOMEKIT 1.0.0 gestartet: {advertise_ip}:"
                    f"51998 · "
                    f"{self.accessory_count} Accessories"
                )
                return True
            except Exception as exc:
                self.last_error = str(exc)
                self.status = "error"
                self.logger.exception("HomeKit start failed")
                return False

    def stop(self):
        self._unregister_live_listener()
        self._stop_sync_worker()
        with self.lock:
            driver = self.driver
            if driver is None:
                self.status = "stopped"
                return True
            try:
                driver.stop()
            except Exception as exc:
                self.last_error = str(exc)
                self.logger.exception("HomeKit stop failed")
                return False
            finally:
                self.driver = None
            self.status = "stopped"
            return True

    def restart(self):
        # A configuration save may trigger a rebuild. Never allow two rebuilds
        # to overlap, otherwise Apple sees a flapping HAP bridge.
        if not self.restart_lock.acquire(blocking=False):
            return True
        try:
            self.stop()
            time.sleep(0.4)
            return self.start()
        finally:
            self.restart_lock.release()

    def _schedule_mdns_reannounce(self):
        driver = self.driver
        if driver is None:
            return False
        try:
            driver.update_advertisement()
            return True
        except Exception:
            self.logger.exception("HomeKit mDNS update failed")
            return False

    def _characteristic_map(self):
        result = {}
        for accessory in self.endpoint_accessories.values():
            try:
                aid = int(accessory.aid or 0)
            except Exception:
                continue
            for service in list(getattr(accessory, "services", []) or []):
                for char in list(getattr(service, "characteristics", []) or []):
                    try:
                        iid = int(accessory.iid_manager.get_iid(char))
                    except Exception:
                        continue
                    result[(aid, iid)] = {
                        "accessory": str(
                            getattr(accessory, "display_name", "") or ""
                        ),
                        "service": str(
                            getattr(service, "display_name", "") or ""
                        ),
                        "characteristic": str(
                            getattr(char, "display_name", "") or ""
                        ),
                    }
        return result

    def _hap_characteristics_for_accessory(self, accessory):
        rows = []
        driver = self.driver
        topics = getattr(driver, "topics", {}) if driver is not None else {}
        try:
            aid = int(accessory.aid or 0)
        except Exception:
            aid = 0

        for service in list(getattr(accessory, "services", []) or []):
            for char in list(getattr(service, "characteristics", []) or []):
                name = str(getattr(char, "display_name", "") or "")
                if name not in {
                    "On", "Brightness", "Hue", "Saturation", "ColorTemperature",
                    "CurrentTemperature", "CurrentRelativeHumidity",
                    "CurrentAmbientLightLevel", "ContactSensorState", "MotionDetected"
                }:
                    continue
                try:
                    iid = int(accessory.iid_manager.get_iid(char))
                except Exception:
                    continue
                topic = f"{aid}.{iid}"
                rows.append({
                    "name": name,
                    "iid": iid,
                    "value": getattr(char, "value", None),
                    "topic": topic,
                    "subscribers": len(list((topics or {}).get(topic, []) or [])),
                })
        return rows

    def _connections(self):
        driver = self.driver
        server = getattr(driver, "http_server", None) if driver else None
        connections = getattr(server, "connections", {}) if server else {}
        rows = []
        for client, proto in list((connections or {}).items()):
            try:
                host, port = str(client[0]), int(client[1])
            except Exception:
                host, port = str(client), 0
            rows.append({
                "host": host,
                "port": port,
                "client": f"{host}:{port}" if port else host,
                "encrypted": bool(getattr(proto, "hap_crypto", None)),
                "connection_id": str(
                    getattr(proto, "client_uuid", "")
                    or getattr(proto, "connection_id", "")
                    or ""
                ),
                "last_activity_seconds": 0,
            })
        return rows

    def _configured_homekit_objects(self):
        rows = []
        try:
            for item in self.core.object_core_service.list_objects():
                adapter = self._homekit_adapter_for_object(item)
                if adapter is None:
                    continue
                for index, ep in enumerate(list(getattr(adapter, "endpoints", []) or [])):
                    if not isinstance(ep, dict):
                        continue
                    rows.append({
                        "object_id": getattr(item, "id", ""),
                        "endpoint_id": str(ep.get("id") or f"homekit_endpoint_{index+1}"),
                        "name": getattr(item, "name", ""),
                        "enabled": bool(ep.get("enabled", False)),
                        "direction": str(ep.get("direction") or "both"),
                        "homekit_type": str(ep.get("homekit_type") or "switch"),
                        "homekit_name": str(ep.get("homekit_name") or ""),
                        "aid": int(ep.get("aid") or 0),
                        "aid_type": str(ep.get("aid_type") or ""),
                        "identity_tag": str(ep.get("identity_tag") or ""),
                    })
        except Exception:
            self.logger.exception("HomeKit configured endpoint diagnostics failed")
        return rows

    def diagnostics(self):
        driver = self.driver
        paired = []
        subscriptions = []
        subscriber_clients = []

        if driver is not None:
            state = getattr(driver, "state", None)
            paired_clients = (
                getattr(state, "paired_clients", {})
                if state is not None
                else {}
            )
            for client_uuid in list(paired_clients or {}):
                try:
                    admin = bool(state.is_admin(client_uuid))
                except Exception:
                    admin = False
                paired.append({"id": str(client_uuid), "admin": admin})

            char_map = self._characteristic_map()
            for topic, clients in list(
                (getattr(driver, "topics", {}) or {}).items()
            ):
                try:
                    aid_raw, iid_raw = str(topic).split(".", 1)
                    aid, iid = int(aid_raw), int(iid_raw)
                except Exception:
                    aid = iid = None
                meta = (
                    char_map.get((aid, iid), {})
                    if aid is not None and iid is not None
                    else {}
                )
                for client in list(clients or []):
                    try:
                        host, port = str(client[0]), int(client[1])
                    except Exception:
                        host, port = str(client), 0
                    subscriptions.append({
                        "client": f"{host}:{port}" if port else host,
                        "host": host,
                        "port": port,
                        "topic": str(topic),
                        "aid": aid,
                        "iid": iid,
                        **meta,
                    })
                    subscriber_clients.append(
                        f"{host}:{port}" if port else host
                    )

        config = load_homekit_config()
        driver_state = getattr(driver, "state", None) if driver else None
        return {
            "available": PYHAP_AVAILABLE,
            "status": self.status,
            "last_error": self.last_error,
            "started_at": self.started_at,
            "advertised_ip": self.advertised_ip,
            "listen_address": self.listen_address,
            "port": 51998,
            "accessory_count": self.accessory_count,
            "primary_accessory_count": len(self.object_accessories),
            "endpoint_accessory_count": len(self.endpoint_accessories),
            "configured_homekit_objects": self._configured_homekit_objects(),
            "accessory_class_audit": {
                "status": "ok",
                "factory_classes": sorted([
                    name for name, obj in globals().items()
                    if name.startswith("Object") and isinstance(obj, type)
                ]),
            },
            "udp_rx_trace": self.core.get_udp_rx_trace(50) if hasattr(self.core, "get_udp_rx_trace") else [],
            "configured_homekit_enabled_count": sum(
                1 for row in self._configured_homekit_objects() if row.get("enabled")
            ),
            "paired_controllers": paired,
            "subscriber_clients": sorted(set(subscriber_clients)),
            "hap_subscriptions": subscriptions,
            "hap_subscription_count": len(subscriptions),
            "hap_subscription_events": [],
            "hap_connections": self._connections(),
            "connection_watchdog_running": False,
            "hap_server_listening": bool(self.driver),
            "reannounce_count": 0,
            "last_reannounce_at": 0,
            "last_reannounce_result": "",
            "server_recovery_count": 0,
            "last_server_recovery_at": 0,
            "last_server_recovery_result": "",
            "sync_worker_running": bool(
                self.sync_thread and self.sync_thread.is_alive()
            ),
            "realtime_listener_registered": bool(self._live_listener_registered),
            "sync_objects": [
                {
                    **state,
                    "hap_characteristics": self._hap_characteristics_for_accessory(
                        self.endpoint_accessories.get(object_id)
                    ) if self.endpoint_accessories.get(object_id) is not None else [],
                    "last_write": self.last_write.get(state.get("object_id"), {}),
                    "immediate_push_count": int(
                        getattr(self.endpoint_accessories.get(object_id), "_immediate_push_count", 0)
                        if self.endpoint_accessories.get(object_id) is not None else 0
                    ),
                }
                for object_id, state in self.sync_state.items()
            ],
            "hap_config_version": getattr(driver_state, "config_version", None),
            "hap_accessories_hash_present": bool(
                getattr(driver_state, "accessories_hash", None)
            ),
            # Compatibility keys retained so the existing UI remains harmless.
            "hap_event_diagnostics": [],
            "hap_topic_diagnostics": [],
            "hap_pipeline_diagnostics": [],
            "hap_protocol_event_queues": [],
            "hap_request_response_trace": [],
            "hap_traffic_summary": [],
            "hap_traffic_events": [],
            "compat_heartbeat_running": False,
            "compat_heartbeat_count": 0,
            "compat_last_push": "",
        }

    def snapshot(self):
        return self.diagnostics()
