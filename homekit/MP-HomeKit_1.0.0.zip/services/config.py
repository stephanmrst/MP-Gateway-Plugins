"""Persistent configuration for the MP-Gateway HomeKit bridge."""

from __future__ import annotations

import os
import random

from app.engine import port
from app.services.config import safe_load_json_file, safe_save_json_file

HOMEKIT_CONFIG_FILE = os.path.join(str(port.CONFIG_DIR), "homekit.json")
HOMEKIT_STATE_FILE = os.path.join(str(port.CONFIG_DIR), "homekit-v2.state")


def _random_pin() -> str:
    # Avoid Apple-reserved/simple codes by generating a stable random PIN.
    a = random.randint(100, 999)
    b = random.randint(10, 99)
    c = random.randint(100, 999)
    return f"{a:03d}-{b:02d}-{c:03d}"


DEFAULT_HOMEKIT_CONFIG = {
    "enabled": False,
    "name": "MP-Gateway HomeKit v2",
    "port": 51998,
    "advertise_ip": "",
    "pincode": "",
    "mappings": [],
}


def _assign_stable_aids(mappings: list[dict]) -> list[dict]:
    """Preserve current bridge order once, then keep each object's AID stable forever."""
    used = {1, 7}  # 1 = bridge, 7 avoided by HAP-python itself.
    # First keep already-persisted valid AIDs.
    for item in mappings:
        try:
            aid = int(item.get("aid") or 0)
        except Exception:
            aid = 0
        if aid > 1 and aid != 7 and aid not in used:
            used.add(aid)
            item["aid"] = aid
        else:
            item["aid"] = 0

    # For old 36.4.x configs without AID, assigning in the existing mapping
    # order preserves the same sequential AIDs HAP-python used previously.
    next_aid = 2
    for item in mappings:
        if int(item.get("aid") or 0) > 1:
            continue
        while next_aid in used or next_aid == 7:
            next_aid += 1
        item["aid"] = next_aid
        used.add(next_aid)
        next_aid += 1
    return mappings


def load_homekit_config() -> dict:
    data = safe_load_json_file(HOMEKIT_CONFIG_FILE, dict(DEFAULT_HOMEKIT_CONFIG))
    if not isinstance(data, dict):
        data = dict(DEFAULT_HOMEKIT_CONFIG)
    merged = dict(DEFAULT_HOMEKIT_CONFIG)
    merged.update(data)
    if not merged.get("pincode"):
        merged["pincode"] = _random_pin()
    mappings = merged.get("mappings")
    if not isinstance(mappings, list):
        mappings = []
    cleaned = []
    for item in mappings:
        if not isinstance(item, dict):
            continue
        object_id = str(item.get("object_id") or "").strip()
        hk_type = str(item.get("type") or "").strip().lower()
        if not object_id or hk_type not in {"switch", "light", "temperature"}:
            continue
        cleaned.append({
            "object_id": object_id,
            "type": hk_type,
            "name": str(item.get("name") or "").strip(),
            "value_path": str(item.get("value_path") or "").strip(),
            "writable": bool(item.get("writable", hk_type in {"switch", "light"})),
            "aid": int(item.get("aid") or 0) if str(item.get("aid") or "").strip().isdigit() else 0,
        })
    merged["mappings"] = _assign_stable_aids(cleaned)
    save_homekit_config(merged)
    return merged


def save_homekit_config(data: dict) -> None:
    payload = dict(DEFAULT_HOMEKIT_CONFIG)
    payload.update(data if isinstance(data, dict) else {})
    safe_save_json_file(HOMEKIT_CONFIG_FILE, payload, indent=2)


def reset_pairing_state() -> bool:
    try:
        if os.path.exists(HOMEKIT_STATE_FILE):
            os.remove(HOMEKIT_STATE_FILE)
        return True
    except OSError:
        return False
