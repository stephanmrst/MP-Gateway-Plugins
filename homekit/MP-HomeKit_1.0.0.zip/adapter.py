from dataclasses import dataclass, field
from typing import Any, ClassVar

from app.services.object_adapter_engine import BaseAdapter

ALLOWED_TYPES = {'switch', 'light', 'color_light', 'temperature', 'humidity', 'lux', 'contact', 'motion', 'occupancy', 'leak', 'smoke', 'carbon_monoxide', 'carbon_dioxide', 'air_quality', 'outlet', 'fan', 'valve', 'garage_door', 'lock', 'window_covering', 'thermostat'}
SENSOR_TYPES = {'air_quality', 'carbon_dioxide', 'carbon_monoxide', 'contact', 'humidity', 'leak', 'lux', 'motion', 'occupancy', 'smoke', 'temperature'}
COLOR_MODES = {'auto', 'json', 'loxone_lumitech', 'loxone_lumitech_hs'}


@dataclass
class HomeKitAdapter(BaseAdapter):
    protocol: ClassVar[str] = "homekit"
    homekit_type: str = "switch"
    homekit_name: str = ""
    value_path: str = ""
    aid: int = 0
    aid_type: str = ""
    color_mode: str = "auto"
    sensor_invert: bool = False
    endpoints: list[dict[str, Any]] = field(default_factory=list)

    @classmethod
    def deserialize(cls, data: dict[str, Any]) -> "HomeKitAdapter":
        payload = dict(data or {})
        raw_endpoints = payload.get("endpoints") if isinstance(payload.get("endpoints"), list) else []
        endpoints = []
        for index, raw in enumerate(raw_endpoints):
            if not isinstance(raw, dict):
                continue
            endpoint = dict(raw)
            hk_type = str(endpoint.get("homekit_type") or endpoint.get("type") or "switch").strip().lower()
            if hk_type not in ALLOWED_TYPES:
                hk_type = "switch"
            direction = str(endpoint.get("direction") or "both").strip().lower()
            if direction not in {"in", "out", "both"}:
                direction = "both"
            if hk_type in SENSOR_TYPES:
                direction = "out"
            color_mode = str(endpoint.get("color_mode") or "auto").strip().lower()
            if color_mode not in COLOR_MODES:
                color_mode = "auto"
            try:
                aid = int(endpoint.get("aid") or 0)
            except (TypeError, ValueError):
                aid = 0
            endpoints.append({
                "id": str(endpoint.get("id") or f"homekit_endpoint_{index+1}"),
                "enabled": bool(endpoint.get("enabled", True)),
                "direction": direction,
                "homekit_type": hk_type,
                "homekit_name": str(endpoint.get("homekit_name") or endpoint.get("name") or "").strip(),
                "value_path": str(endpoint.get("value_path") or endpoint.get("json_path") or "").strip(),
                "aid": aid,
                "aid_type": str(endpoint.get("aid_type") or "").strip().lower(),
                "identity_tag": str(endpoint.get("identity_tag") or "").strip().lower(),
                "color_mode": color_mode,
                "sensor_invert": bool(endpoint.get("sensor_invert", False)),
            })

        if not endpoints and bool(payload.get("enabled", False)):
            hk_type = str(payload.get("homekit_type") or payload.get("type") or "switch").strip().lower()
            if hk_type not in ALLOWED_TYPES:
                hk_type = "switch"
            direction = str(payload.get("direction") or "both").strip().lower()
            if direction not in {"in", "out", "both"}:
                direction = "both"
            if hk_type in SENSOR_TYPES:
                direction = "out"
            try:
                aid = int(payload.get("aid") or 0)
            except (TypeError, ValueError):
                aid = 0
            color_mode = str(payload.get("color_mode") or "auto").strip().lower()
            if color_mode not in COLOR_MODES:
                color_mode = "auto"
            endpoints.append({
                "id": "homekit_endpoint_1",
                "enabled": True,
                "direction": direction,
                "homekit_type": hk_type,
                "homekit_name": str(payload.get("homekit_name") or payload.get("name") or "").strip(),
                "value_path": str(payload.get("value_path") or payload.get("json_path") or "").strip(),
                "aid": aid,
                "aid_type": str(payload.get("aid_type") or "").strip().lower(),
                "identity_tag": "",
                "color_mode": color_mode,
                "sensor_invert": bool(payload.get("sensor_invert", False)),
            })

        payload["endpoints"] = endpoints
        payload["enabled"] = any(bool(ep.get("enabled")) for ep in endpoints)
        first = endpoints[0] if endpoints else {}
        payload["direction"] = str(first.get("direction") or "out")
        payload["homekit_type"] = str(first.get("homekit_type") or "switch")
        payload["homekit_name"] = str(first.get("homekit_name") or "")
        payload["value_path"] = str(first.get("value_path") or "")
        payload["aid"] = int(first.get("aid") or 0)
        payload["aid_type"] = str(first.get("aid_type") or "")
        payload["color_mode"] = str(first.get("color_mode") or "auto")
        payload["sensor_invert"] = bool(first.get("sensor_invert", False))
        return super().deserialize(payload)


def adapter_from_form(form_data: Any) -> HomeKitAdapter:
    ids = form_data.getlist("homekit_endpoint_id[]") if hasattr(form_data, "getlist") else []
    enabled = set(form_data.getlist("homekit_endpoint_enabled[]")) if hasattr(form_data, "getlist") else set()
    directions = form_data.getlist("homekit_endpoint_direction[]") if hasattr(form_data, "getlist") else []
    types_ = form_data.getlist("homekit_endpoint_type[]") if hasattr(form_data, "getlist") else []
    names = form_data.getlist("homekit_endpoint_name[]") if hasattr(form_data, "getlist") else []
    paths = form_data.getlist("homekit_endpoint_value_path[]") if hasattr(form_data, "getlist") else []
    aids = form_data.getlist("homekit_endpoint_aid[]") if hasattr(form_data, "getlist") else []
    aid_types = form_data.getlist("homekit_endpoint_aid_type[]") if hasattr(form_data, "getlist") else []
    identity_tags = form_data.getlist("homekit_endpoint_identity_tag[]") if hasattr(form_data, "getlist") else []
    color_modes = form_data.getlist("homekit_endpoint_color_mode[]") if hasattr(form_data, "getlist") else []
    inverted = set(form_data.getlist("homekit_endpoint_sensor_invert[]")) if hasattr(form_data, "getlist") else set()

    endpoints = []
    count = max(len(ids), len(directions), len(types_), len(names), len(paths), len(aids), len(aid_types), len(identity_tags), len(color_modes))
    for index in range(count):
        key = str(index)
        hk_type = str(types_[index] if index < len(types_) else "switch").strip().lower()
        if hk_type not in ALLOWED_TYPES:
            hk_type = "switch"
        direction = str(directions[index] if index < len(directions) else "both").strip().lower()
        if direction not in {"in", "out", "both"}:
            direction = "both"
        if hk_type in SENSOR_TYPES:
            direction = "out"
        color_mode = str(color_modes[index] if index < len(color_modes) else "auto").strip().lower()
        if color_mode not in COLOR_MODES:
            color_mode = "auto"
        try:
            aid = int(aids[index] if index < len(aids) and str(aids[index]).strip() else 0)
        except (TypeError, ValueError):
            aid = 0
        endpoints.append({
            "id": str(ids[index] if index < len(ids) and str(ids[index]).strip() else f"homekit_endpoint_{index+1}"),
            "enabled": key in enabled,
            "direction": direction,
            "homekit_type": hk_type,
            "homekit_name": str(names[index] if index < len(names) else "").strip(),
            "value_path": str(paths[index] if index < len(paths) else "").strip(),
            "aid": aid,
            "aid_type": str(aid_types[index] if index < len(aid_types) else "").strip().lower(),
            "identity_tag": str(identity_tags[index] if index < len(identity_tags) else "").strip().lower(),
            "color_mode": color_mode,
            "sensor_invert": key in inverted,
        })

    if not endpoints and any(name in form_data for name in ("homekit_type", "homekit_name", "value_path")):
        hk_type = str(form_data.get("homekit_type", "switch") or "switch").strip().lower()
        if hk_type not in ALLOWED_TYPES:
            hk_type = "switch"
        direction = str(form_data.get("direction", "both") or "both").strip().lower()
        if direction not in {"in", "out", "both"}:
            direction = "both"
        if hk_type in SENSOR_TYPES:
            direction = "out"
        try:
            aid = int(form_data.get("aid", 0) or 0)
        except (TypeError, ValueError):
            aid = 0
        color_mode = str(form_data.get("color_mode", "auto") or "auto").strip().lower()
        if color_mode not in COLOR_MODES:
            color_mode = "auto"
        endpoints.append({
            "id": "homekit_endpoint_1", "enabled": "enabled" in form_data, "direction": direction,
            "homekit_type": hk_type, "homekit_name": str(form_data.get("homekit_name", "") or "").strip(),
            "value_path": str(form_data.get("value_path", "") or "").strip(), "aid": aid,
            "aid_type": str(form_data.get("aid_type", "") or "").strip().lower(), "identity_tag": "",
            "color_mode": color_mode, "sensor_invert": "sensor_invert" in form_data,
        })

    payload = {"protocol": "homekit", "endpoints": endpoints, "enabled": any(bool(ep.get("enabled")) for ep in endpoints)}
    first = endpoints[0] if endpoints else {}
    payload.update({
        "direction": str(first.get("direction") or "out"), "homekit_type": str(first.get("homekit_type") or "switch"),
        "homekit_name": str(first.get("homekit_name") or ""), "value_path": str(first.get("value_path") or ""),
        "aid": int(first.get("aid") or 0), "aid_type": str(first.get("aid_type") or ""),
        "color_mode": str(first.get("color_mode") or "auto"), "sensor_invert": bool(first.get("sensor_invert", False)),
    })
    return HomeKitAdapter.deserialize(payload)


def postprocess_adapter(object_def, adapter, object_service, adapter_map):
    """Assign stable HomeKit AIDs outside the MP-Gateway core."""
    endpoints = list(getattr(adapter, "endpoints", []) or [])
    if not endpoints:
        return adapter
    previous_by_id = {}
    previous_aids = set()
    try:
        previous_adapter = adapter_map(object_def).get("homekit")
        for old_ep in list(getattr(previous_adapter, "endpoints", []) or []):
            if not isinstance(old_ep, dict):
                continue
            old_id = str(old_ep.get("id") or "")
            previous_by_id[old_id] = old_ep
            try:
                old_aid = int(old_ep.get("aid") or 0)
            except Exception:
                old_aid = 0
            if old_aid > 1 and old_aid != 7:
                previous_aids.add(old_aid)
    except Exception:
        pass

    used = {1, 7}
    try:
        for obj in object_service.list_objects():
            if getattr(obj, "id", None) == getattr(object_def, "id", None):
                continue
            other = adapter_map(obj).get("homekit")
            for ep in list(getattr(other, "endpoints", []) or []):
                if isinstance(ep, dict) and bool(ep.get("enabled", False)):
                    try:
                        aid = int(ep.get("aid") or 0)
                    except Exception:
                        aid = 0
                    if aid > 1 and aid != 7:
                        used.add(aid)
    except Exception:
        pass

    for index, ep in enumerate(endpoints):
        if not isinstance(ep, dict):
            continue
        hk_type = str(ep.get("homekit_type") or "switch").strip().lower()
        if hk_type not in ALLOWED_TYPES:
            hk_type = "switch"
        ep["homekit_type"] = hk_type
        endpoint_id = str(ep.get("id") or f"homekit_endpoint_{index+1}")
        ep["id"] = endpoint_id
        old_ep = previous_by_id.get(endpoint_id)
        stored_type = str(ep.get("aid_type") or "").strip().lower()
        old_mode = str((old_ep or {}).get("color_mode") or "").strip().lower()
        new_mode = str(ep.get("color_mode") or "").strip().lower()
        identity_tag = str(ep.get("identity_tag") or "").strip().lower()
        migrate = stored_type and stored_type != hk_type
        desired_tag = hk_type if migrate else identity_tag
        if hk_type == "color_light" and new_mode == "loxone_lumitech_hs":
            desired_tag = "color_light_hs_v2"
            migrate = migrate or identity_tag != desired_tag
        if hk_type == "color_light" and old_ep is not None and (old_mode == "loxone_lumitech_hs") != (new_mode == "loxone_lumitech_hs"):
            migrate = True
            desired_tag = "color_light_hs_v2" if new_mode == "loxone_lumitech_hs" else "color_light_ct_v2"
        try:
            aid = int(ep.get("aid") or 0)
        except Exception:
            aid = 0
        if migrate:
            aid = 0
            ep["identity_tag"] = desired_tag
        if aid > 1 and aid != 7 and aid not in used and not migrate:
            used.add(aid)
        else:
            next_aid = 100 if hk_type != "switch" else 2
            forbidden = set(used) | (set(previous_aids) if migrate else set())
            while next_aid in forbidden or next_aid == 7:
                next_aid += 1
            aid = next_aid
            used.add(aid)
        ep["aid"] = aid
        ep["aid_type"] = hk_type
        if index > 0 and not str(ep.get("identity_tag") or "").strip():
            ep["identity_tag"] = endpoint_id.lower()

    adapter.endpoints = endpoints
    first = endpoints[0]
    adapter.aid = int(first.get("aid") or 0)
    adapter.aid_type = str(first.get("aid_type") or "")
    adapter.homekit_type = str(first.get("homekit_type") or "switch")
    return adapter


def change_hook(app, previous_serialized: dict, new_serialized: dict) -> None:
    keys = ("enabled", "direction", "homekit_type", "homekit_name", "value_path", "aid", "aid_type", "color_mode", "sensor_invert", "endpoints")
    old = {key: (previous_serialized or {}).get(key) for key in keys}
    new = {key: (new_serialized or {}).get(key) for key in keys}
    if old == new:
        return
    runtime = app.extensions.get("homekit_runtime")
    if runtime is None:
        return
    import threading

    def worker():
        with app.app_context():
            try:
                core = app.extensions.get("app_core")
                if core and hasattr(core, "add_log_entry"):
                    core.add_log_entry("HomeKit Plugin Runtime Reload angefordert")
                runtime.restart()
            except Exception:
                app.logger.exception("HomeKit Plugin Runtime Reload fehlgeschlagen")

    threading.Thread(target=worker, name="mp-homekit-plugin-object-reload", daemon=True).start()
