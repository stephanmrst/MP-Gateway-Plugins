"""HomeKit bridge configuration and runtime routes."""

from __future__ import annotations

import json
import socket
from flask import Blueprint, current_app, jsonify, redirect, render_template, request, url_for

from .services.config import load_homekit_config, reset_pairing_state, save_homekit_config

bp = Blueprint("homekit", __name__)


def _runtime():
    return current_app.extensions.get("homekit_runtime")


def _core():
    return current_app.extensions["app_core"]


@bp.get("/homekit")
def homekit_page():
    cfg = load_homekit_config()
    objects = _core().object_core_service.list_objects()
    runtime = _runtime()

    def flatten_paths(value, prefix=""):
        rows = []
        if isinstance(value, str):
            try:
                value = json.loads(value)
            except Exception:
                return rows
        if isinstance(value, dict):
            for key, child in value.items():
                path = f"{prefix}.{key}" if prefix else str(key)
                rows.extend(flatten_paths(child, path))
        elif isinstance(value, list):
            for index, child in enumerate(value):
                path = f"{prefix}[{index}]" if prefix else f"[{index}]"
                rows.extend(flatten_paths(child, path))
        elif prefix:
            rows.append({"path": prefix, "value": value})
        return rows

    object_value_paths = {}
    for obj in objects:
        live = _core().object_core_service.get_object_live_status(obj.id) or {}
        object_value_paths[obj.id] = flatten_paths(live.get("value"))

    return render_template(
        "homekit.html",
        config=cfg,
        objects=objects,
        object_value_paths=object_value_paths,
        hk_status=runtime.snapshot() if runtime else {"status": "unavailable", "available": False},
    )


@bp.post("/homekit/save")
def homekit_save():
    cfg = load_homekit_config()
    cfg["enabled"] = request.form.get("enabled") == "on"
    cfg["name"] = str(request.form.get("name") or "MP-Gateway").strip() or "MP-Gateway"
    try:
        cfg["port"] = max(1024, min(65535, int(request.form.get("port") or 51826)))
    except ValueError:
        cfg["port"] = 51826
    cfg["advertise_ip"] = str(request.form.get("advertise_ip") or "").strip()
    pincode = str(request.form.get("pincode") or cfg.get("pincode") or "").strip()
    if pincode:
        cfg["pincode"] = pincode

    old_aids = {
        str(item.get("object_id") or ""): int(item.get("aid") or 0)
        for item in (cfg.get("mappings") or [])
        if str(item.get("object_id") or "")
    }
    object_ids = request.form.getlist("object_id[]")
    types = request.form.getlist("type[]")
    names = request.form.getlist("hk_name[]")
    value_paths = request.form.getlist("value_path[]")
    writable_indices = set(request.form.getlist("writable[]"))
    mappings = []
    for index, object_id in enumerate(object_ids):
        hk_type = str(types[index] if index < len(types) else "").strip().lower()
        if hk_type not in {"switch", "light", "temperature"}:
            continue
        mappings.append({
            "object_id": str(object_id or "").strip(),
            "type": hk_type,
            "name": str(names[index] if index < len(names) else "").strip(),
            "value_path": str(value_paths[index] if index < len(value_paths) else "").strip(),
            "writable": str(index) in writable_indices and hk_type in {"switch", "light"},
            "aid": int(old_aids.get(str(object_id or "").strip()) or 0),
        })
    cfg["mappings"] = mappings
    save_homekit_config(cfg)

    runtime = _runtime()
    if runtime:
        if cfg["enabled"]:
            runtime.restart()
        else:
            runtime.stop()
    return redirect(url_for("homekit.homekit_page"))


@bp.post("/homekit/start")
def homekit_start():
    runtime = _runtime()
    ok = bool(runtime and runtime.start())
    return jsonify({"ok": ok, **(runtime.snapshot() if runtime else {})})


@bp.post("/homekit/stop")
def homekit_stop():
    runtime = _runtime()
    ok = bool(runtime and runtime.stop())
    return jsonify({"ok": ok, **(runtime.snapshot() if runtime else {})})


@bp.post("/homekit/reset")
def homekit_reset():
    runtime = _runtime()
    if runtime:
        runtime.stop()
    ok = reset_pairing_state()
    if runtime and load_homekit_config().get("enabled"):
        runtime.start()
    return jsonify({"ok": ok, **(runtime.snapshot() if runtime else {})})


@bp.get("/homekit/network")
def homekit_network():
    runtime = _runtime()
    snap = runtime.snapshot() if runtime else {}
    target_ip = str(snap.get("advertised_ip") or load_homekit_config().get("advertise_ip") or "").strip()
    port = int(snap.get("port") or load_homekit_config().get("port") or 51826)
    tcp_ok = False
    tcp_error = ""
    if target_ip:
        try:
            with socket.create_connection((target_ip, port), timeout=1.5):
                tcp_ok = True
        except OSError as exc:
            tcp_error = str(exc)
    return jsonify({
        "ok": bool(target_ip and tcp_ok),
        "advertised_ip": target_ip,
        "port": port,
        "listen_address": snap.get("listen_address") or "",
        "tcp_reachable_locally": tcp_ok,
        "tcp_error": tcp_error,
        "status": snap.get("status") or "unknown",
    })


@bp.post("/homekit/reannounce")
def homekit_reannounce():
    runtime = _runtime()
    ok = bool(runtime and runtime._schedule_mdns_reannounce())
    return jsonify({"ok": ok, **(runtime.snapshot() if runtime else {})})


@bp.get("/homekit/diagnostics")
def homekit_diagnostics():
    runtime = _runtime()
    if not runtime:
        return jsonify({"ok": False, "status": "unavailable"})
    snap = runtime.snapshot()
    return jsonify({"ok": True, **snap})


@bp.get("/homekit/status")
def homekit_status():
    runtime = _runtime()
    return jsonify(runtime.snapshot() if runtime else {"available": False, "status": "unavailable"})
