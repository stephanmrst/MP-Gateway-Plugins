from __future__ import annotations

import logging
import threading
import time


def register_adapter() -> None:
    from app.services.object_adapter_engine import register_adapter
    from .adapter import HomeKitAdapter, adapter_from_form, postprocess_adapter, change_hook

    register_adapter(
        HomeKitAdapter,
        form_parser=adapter_from_form,
        template_name="objects_v33/adapters/homekit.html",
        postprocessor=postprocess_adapter,
        change_hook=change_hook,
    )


def register(app, core, manager) -> None:
    from .routes import bp
    from .services.config import load_homekit_config
    from .services.runtime import HomeKitRuntime

    if bp.name not in app.blueprints:
        app.register_blueprint(bp)

    try:
        core.object_core_service.SUPPORTED_ROUTE_PAIRS.update({
            ("homekit", "mqtt"), ("homekit", "loxone"), ("homekit", "knx"),
            ("homekit", "udp"), ("homekit", "influx"),
        })
    except Exception:
        app.logger.exception("HomeKit Plugin routing registration failed")

    runtime = HomeKitRuntime(core, app.logger)
    app.extensions["homekit_runtime"] = runtime
    logging.getLogger("pyhap").setLevel(logging.INFO)

    def _autostart() -> None:
        time.sleep(2.0)
        try:
            if load_homekit_config().get("enabled"):
                if runtime.start():
                    core.add_log_entry("HomeKit Plugin Auto-Start angefordert")
                else:
                    core.add_log_entry(
                        f"HomeKit Plugin Auto-Start nicht aktiv: {runtime.snapshot().get('last_error', '')}"
                    )
        except Exception as exc:
            core.add_log_entry(f"HomeKit Plugin Auto-Start Fehler: {exc}")

    threading.Thread(target=_autostart, name="mp-homekit-plugin-autostart", daemon=True).start()
