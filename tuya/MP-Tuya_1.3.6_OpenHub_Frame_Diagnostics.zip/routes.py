from __future__ import annotations

from flask import Blueprint, current_app, jsonify, redirect, request

from .services.config import load_config, save_config
from .services.runtime import dps_meta
from .services.cloud import sync_devices, TuyaCloudError

bp = Blueprint("tuya", __name__)


def _core():
    return current_app.extensions["app_core"]


def _runtime():
    return current_app.extensions.get("tuya_runtime")


def _realtime():
    return current_app.extensions.get("tuya_iot_realtime")


def _esc(value):
    return _core().escape(str(value or ""))


def _checked(value):
    return "checked" if value else ""


def _settings_content(notice: str = ""):
    cfg = load_config()
    realtime = _realtime()
    rt_status = realtime.snapshot() if realtime is not None else {"state": "unavailable", "message": "Runtime nicht verfügbar", "connected": False}
    rt_cfg = dict(cfg.get("iot_realtime") or {})
    devices = list(cfg.get("devices") or [])
    while len(devices) < max(6, len(devices) + 1):
        devices.append({"enabled": True, "name": "", "device_id": "", "ip": "", "local_key": "", "version": "3.3", "profile": "auto"})
        if len(devices) >= 8:
            break
    rows = []
    for i, dev in enumerate(devices):
        rows.append(f"""
        <div class="card compact-card" style="margin-top:10px;">
          <div style="display:grid;grid-template-columns:40px 1.2fr 1.5fr 1fr 1.3fr 90px;gap:10px;align-items:end;">
            <label style="margin:0"><input type="checkbox" name="dev_enabled_{i}" {_checked(dev.get('enabled'))}> aktiv</label>
            <div><label>Name</label><input name="dev_name_{i}" value="{_esc(dev.get('name'))}" placeholder="z. B. Bewegungsmelder Lager"></div>
            <div><label>Device ID</label><input name="dev_id_{i}" value="{_esc(dev.get('device_id'))}"></div>
            <div><label>IP</label><input name="dev_ip_{i}" value="{_esc(dev.get('ip'))}" placeholder="192.168.1.x"></div>
            <div><label>Local Key</label><input type="password" name="dev_key_{i}" value="{_esc(dev.get('local_key'))}"></div>
            <div><label>Version</label><input name="dev_ver_{i}" value="{_esc(dev.get('version') or '3.3')}"></div>
          </div>
        </div>""")
    return f"""
{notice}
<form method="post" action="/tuya/save">
  <div class="card compact-card">
    <h1>MP-Tuya</h1>
    <p class="small">Direkte lokale Tuya-LAN-Verbindung. Für den ersten Stand liegt der Fokus auf Tuya 3.3 und DPS-Livewerten. Device-ID, IP und Local Key werden lokal im Plugin-Datenverzeichnis gespeichert.</p>
    <p class="small"><b>Wichtig:</b> Viele Tuya-Geräte erlauben nur eine lokale Client-Verbindung. Für einen sauberen Test den ioBroker.tuya Adapter für dasselbe Gerät vorübergehend stoppen.</p>
  </div>
  <div class="card">
    <h2 class="section-title">Runtime</h2>
    <label><input type="checkbox" name="enabled" {_checked(cfg.get('enabled'))}> Tuya Runtime aktivieren</label>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;max-width:600px;">
      <div><label>Vollabfrage alle (s)</label><input name="poll_interval" value="{_esc(cfg.get('poll_interval',15))}"></div>
      <div><label>Socket Timeout (s)</label><input name="socket_timeout" value="{_esc(cfg.get('socket_timeout',1))}"></div>
    </div>
  </div>
  <div class="card">
    <h2 class="section-title">Cloud-Synchronisation</h2>
    <p class="small">Optionaler Geräteimport aus Smart Life/Tuya Smart. Die Cloud wird nur zum Abruf von Gerätenamen, Device-ID und Local Key verwendet; danach arbeitet MP-Tuya lokal weiter. Das Passwort wird nur gespeichert, wenn der automatische Start-Sync aktiviert ist.</p>
    <div style="display:grid;grid-template-columns:160px 130px 1fr 1fr 110px;gap:12px;align-items:end;">
      <div><label>App</label><select name="cloud_app_type">
        <option value="smart_life" {"selected" if str((cfg.get('cloud') or {}).get('app_type')) == 'smart_life' else ""}>Smart Life</option>
        <option value="tuya_smart" {"selected" if str((cfg.get('cloud') or {}).get('app_type')) == 'tuya_smart' else ""}>Tuya Smart</option>
      </select></div>
      <div><label>Region</label><select name="cloud_region">
        <option value="EU" {"selected" if str((cfg.get('cloud') or {}).get('region','EU')) == 'EU' else ""}>EU</option>
        <option value="AZ" {"selected" if str((cfg.get('cloud') or {}).get('region')) == 'AZ' else ""}>Amerika</option>
        <option value="AY" {"selected" if str((cfg.get('cloud') or {}).get('region')) == 'AY' else ""}>Asien</option>
        <option value="IN" {"selected" if str((cfg.get('cloud') or {}).get('region')) == 'IN' else ""}>Indien</option>
      </select></div>
      <div><label>Benutzer / E-Mail</label><input name="cloud_username" value="{_esc((cfg.get('cloud') or {}).get('username'))}"></div>
      <div><label>Passwort</label><input type="password" name="cloud_password" value="{_esc((cfg.get('cloud') or {}).get('password'))}"></div>
      <div><label>LAN-Scan (s)</label><input name="cloud_scan_seconds" value="{_esc((cfg.get('cloud') or {}).get('scan_seconds',8))}"></div>
    </div>
    <div class="button-row" style="margin-top:14px;">
      <button type="submit" formaction="/tuya/cloud-sync" formmethod="post">Cloud synchronisieren</button>
      <label style="margin-left:10px;"><input type="checkbox" name="cloud_sync_on_start" {_checked((cfg.get('cloud') or {}).get('sync_on_start'))}> bei Plugin-Start synchronisieren</label>
    </div>
  </div>
  <div class="card">
    <h2 class="section-title">Tuya IoT Echtzeit <span class="small">/ Cloud Message Service</span></h2>
    <p class="small">Für Echtzeit-Updates von Geräten, die nicht dauerhaft lokal verbunden sind (z. B. batteriebetriebene Geräte). Lokale Werte bleiben bevorzugt; Cloud-Meldungen laufen als zusätzlicher Echtzeitkanal in denselben Tuya-DPS-Pfad.</p>
    <p class="small"><b>Tuya IoT-Konto erforderlich:</b> Registrierung und Einrichtung nach der <a href="https://developer.tuya.com/en/docs/iot/Platform_Configuration_smarthome?id=Kamcgamwoevrx" target="_blank" rel="noopener noreferrer">Tuya-Anleitung zur IoT-Plattform</a>. Hinweis: Kostenlose/Trial-Cloud-Dienste sind zeitlich begrenzt und müssen je nach Tuya-Konditionen regelmäßig verlängert werden.</p>
    <label><input type="checkbox" name="iot_enabled" {_checked(rt_cfg.get('enabled'))}> Cloud-Echtzeit aktivieren</label>
    <div style="display:grid;grid-template-columns:1fr 1fr 110px 160px;gap:12px;align-items:end;margin-top:10px;">
      <div><label>Access ID</label><input name="iot_access_id" value="{_esc(rt_cfg.get('access_id'))}"></div>
      <div><label>Access Secret</label><input type="password" name="iot_access_secret" value="{_esc(rt_cfg.get('access_secret'))}"></div>
      <div><label>Ländercode</label><input name="iot_country_code" value="{_esc(rt_cfg.get('country_code') or '49')}"></div>
      <div><label>App</label><select name="iot_app_schema">
        <option value="smartlife" {"selected" if str(rt_cfg.get('app_schema') or 'smartlife') in ('smartlife','smart_life') else ""}>Smart Life</option>
        <option value="tuyaSmart" {"selected" if str(rt_cfg.get('app_schema')) == 'tuyaSmart' else ""}>Tuya Smart</option>
      </select></div>
      <div><label>App-Benutzer / E-Mail</label><input name="iot_username" value="{_esc(rt_cfg.get('username') or (cfg.get('cloud') or {}).get('username'))}"></div>
      <div><label>App-Passwort</label><input type="password" name="iot_password" value="{_esc(rt_cfg.get('password'))}"></div>
    </div>
    <div class="small" style="margin-top:12px;" id="tuya-iot-status"><b>Status:</b> {('● verbunden' if rt_status.get('connected') else '○ ' + str(rt_status.get('message') or rt_status.get('state') or 'getrennt'))}
      {(' · Fehler: ' + _esc(rt_status.get('error'))) if rt_status.get('error') else ''}
    </div>
    <div class="small" style="margin-top:6px;" id="tuya-iot-diagnostics">
      <b>Cloud-Diagnose:</b>
      Meldungen: {int(rt_status.get('message_count') or 0)}
      · letzte Meldung: {_esc(rt_status.get('last_message') or '-')}
      · extrahiert: {int(rt_status.get('last_extracted') or 0)}
      · zugeordnet: {int(rt_status.get('last_updates') or 0)}
      · unbekannt: {_esc(', '.join(rt_status.get('last_unmatched') or []) or '-')}
      · Rohpakete: {int(rt_status.get('raw_packets') or 0)}
      · Decode-Fehler: {int(rt_status.get('decode_errors') or 0)}
      · Stufe: {_esc(rt_status.get('decode_stage') or '-')}
      · Outer-Keys: {_esc(','.join(rt_status.get('outer_keys') or []) or '-')}
      · Version: {_esc(rt_status.get('encrypted_version_seen') or '-')}
      · Payload: {int(rt_status.get('payload_length') or 0)} B
      · Decoded: {int(rt_status.get('decoded_length') or 0)} Zeichen
      · letzter Decode-Fehler: {_esc(rt_status.get('last_decode_error') or '-')}
      · Kanal: {_esc(rt_status.get('transport') or '-')}
      · Broker: {_esc(rt_status.get('broker') or '-')}
      · Topic: {_esc(rt_status.get('topic') or '-')}
    </div>
  </div>
  <div class="card">
    <h2 class="section-title">Lokale Geräte</h2>
    {''.join(rows)}
    <div class="button-row" style="margin-top:14px;">
      <button type="submit">Speichern &amp; Runtime neu laden</button>
      <a class="button-link" href="/tuya_explorer">Tuya Explorer öffnen</a>
    </div>
  </div>
</form>
""" + r"""
<script>
(function(){
  function esc(v){
    return String(v == null ? '' : v).replace(/[&<>"']/g, function(c){
      return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
  }
  async function refreshTuyaIotStatus(){
    try{
      const r = await fetch('/api/tuya/iot-status', {cache:'no-store'});
      const x = await r.json();
      const st = document.getElementById('tuya-iot-status');
      const dg = document.getElementById('tuya-iot-diagnostics');
      if(st){
        let h = '<b>Status:</b> ' + (x.connected ? '● verbunden' : '○ ' + esc(x.message || x.state || 'getrennt'));
        if(x.error) h += ' · Fehler: ' + esc(x.error);
        st.innerHTML = h;
      }
      if(dg){
        const u = Array.isArray(x.last_unmatched) && x.last_unmatched.length ? x.last_unmatched.join(', ') : '-';
        dg.innerHTML =
          '<b>Cloud-Diagnose:</b> Meldungen: ' + Number(x.message_count || 0) +
          ' · letzte Meldung: ' + esc(x.last_message || '-') +
          ' · extrahiert: ' + Number(x.last_extracted || 0) +
          ' · zugeordnet: ' + Number(x.last_updates || 0) +
          ' · unbekannt: ' + esc(u) +
          ' · Rohpakete: ' + Number(x.raw_packets || 0) +
          ' · Decode-Fehler: ' + Number(x.decode_errors || 0) +
          ' · Stufe: ' + esc(x.decode_stage || '-') +
          ' · Outer-Keys: ' + esc(Array.isArray(x.outer_keys) && x.outer_keys.length ? x.outer_keys.join(',') : '-') +
          ' · Version: ' + esc(x.encrypted_version_seen || '-') +
          ' · Payload: ' + Number(x.payload_length || 0) + ' B' +
          ' · Decoded: ' + Number(x.decoded_length || 0) + ' Zeichen' +
          ' · letzter Decode-Fehler: ' + esc(x.last_decode_error || '-') +
          ' · Kanal: ' + esc(x.transport || '-') +
          ' · Broker: ' + esc(x.broker || '-') +
          ' · Topic: ' + esc(x.topic || '-');
      }
    }catch(e){}
  }
  refreshTuyaIotStatus();
  setInterval(refreshTuyaIotStatus, 1000);
})();
</script>
"""


def _form_config():
    old = load_config()
    try:
        poll = max(2.0, float(request.form.get("poll_interval", old.get("poll_interval", 15))))
    except Exception:
        poll = 15.0
    try:
        timeout = max(0.3, min(5.0, float(request.form.get("socket_timeout", old.get("socket_timeout", 1)))))
    except Exception:
        timeout = 1.0
    devices = []
    for i in range(0, 24):
        dev_id = request.form.get(f"dev_id_{i}", "").strip()
        ip = request.form.get(f"dev_ip_{i}", "").strip()
        key = request.form.get(f"dev_key_{i}", "")
        name = request.form.get(f"dev_name_{i}", "").strip()
        version = request.form.get(f"dev_ver_{i}", "3.3").strip() or "3.3"
        if not any([dev_id, ip, key, name]):
            continue
        devices.append({"enabled": f"dev_enabled_{i}" in request.form, "name": name or dev_id, "device_id": dev_id, "ip": ip, "local_key": key, "version": version, "profile": "auto"})
    old_cloud = dict(old.get("cloud") or {})
    password = request.form.get("cloud_password", "")
    if not password:
        password = str(old_cloud.get("password") or "")
    try:
        scan_seconds = max(3, min(30, int(request.form.get("cloud_scan_seconds", old_cloud.get("scan_seconds", 8)))))
    except Exception:
        scan_seconds = 8
    cloud = dict(old_cloud)
    cloud.update({
        "app_type": request.form.get("cloud_app_type", old_cloud.get("app_type", "smart_life")).strip().lower(),
        "region": request.form.get("cloud_region", old_cloud.get("region", "EU")).strip().upper(),
        "username": request.form.get("cloud_username", old_cloud.get("username", "")).strip(),
        "password": password,
        "sync_on_start": "cloud_sync_on_start" in request.form,
        "scan_seconds": scan_seconds,
    })
    old_rt = dict(old.get("iot_realtime") or {})
    access_secret = request.form.get("iot_access_secret", "") or str(old_rt.get("access_secret") or "")
    iot_password = request.form.get("iot_password", "") or str(old_rt.get("password") or "")
    iot_rt = dict(old_rt)
    iot_rt.update({
        "enabled": "iot_enabled" in request.form,
        "access_id": request.form.get("iot_access_id", old_rt.get("access_id", "")).strip(),
        "access_secret": access_secret,
        "country_code": request.form.get("iot_country_code", old_rt.get("country_code", "49")).strip().lstrip("+"),
        "app_schema": request.form.get("iot_app_schema", old_rt.get("app_schema", "smartlife")).strip(),
        "username": request.form.get("iot_username", old_rt.get("username", cloud.get("username", ""))).strip(),
        "password": iot_password,
        "encrypted_version": "2.0",
    })
    return {"enabled": "enabled" in request.form, "poll_interval": poll, "socket_timeout": timeout, "devices": devices, "cloud": cloud, "iot_realtime": iot_rt}


@bp.get("/tuya_settings_embed")
def settings_embed():
    return _core().embedded_page("MP-Tuya", _settings_content())


@bp.post("/tuya/save")
def save():
    cfg = _form_config()
    if not (cfg.get("cloud") or {}).get("sync_on_start"):
        cfg.setdefault("cloud", {})["password"] = ""
        cfg["cloud"]["sid"] = ""
    save_config(cfg)
    runtime = _runtime()
    if runtime is not None:
        runtime.reload(cfg)
    realtime = _realtime()
    if realtime is not None:
        realtime.reload(cfg)
    _core().add_log_entry("MP-Tuya Konfiguration gespeichert")
    return redirect("/tuya_settings_embed")


@bp.post("/tuya/cloud-sync")
def cloud_sync():
    cfg = _form_config()
    try:
        cfg, report = sync_devices(cfg, current_app.logger)
        if not (cfg.get("cloud") or {}).get("sync_on_start"):
            cfg.setdefault("cloud", {})["password"] = ""
            cfg["cloud"]["sid"] = ""
        save_config(cfg)
        runtime = _runtime()
        if runtime is not None:
            runtime.reload(cfg)
        realtime = _realtime()
        if realtime is not None:
            realtime.reload(cfg)
        _core().add_log_entry(
            f"MP-Tuya Cloud-Sync: {report['cloud_devices']} Geräte, "
            f"{report['added']} neu, {report['updated']} aktualisiert, "
            f"{report['lan_found']} LAN-Treffer"
        )
        notice = (
            f"<div class='notice success'>Cloud-Sync erfolgreich: {report['cloud_devices']} Geräte, "
            f"{report['added']} neu, {report['updated']} aktualisiert, "
            f"{report['lan_found']} lokal gefunden"
            + (f", {report['missing_ip']} ohne LAN-IP" if report.get("missing_ip") else "")
            + ".</div>"
        )
        return _core().embedded_page("MP-Tuya", _settings_content(notice))
    except Exception as exc:
        current_app.logger.exception("MP-Tuya Cloud-Sync fehlgeschlagen")
        notice = f"<div class='notice error'>Cloud-Sync fehlgeschlagen: {_esc(exc)}</div>"
        return _core().embedded_page("MP-Tuya", _settings_content(notice)), 400


@bp.get("/api/tuya/iot-status")
def iot_status():
    realtime = _realtime()
    if realtime is None:
        return jsonify({"state": "unavailable", "connected": False, "message": "Runtime nicht verfügbar"}), 503
    return jsonify(realtime.snapshot())


@bp.get("/api/tuya/discovery")
def discovery():
    runtime = _runtime()
    if runtime is None:
        return jsonify({"dependency_error": "Runtime nicht verfügbar", "devices": [], "entries": []}), 503
    return jsonify(runtime.snapshot())


@bp.post("/api/tuya/test")
def test_device():
    runtime = _runtime()
    if runtime is None:
        return jsonify({"ok": False, "error": "Runtime nicht verfügbar"}), 503
    data = request.get_json(silent=True) or {}
    cfg = load_config()
    dev_id = str(data.get("device_id") or "")
    item = next((x for x in cfg.get("devices") or [] if str(x.get("device_id") or "") == dev_id), None)
    if not item:
        return jsonify({"ok": False, "error": "Gerät nicht gefunden"}), 404
    return jsonify(runtime.test_device(item))


@bp.post("/api/tuya/write")
def write_dps():
    runtime = _runtime()
    if runtime is None:
        return jsonify({"success": False, "error": "Runtime nicht verfügbar"}), 503
    data = request.get_json(silent=True) or {}
    device_id = str(data.get("device_id") or "").strip()
    dps = str(data.get("dps") or "").strip()
    if not device_id or not dps:
        return jsonify({"success": False, "error": "Device-ID oder DPS fehlt"}), 400
    cfg = load_config()
    if not any(str(x.get("device_id") or "") == device_id for x in cfg.get("devices") or []):
        return jsonify({"success": False, "error": "Gerät nicht konfiguriert"}), 404
    ok, message = runtime.write_value(device_id, dps, data.get("value"))
    if not ok:
        return jsonify({"success": False, "error": message}), 502
    entry = runtime.current_entry(device_id, dps) or {}
    return jsonify({"success": True, "message": message, "entry": entry})


@bp.get("/tuya_explorer")
def explorer():
    content = r'''
<style>
.tuya-shell{height:calc(100vh - 118px);min-height:620px;display:flex;flex-direction:column;gap:14px;overflow:hidden}.tuya-head{display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap}.tuya-grid{min-height:0;flex:1;display:grid;grid-template-columns:minmax(300px,35%) minmax(0,1fr);gap:14px;overflow:hidden}.tuya-list,.tuya-detail{min-height:0;height:100%;overflow:hidden;display:flex;flex-direction:column}.tuya-items,.tuya-scroll{min-height:0;flex:1;overflow:auto}.tuya-device{width:100%;text-align:left;border:1px solid var(--border-color,#3a414f);border-radius:9px;padding:11px;margin:0 0 8px;background:var(--panel2,#1d212b);color:var(--text,#eef2ff);cursor:pointer}.tuya-device.active{border-color:#2b8a3e;box-shadow:0 0 0 1px #2b8a3e inset}.tuya-led{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:8px;background:#e03131}.tuya-led.on{background:#2f9e44}.tuya-sub{opacity:.65;font-size:.82rem;margin:5px 0 0 18px}.tuya-dp{display:grid;grid-template-columns:34px 70px minmax(150px,1fr) minmax(100px,.55fr) minmax(150px,.8fr) auto;gap:10px;align-items:center;padding:10px 6px;border-bottom:1px solid rgba(127,127,127,.15)}.tuya-value{font-family:monospace;font-weight:700;text-align:right}.tuya-control-wrap{display:flex;align-items:center;gap:8px;min-height:34px}.tuya-control{max-width:180px}.tuya-write-status{font-size:.76rem;opacity:.75;white-space:nowrap}.tuya-write-status.ok{color:#51cf66;opacity:1}.tuya-write-status.bad{color:#ff6b6b;opacity:1}.tuya-toggle{position:relative;display:inline-block;width:44px;height:24px}.tuya-toggle input{opacity:0;width:0;height:0}.tuya-toggle span{position:absolute;inset:0;border-radius:24px;background:#868e96;cursor:pointer;transition:.15s}.tuya-toggle span:before{content:'';position:absolute;width:18px;height:18px;left:3px;top:3px;border-radius:50%;background:white;transition:.15s}.tuya-toggle input:checked+span{background:#2f9e44}.tuya-toggle input:checked+span:before{transform:translateX(20px)}.status-dot{width:10px;height:10px;border-radius:50%;display:inline-block;margin-right:7px;background:#868e96}.status-dot.ok{background:#2f9e44}.status-dot.bad{background:#e03131}@media(max-width:850px){.tuya-shell{height:auto;overflow:visible}.tuya-grid{grid-template-columns:1fr;overflow:visible}.tuya-list{height:500px}}
</style>
<div class="tuya-shell">
 <div class="card compact-card"><div class="tuya-head"><div><h1>Tuya Explorer</h1><p class="small">Lokale Tuya-Geräte und ihre DPS in Echtzeit.</p><div class="small"><span id="dot" class="status-dot"></span><b id="statusText">Runtime wird geprüft …</b></div></div><div class="button-row"><a class="button-link" href="/tuya_settings_embed">Verbindung konfigurieren</a><button id="refreshBtn" type="button">Aktualisieren</button></div></div></div>
 <div class="tuya-grid"><div class="card tuya-list"><h2 class="section-title">Geräte</h2><input id="search" placeholder="Gerät suchen …"><div id="list" class="tuya-items" style="margin-top:12px"></div></div><div class="card tuya-detail"><div id="detail" class="tuya-scroll"><div style="padding:40px;text-align:center"><h2>Gerät auswählen</h2></div></div></div></div>
</div>
<script>
(()=>{
 const $=id=>document.getElementById(id), esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 let devices=[],selected='',selection=new Map();
 const nav=url=>{if(window.parent&&window.parent!==window)window.parent.postMessage({type:'mqtt2lox:navigateFrame',url,activeHref:'/objects_v33'},window.location.origin);else location.href=url};
 function createUrl(dev,e){const p=new URLSearchParams({explorer:'tuya',source:'tuya',source_type:'tuya',origin_source:'tuya',source_adapter:'tuya',tab:'general',name:[dev.name,e.name].filter(Boolean).join(' · '),suggested_name:[dev.name,e.name].filter(Boolean).join(' · '),topic:e.endpoint,source_topic:e.endpoint,source_address:e.endpoint,datatype:e.datatype||'auto',value:String(e.value??''),explorer_action:'create'});return '/objects_v33/create_from_explorer?'+p.toString()}
 function renderList(){const q=$('search').value.toLowerCase().trim(),vis=devices.filter(d=>!q||[d.name,d.device_id,d.ip].join(' ').toLowerCase().includes(q));$('list').innerHTML=vis.length?vis.map(d=>`<button class="tuya-device ${d.device_id===selected?'active':''}" data-id="${esc(d.device_id)}"><div><span class="tuya-led ${d.online?'on':''}"></span><b>${esc(d.name||d.device_id)}</b></div><div class="tuya-sub">${esc(d.ip)} · v${esc(d.version)} · ${esc(d.message||(d.online?'verbunden':'offline'))}</div></button>`).join(''):'<div class="small">Keine Geräte konfiguriert.</div>';$('list').querySelectorAll('button').forEach(b=>b.onclick=()=>{selected=b.dataset.id;renderList();renderDetail()})}
 async function api(url,body=null){const opt=body===null?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)};const r=await fetch(url,opt),data=await r.json().catch(()=>({}));if(!r.ok||data.success===false)throw new Error(data.error||`HTTP ${r.status}`);return data}
 function compositeField(e){return {key:String(e.name||('dps_'+e.dps)).replace(/[^A-Za-z0-9_]+/g,'_'),protocol:'tuya',address:e.endpoint,value_path:''}}
 async function createComposite(){if(!selection.size)return alert('Bitte zuerst DPS auswählen.');const d=devices.find(x=>x.device_id===selected);const name=prompt('Name des Composite-Objekts:',(d?.name||'Tuya Gerät'));if(!name)return;try{const r=await api('/api/objects_v33/composites',{name,fields:[...selection.values()]});selection.clear();nav(`/objects_v33?selected=${encodeURIComponent(r.id)}&tab=general`)}catch(e){alert(e.message)}}
 async function appendComposite(){if(!selection.size)return alert('Bitte zuerst DPS auswählen.');try{const r=await api('/api/objects_v33/composites'),items=r.items||[];if(!items.length)return alert('Noch kein Composite-Objekt vorhanden.');const choices=items.map((x,i)=>`${i+1}: ${x.name}`).join('\n');const n=Number(prompt('Zu welchem Composite hinzufügen?\n'+choices,'1'));if(!n||!items[n-1])return;await api(`/api/objects_v33/composites/${encodeURIComponent(items[n-1].id)}/fields`,{fields:[...selection.values()]});selection.clear();nav(`/objects_v33?selected=${encodeURIComponent(items[n-1].id)}&tab=general`)}catch(e){alert(e.message)}}
 function sameValue(a,b){return JSON.stringify(a)===JSON.stringify(b)}
 function controlHtml(e){const c=e.control;if(!c||!c.writable)return '<span class="small">nur lesen</span>';if(c.type==='bool')return `<label class="tuya-toggle" title="${e.raw?'EIN':'AUS'}"><input class="tuya-control ctl-bool" data-ep="${esc(e.endpoint)}" type="checkbox" ${e.raw?'checked':''}><span></span></label><span class="tuya-write-status" data-status="${esc(e.endpoint)}"></span>`;if(c.type==='enum'){const opts=(c.options||[]).map((o,i)=>`<option value="${i}" ${sameValue(o.value,e.raw)?'selected':''}>${esc(o.label)}</option>`).join('');return `<select class="tuya-control ctl-enum" data-ep="${esc(e.endpoint)}">${opts}</select><span class="tuya-write-status" data-status="${esc(e.endpoint)}"></span>`}if(c.type==='number'){const range=(c.slider&&c.min!==undefined&&c.max!==undefined)?`<input class="tuya-control ctl-range" data-ep="${esc(e.endpoint)}" type="range" min="${esc(c.min)}" max="${esc(c.max)}" step="${esc(c.step??1)}" value="${esc(e.raw)}">`:'';return `${range}<input class="tuya-control ctl-number" data-ep="${esc(e.endpoint)}" type="number" ${c.min!==undefined?`min="${esc(c.min)}"`:''} ${c.max!==undefined?`max="${esc(c.max)}"`:''} step="${esc(c.step??1)}" value="${esc(e.raw)}"><span class="tuya-write-status" data-status="${esc(e.endpoint)}"></span>`}return '<span class="small">nur lesen</span>'}
 function statusFor(ep,text,kind=''){const el=$('detail').querySelector(`[data-status="${CSS.escape(ep)}"]`);if(el){el.textContent=text;el.className='tuya-write-status '+kind}}
 async function writeEntry(e,value){statusFor(e.endpoint,'wird gesendet…');try{const data=await api('/api/tuya/write',{device_id:e.device_id,dps:e.dps,value});const returned=data.entry||{};if(Object.prototype.hasOwnProperty.call(returned,'raw')&&sameValue(returned.raw,value))statusFor(e.endpoint,'✓ übernommen','ok');else statusFor(e.endpoint,'✓ gesendet','ok');setTimeout(refresh,250)}catch(err){statusFor(e.endpoint,'✕ '+err.message,'bad');setTimeout(refresh,1500)}}
 function bindControls(map){$('detail').querySelectorAll('.ctl-bool').forEach(x=>x.onchange=()=>writeEntry(map[x.dataset.ep],x.checked));$('detail').querySelectorAll('.ctl-enum').forEach(x=>x.onchange=()=>{const e=map[x.dataset.ep],o=e.control.options[Number(x.value)];if(o)writeEntry(e,o.value)});$('detail').querySelectorAll('.ctl-number').forEach(x=>x.onchange=()=>{const e=map[x.dataset.ep],v=Number(x.value);if(Number.isFinite(v))writeEntry(e,v)});$('detail').querySelectorAll('.ctl-range').forEach(x=>{x.oninput=()=>{const n=$('detail').querySelector(`.ctl-number[data-ep="${CSS.escape(x.dataset.ep)}"]`);if(n)n.value=x.value};x.onchange=()=>{const e=map[x.dataset.ep],v=Number(x.value);if(Number.isFinite(v))writeEntry(e,v)}})}
 function renderDetail(){const d=devices.find(x=>x.device_id===selected);if(!d){$('detail').innerHTML='<div style="padding:40px;text-align:center"><h2>Gerät auswählen</h2></div>';return}const entries=Object.values(d.dps||{}).sort((a,b)=>Number(a.dps)-Number(b.dps));$('detail').innerHTML=`<h2>${esc(d.name||d.device_id)}</h2><div class="small" style="margin-bottom:12px">${esc(d.device_id)} · ${esc(d.ip)} · Tuya ${esc(d.version)}<br>${d.last_error?'<span style="color:#e03131">'+esc(d.last_error)+'</span>':esc(d.message||'')}</div><div class="button-row" style="margin-bottom:12px"><button id="createComposite" type="button">Composite aus Auswahl</button><button id="appendComposite" type="button">Zu Composite hinzufügen</button><span class="small">${selection.size} DPS ausgewählt</span></div><h3>Datenpunkte (DPS)</h3>${entries.length?entries.map(e=>`<div class="tuya-dp"><input type="checkbox" class="select-dps" data-ep="${esc(e.endpoint)}" ${selection.has(e.endpoint)?'checked':''}><b>${esc(e.dps)}</b><div><b>${esc(e.name)}</b><div class="small">${esc(e.endpoint)}</div></div><div class="tuya-value">${esc(e.display)}${String(e.display)!==String(e.raw)?` <span class="small">(${esc(e.raw)})</span>`:''}</div><div class="tuya-control-wrap">${controlHtml(e)}</div><button class="create" data-ep="${esc(e.endpoint)}">Objekt erstellen</button></div>`).join(''):'<div class="small">Noch keine DPS empfangen.</div>'}`;const map=Object.fromEntries(entries.map(e=>[e.endpoint,e]));$('detail').querySelectorAll('.create').forEach(b=>b.onclick=()=>nav(createUrl(d,map[b.dataset.ep])));$('detail').querySelectorAll('.select-dps').forEach(c=>c.onchange=()=>{const e=map[c.dataset.ep];if(c.checked)selection.set(e.endpoint,compositeField(e));else selection.delete(e.endpoint);renderDetail()});bindControls(map);$('createComposite').onclick=createComposite;$('appendComposite').onclick=appendComposite}
 async function refresh(){try{const r=await fetch('/api/tuya/discovery',{cache:'no-store'}),data=await r.json();devices=Array.isArray(data.devices)?data.devices:[];const online=devices.filter(d=>d.online).length,local=devices.filter(d=>String(d.message||'').startsWith('Lokal verbunden')).length,cloud=devices.filter(d=>String(d.message||'').includes('Cloud-Echtzeit')).length;$('dot').className='status-dot '+(data.dependency_error?'bad':online?'ok':'');$('statusText').textContent=data.dependency_error?('Abhängigkeit fehlt: '+data.dependency_error):`${local}/${devices.length} lokal verbunden${cloud?` · ${cloud} über Cloud-Echtzeit`:''}`;if(selected&&!devices.some(d=>d.device_id===selected))selected='';renderList();if(!document.activeElement?.classList?.contains('tuya-control'))renderDetail()}catch(e){$('dot').className='status-dot bad';$('statusText').textContent='Runtime nicht erreichbar'}}
 $('search').oninput=renderList;$('refreshBtn').onclick=refresh;refresh();setInterval(refresh,1000);
})();
</script>
'''
    return _core().embedded_page("Tuya Explorer", content)
