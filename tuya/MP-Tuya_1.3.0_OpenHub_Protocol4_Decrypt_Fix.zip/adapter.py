from __future__ import annotations

from dataclasses import dataclass
from typing import ClassVar

from app.services.object_adapter_engine import BaseAdapter


@dataclass
class TuyaAdapter(BaseAdapter):
    protocol: ClassVar[str] = "tuya"
    device_id: str = ""
    dps: str = ""
    target_value_path: str = ""

    @property
    def endpoint(self) -> str:
        device_id = str(self.device_id or "").strip()
        dps = str(self.dps or "").strip()
        return f"{device_id}/{dps}" if device_id and dps else ""

    def validate(self) -> list[str]:
        errors = super().validate()
        if self.enabled and self.direction in {"out", "both"}:
            if not str(self.device_id or "").strip():
                errors.append("Tuya Device-ID fehlt")
            if not str(self.dps or "").strip():
                errors.append("Tuya DPS fehlt")
        return errors


def adapter_from_form(form_data):
    return TuyaAdapter(
        enabled="enabled" in form_data,
        direction="out",
        datatype=str(form_data.get("datatype", "auto") or "auto"),
        device_id=str(form_data.get("device_id", "") or "").strip(),
        dps=str(form_data.get("dps", "") or "").strip(),
        target_value_path=str(form_data.get("target_value_path", "") or "").strip(),
    )
