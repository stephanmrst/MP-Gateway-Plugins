"""MP-Tuya plugin."""
