from __future__ import annotations

import threading
import time
from collections import OrderedDict
from datetime import datetime
from zoneinfo import ZoneInfo
from typing import Any, Callable

BERLIN = ZoneInfo("Europe/Berlin")

# First known profile from the user's local Tuya 3.3 PIR sensors.
# Known Tuya Cloud status codes that need translating back to raw DPS ids.
# Keep this separate from PIR_DPS because e.g. DPS 1 means different things on
# different device categories. The cloud code itself is the semantic hint.
CLOUD_CODE_DPS = {
    "doorcontact_state": "1",
    "battery_percentage": "2",
}

PIR_DPS = {
    # ``write`` is intentionally only present for parameters we know are writable
    # on the first locally tested PIR profile. Unknown DPS remain read-only in the
    # Explorer until a device profile/schema proves otherwise.
    "20": {"name": "switch_led", "write": {"type": "bool"}},
    "21": {"name": "work_mode", "enum": {0: "white"}},
    "28": {"name": "control_data"},
    "51": {
        "name": "device_mode",
        "enum": {0: "Sensor", 1: "Manual", "auto": "Sensor", "manual": "Manual"},
        "write": {
            "type": "enum",
            "options": [
                {"raw": "auto", "label": "Sensor"},
                {"raw": "manual", "label": "Manual"},
            ],
            "numeric_options": [
                {"raw": 0, "label": "Sensor"},
                {"raw": 1, "label": "Manual"},
            ],
        },
    },
    "52": {"name": "pir_state", "enum": {0: "EIN", 1: "AUS", "pir": "EIN", "none": "AUS"}, "bool_map": {0: True, 1: False, "pir": True, "none": False}},
    "53": {
        "name": "cds",
        "enum": {
            "5lux": "5 lux", "10lux": "10 lux", "50lux": "50 lux",
            "300lux": "300 lux", "2000lux": "2000 lux", "now": "Immer / now",
        },
        "write": {
            "type": "enum",
            "options": [
                {"raw": "5lux", "label": "5 lux"},
                {"raw": "10lux", "label": "10 lux"},
                {"raw": "50lux", "label": "50 lux"},
                {"raw": "300lux", "label": "300 lux"},
                {"raw": "2000lux", "label": "2000 lux"},
                {"raw": "now", "label": "Immer / now"},
            ],
        },
    },
    "54": {
        "name": "pir_sensitivity",
        "enum": {0: "Nah", 1: "Mittel", 2: "Weit", "low": "Nah", "middle": "Mittel", "high": "Weit"},
        "write": {
            "type": "enum",
            "options": [
                {"raw": "low", "label": "Nah"},
                {"raw": "middle", "label": "Mittel"},
                {"raw": "high", "label": "Weit"},
            ],
            "numeric_options": [
                {"raw": 0, "label": "Nah"},
                {"raw": 1, "label": "Mittel"},
                {"raw": 2, "label": "Weit"},
            ],
        },
    },
    "55": {"name": "pir_delay", "write": {"type": "number", "step": 1}},
    "56": {"name": "switch_pir", "write": {"type": "bool"}},
    "57": {"name": "pir_resume_countdown"},
}


def _now() -> str:
    return datetime.now(BERLIN).isoformat(timespec="seconds")


def dps_meta(dps: str, raw: Any) -> dict[str, Any]:
    key = str(dps)
    spec = dict(PIR_DPS.get(key, {}))
    name = spec.get("name") or f"DPS {key}"
    enum = spec.get("enum") or {}
    display = enum.get(raw, raw)
    if "bool_map" in spec and raw in spec["bool_map"]:
        value = spec["bool_map"][raw]
        datatype = "bool"
    else:
        value = raw
        datatype = "bool" if isinstance(raw, bool) else "number" if isinstance(raw, (int, float)) and not isinstance(raw, bool) else "auto"

    control = None
    write = spec.get("write") or {}
    control_type = str(write.get("type") or "")
    if control_type == "bool":
        # Writable capability belongs to the DPS profile, not to the Python type
        # TinyTuya happened to return in the latest status packet.
        control = {"type": "bool", "writable": True}
    elif control_type == "enum":
        # Keep the exact Tuya raw value for TX, while allowing a friendly UI label.
        configured = list(write.get("options") or [])
        numeric_configured = list(write.get("numeric_options") or [])
        if isinstance(raw, (int, float)) and not isinstance(raw, bool) and numeric_configured:
            options = [{"value": item.get("raw"), "label": item.get("label", item.get("raw"))} for item in numeric_configured]
        elif configured:
            options = [{"value": item.get("raw"), "label": item.get("label", item.get("raw"))} for item in configured]
        else:
            labels = list(write.get("labels") or [])
            if isinstance(raw, (int, float)) and not isinstance(raw, bool):
                options = [{"value": i, "label": label} for i, label in enumerate(labels)]
            else:
                options = [{"value": label, "label": label} for label in labels]
        control = {"type": "enum", "writable": True, "options": options}
    elif control_type == "number":
        control = {"type": "number", "writable": True, "step": write.get("step", 1)}
        if "min" in write and "max" in write:
            control.update({"min": write["min"], "max": write["max"], "slider": True})

    return {"name": name, "display": display, "value": value, "datatype": datatype, "raw": raw, "control": control}


class TuyaRuntime:
    def __init__(self, config_loader: Callable[[], dict[str, Any]], logger, on_value: Callable[..., None]):
        self.config_loader = config_loader
        self.logger = logger
        self.on_value = on_value
        self._stop = threading.Event()
        self._lock = threading.RLock()
        self._threads: dict[str, threading.Thread] = {}
        self._generation = 0
        self._entries: OrderedDict[str, dict[str, Any]] = OrderedDict()
        self._devices: dict[str, dict[str, Any]] = {}
        self._clients: dict[str, Any] = {}
        self._io_locks: dict[str, threading.RLock] = {}
        self._dependency_error = ""
        try:
            import tinytuya  # noqa: F401
        except Exception as exc:
            self._dependency_error = str(exc)

    def _log(self, level: str, message: str, *args) -> None:
        try:
            getattr(self.logger, level)(message, *args)
        except Exception:
            pass

    def start(self) -> None:
        self.reload()

    def reload(self, cfg: dict[str, Any] | None = None) -> None:
        self._generation += 1
        generation = self._generation
        cfg = dict(cfg or self.config_loader() or {})
        with self._lock:
            self._devices = {}
            self._clients = {}
            self._io_locks = {}
        if self._dependency_error:
            self._log("error", "MP-Tuya: tinytuya fehlt: %s", self._dependency_error)
            return
        if not cfg.get("enabled", True):
            return
        for item in cfg.get("devices") or []:
            if not item.get("enabled", True):
                continue
            dev_id = str(item.get("device_id") or "").strip()
            ip = str(item.get("ip") or "").strip()
            key = str(item.get("local_key") or "")
            if not dev_id:
                continue
            local_ready = bool(ip and key)
            with self._lock:
                self._io_locks[dev_id] = threading.RLock()
                self._devices[dev_id] = {
                    "device_id": dev_id, "name": item.get("name") or dev_id, "ip": ip,
                    "version": item.get("version") or "3.3", "profile": item.get("profile") or "auto",
                    "online": False,
                    "state": "starting" if local_ready else "cloud_wait",
                    "message": "Verbindung wird aufgebaut" if local_ready else "Keine lokale Verbindung – wartet auf Cloud-Echtzeit",
                    "last_update": "", "last_error": "", "dps": {},
                }
            if not local_ready:
                continue
            thread = threading.Thread(target=self._device_loop, args=(dict(item), cfg, generation), daemon=True, name=f"mp-tuya-{dev_id[-6:]}")
            self._threads[dev_id] = thread
            thread.start()

    def _update_device(self, dev_id: str, **changes) -> None:
        with self._lock:
            if dev_id in self._devices:
                self._devices[dev_id].update(changes)

    def _handle_payload(self, item: dict[str, Any], payload: Any) -> None:
        dev_id = str(item.get("device_id") or "")
        if not isinstance(payload, dict):
            return
        dps = payload.get("dps")
        if not isinstance(dps, dict):
            return
        now = _now()
        # Tuya event packets often contain only the DPS that changed.  Keep the
        # last known full device snapshot and merge partial event payloads into it
        # instead of replacing the complete DPS tree on every update.
        with self._lock:
            previous_dps = dict((self._devices.get(dev_id) or {}).get("dps") or {})
        normalized = previous_dps
        for dps_id, raw in dps.items():
            key = str(dps_id)
            meta = dps_meta(key, raw)
            endpoint = f"{dev_id}/{key}"
            entry = {
                "device_id": dev_id,
                "device_name": item.get("name") or dev_id,
                "ip": item.get("ip") or "",
                "version": item.get("version") or "3.3",
                "dps": key,
                "name": meta["name"],
                "raw": meta["raw"],
                "value": meta["value"],
                "display": meta["display"],
                "datatype": meta["datatype"],
                # Explorer control metadata must travel with the runtime entry.
                # Without this field the browser correctly falls back to
                # "nur lesen", even though dps_meta() knows the DPS is writable.
                "control": meta["control"],
                "endpoint": endpoint,
                "updated_at": now,
            }
            normalized[key] = entry
            with self._lock:
                self._entries[endpoint] = entry
                self._entries.move_to_end(endpoint)
                while len(self._entries) > 2000:
                    self._entries.popitem(last=False)
            try:
                self.on_value(endpoint, meta["value"], now, entry)
            except Exception:
                self._log("exception", "MP-Tuya Livewert konnte nicht übergeben werden: %s", endpoint)
        self._update_device(dev_id, online=True, state="connected", message="Lokal verbunden", last_update=now, last_error="", dps=normalized)

    def _device_loop(self, item: dict[str, Any], cfg: dict[str, Any], generation: int) -> None:
        import tinytuya
        dev_id = str(item.get("device_id") or "")
        timeout = float(cfg.get("socket_timeout", 1.0) or 1.0)
        poll_interval = float(cfg.get("poll_interval", 15.0) or 15.0)
        retry_delay = 3.0
        while generation == self._generation and not self._stop.is_set():
            try:
                device = tinytuya.Device(dev_id, str(item.get("ip") or ""), str(item.get("local_key") or ""), version=float(item.get("version") or 3.3), persist=True)
                device.set_socketTimeout(timeout)
                device.set_socketRetryLimit(1)
                device.set_socketRetryDelay(1)
                self._update_device(dev_id, state="connecting", message="Lokale Verbindung wird aufgebaut")
                with self._lock:
                    self._clients[dev_id] = device
                    io_lock = self._io_locks.setdefault(dev_id, threading.RLock())
                with io_lock:
                    first = device.status()
                self._handle_payload(item, first)
                last_query = time.monotonic()
                last_heartbeat = time.monotonic()
                while generation == self._generation and not self._stop.is_set():
                    try:
                        with io_lock:
                            data = device.receive()
                        if data:
                            self._handle_payload(item, data)
                    except Exception as exc:
                        # A receive timeout is normal for quiet devices; status queries below keep them fresh.
                        text = str(exc).lower()
                        if "timeout" not in text and "timed out" not in text:
                            raise
                    now_mono = time.monotonic()
                    if now_mono - last_query >= poll_interval:
                        with io_lock:
                            data = device.status()
                        self._handle_payload(item, data)
                        last_query = now_mono
                    elif now_mono - last_heartbeat >= 8.0:
                        try:
                            with io_lock:
                                device.heartbeat(nowait=True)
                        except TypeError:
                            with io_lock:
                                device.heartbeat()
                        last_heartbeat = now_mono
                try:
                    device.close()
                except Exception:
                    pass
                with self._lock:
                    if self._clients.get(dev_id) is device:
                        self._clients.pop(dev_id, None)
            except Exception as exc:
                with self._lock:
                    self._clients.pop(dev_id, None)
                self._update_device(dev_id, online=False, state="error", message="Lokale Verbindung getrennt", last_error=str(exc))
                self._log("warning", "MP-Tuya %s (%s): %s", item.get("name") or dev_id, dev_id, exc)
                time.sleep(retry_delay)


    def _dps_from_code(self, code: str) -> str | None:
        code = str(code or "").strip()
        if not code:
            return None
        if code.isdigit():
            return code
        if code in CLOUD_CODE_DPS:
            return str(CLOUD_CODE_DPS[code])
        for dps_id, spec in PIR_DPS.items():
            if str(spec.get("name") or "").strip() == code:
                return str(dps_id)
        return None

    def handle_cloud_update(self, device_id: str, dps_or_code: str, raw: Any) -> bool:
        """Feed a Tuya IoT/Cloud update into the same endpoint path as LAN data."""
        device_id = str(device_id or "").strip()
        key = self._dps_from_code(str(dps_or_code or ""))
        if not device_id or not key:
            return False
        cfg = self.config_loader() or {}
        item = None
        for candidate in cfg.get("devices") or []:
            if str(candidate.get("device_id") or "").strip() == device_id:
                item = dict(candidate)
                break
        if item is None:
            return False
        # LAN is the primary transport. Cloud realtime is a fallback for sleeping
        # or otherwise non-locally-connected devices and must not race the local socket.
        with self._lock:
            if device_id in self._clients:
                return False
        now = _now()
        cloud_code = str(dps_or_code or "").strip()
        meta = dps_meta(key, raw)
        if cloud_code and not cloud_code.isdigit():
            meta["name"] = cloud_code
        endpoint = f"{device_id}/{key}"
        with self._lock:
            dev = self._devices.setdefault(device_id, {
                "device_id": device_id, "name": item.get("name") or device_id, "ip": item.get("ip") or "",
                "version": item.get("version") or "3.3", "profile": item.get("profile") or "auto",
                "online": False, "state": "cloud", "message": "Cloud-Echtzeit aktiv", "last_update": "", "last_error": "", "dps": {},
            })
            previous_dps = dict(dev.get("dps") or {})
        entry = {
            "device_id": device_id,
            "device_name": item.get("name") or device_id,
            "ip": item.get("ip") or "",
            "version": item.get("version") or "3.3",
            "dps": key,
            "name": meta["name"], "raw": meta["raw"], "value": meta["value"],
            "display": meta["display"], "datatype": meta["datatype"], "control": meta["control"],
            "endpoint": endpoint, "updated_at": now, "transport": "cloud",
        }
        previous_dps[key] = entry
        with self._lock:
            self._entries[endpoint] = entry
            self._entries.move_to_end(endpoint)
            while len(self._entries) > 2000:
                self._entries.popitem(last=False)
        try:
            self.on_value(endpoint, meta["value"], now, entry)
        except Exception:
            self._log("exception", "MP-Tuya Cloud-Livewert konnte nicht übergeben werden: %s", endpoint)
        with self._lock:
            local_connected = device_id in self._clients
        self._update_device(
            device_id,
            online=True if not local_connected else True,
            state="connected" if local_connected else "cloud",
            message="Lokal verbunden + Cloud-Echtzeit" if local_connected else "Cloud-Echtzeit",
            last_update=now,
            last_error="",
            dps=previous_dps,
        )
        return True

    def current_entry(self, device_id: str, dps: str) -> dict[str, Any] | None:
        endpoint = f"{str(device_id or '').strip()}/{str(dps or '').strip()}"
        with self._lock:
            entry = self._entries.get(endpoint)
            return dict(entry) if entry else None

    def write_value(self, device_id: str, dps: str, value: Any) -> tuple[bool, str]:
        device_id = str(device_id or "").strip()
        dps = str(dps or "").strip()
        with self._lock:
            device = self._clients.get(device_id)
            io_lock = self._io_locks.get(device_id)
            dev_state = dict(self._devices.get(device_id) or {})
        if device is None or io_lock is None:
            return False, "Gerät nicht lokal verbunden"
        try:
            try:
                dps_num = int(dps)
            except Exception:
                dps_num = dps
            with io_lock:
                result = device.set_value(dps_num, value)
                # For manual Explorer changes, read the device back immediately.
                # This keeps the UI honest: the displayed value comes from the
                # device, not from an optimistic browser-side assignment.
                try:
                    status = device.status()
                except Exception:
                    status = None
            item = {
                "device_id": device_id,
                "name": dev_state.get("name") or device_id,
                "ip": dev_state.get("ip") or "",
                "version": dev_state.get("version") or "3.3",
            }
            if isinstance(result, dict) and isinstance(result.get("dps"), dict):
                self._handle_payload(item, result)
            if isinstance(status, dict) and isinstance(status.get("dps"), dict):
                self._handle_payload(item, status)
            if isinstance(result, dict) and result.get("Error"):
                return False, str(result.get("Error"))
            self._log("info", "MP-Tuya TX %s/%s = %r", device_id, dps, value)
            return True, "ok"
        except Exception as exc:
            return False, str(exc)

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            devices = [dict(v) for v in self._devices.values()]
            entries = [dict(v) for v in reversed(self._entries.values())]
        return {"dependency_error": self._dependency_error, "devices": devices, "entries": entries}

    def test_device(self, item: dict[str, Any], timeout: float = 2.0) -> dict[str, Any]:
        if self._dependency_error:
            return {"ok": False, "error": f"tinytuya fehlt: {self._dependency_error}"}
        try:
            import tinytuya
            d = tinytuya.Device(str(item.get("device_id") or ""), str(item.get("ip") or ""), str(item.get("local_key") or ""), version=float(item.get("version") or 3.3))
            d.set_socketTimeout(timeout)
            d.set_socketRetryLimit(1)
            data = d.status()
            try:
                d.close()
            except Exception:
                pass
            if isinstance(data, dict) and isinstance(data.get("dps"), dict):
                return {"ok": True, "dps": data["dps"]}
            return {"ok": False, "error": str(data)}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}
