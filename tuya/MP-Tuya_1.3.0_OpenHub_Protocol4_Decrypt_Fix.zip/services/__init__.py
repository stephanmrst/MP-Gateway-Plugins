"""MP-Tuya services."""
