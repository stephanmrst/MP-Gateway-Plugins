from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import time
import urllib.parse
import urllib.request
import uuid
from typing import Any

# Mobile-app API settings used by the Smart Life / Tuya Smart applications.
# The request/login flow is reimplemented in Python so MP-Tuya does not require
# Node.js or ioBroker for its one-time cloud device import.
APP_PROFILES = {
    "smart_life": {
        "ttid": "smart_life",
        "key": "ekmnwp9f5pnh3trdtpgy",
        "secret": "r3me7ghmxjevrvnpemwmhw3fxtacphyg",
        "secret2": "jfg5rs5kkmrj5mxahugvucrsvw43t48x",
        "cert_sign": "0F:C3:61:99:9C:C0:C3:5B:A8:AC:A5:7D:AA:55:93:A2:0C:F5:57:27:70:2E:A8:5A:D7:B3:22:89:49:F8:88:FE",
    },
    "tuya_smart": {
        "ttid": "tuya",
        "key": "3fjrekuxank9eaej3gcx",
        "secret": "aq7xvqcyqcnegvew793pqjmhv77rneqc",
        "secret2": "vay9g59g9g99qf3rtqptmc3emhkanwkx",
        "cert_sign": "93:21:9F:C2:73:E2:20:0F:4A:DE:E5:F7:19:1D:C6:56:BA:2A:2D:7B:2F:F5:D2:4C:D5:5C:4B:61:55:00:1E:40",
    },
}

REGION_ENDPOINTS = {
    "EU": "https://a1.tuyaeu.com/api.json",
    "AZ": "https://a1.tuyaus.com/api.json",
    "AY": "https://a1.tuyacn.com/api.json",
    "IN": "https://a1.tuyain.com/api.json",
}

SIGN_KEYS = [
    "a", "v", "lat", "lon", "lang", "deviceId", "imei", "imsi",
    "appVersion", "ttid", "isH5", "h5Token", "os", "clientId",
    "postData", "time", "requestId", "n4h5", "sid", "sp", "et",
]


class TuyaCloudError(RuntimeError):
    pass


def _md5(data: str | bytes) -> str:
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.md5(data).hexdigest()


def _mobile_hash(data: str) -> str:
    digest = _md5(data)
    return digest[8:16] + digest[0:8] + digest[24:32] + digest[16:24]


def _rsa_no_padding_encrypt(message: bytes, modulus: Any, exponent: Any) -> str:
    """Mirror RSA_NO_PADDING used by the Tuya mobile login flow."""
    if isinstance(modulus, int):
        n = modulus
    else:
        raw = str(modulus or "").strip()
        if not raw:
            raise TuyaCloudError("Cloud-Login lieferte keinen RSA Public Key")
        # Tuya has exposed this field as hex in the mobile API. Accept base64 and
        # decimal too so minor response format changes do not break immediately.
        # @tuyapi/cloud imports token.publicKey directly into node-rsa 1.1.1.
        # node-rsa passes string components to JSBN without an explicit radix;
        # JSBN therefore treats a numeric string as decimal.  Tuya's mobile API
        # currently returns the RSA modulus in exactly that decimal form.
        #
        # Keep fallbacks for possible API format changes, but decimal MUST be
        # attempted first or the password hash gets encrypted with the wrong key
        # and Tuya misleadingly responds with USER_PASSWD_WRONG.
        if raw.isdigit():
            n = int(raw, 10)
        else:
            try:
                decoded = base64.b64decode(raw, validate=True)
                if decoded:
                    n = int.from_bytes(decoded, "big")
                else:
                    raise ValueError("empty base64")
            except Exception:
                n = int(raw, 16)
    e = int(exponent)
    size = (n.bit_length() + 7) // 8
    m = int.from_bytes(message, "big")
    if m >= n:
        raise TuyaCloudError("RSA-Nachricht ist größer als der Public Key")
    encrypted = pow(m, e, n).to_bytes(size, "big")
    return encrypted.hex()


class TuyaAppCloud:
    def __init__(
        self,
        username: str,
        password: str,
        region: str = "EU",
        app_type: str = "smart_life",
        device_id: str = "",
        sid: str = "",
        endpoint: str = "",
        app_region: str = "",
        timeout: float = 12.0,
    ):
        app_type = str(app_type or "smart_life").strip().lower()
        if app_type not in APP_PROFILES:
            raise TuyaCloudError(f"Unbekannter Tuya App-Typ: {app_type}")
        self.profile = APP_PROFILES[app_type]
        self.username = str(username or "").strip()
        self.password = str(password or "")
        self.region = str(app_region or region or "EU").strip().upper()
        self.endpoint = str(endpoint or REGION_ENDPOINTS.get(self.region) or REGION_ENDPOINTS["EU"])
        self.device_id = str(device_id or "") or secrets.token_hex(22)[:44]
        self.sid = str(sid or "")
        self.timeout = float(timeout)
        self.last_login: dict[str, Any] = {}

    def request(
        self,
        action: str,
        *,
        data: Any = None,
        gid: str = "",
        version: str = "1.0",
        requires_sid: bool = True,
    ) -> Any:
        if requires_sid and not self.sid:
            raise TuyaCloudError("Cloud-Session fehlt")
        pairs: dict[str, Any] = {
            "a": action,
            "deviceId": self.device_id,
            "os": "Android",
            "lang": "en",
            "v": version or "1.0",
            "clientId": self.profile["key"],
            "time": round(time.time()),
            "et": "0.0.1",
            "ttid": self.profile["ttid"],
            "appVersion": "3.8.5",
            "appRnVersion": "5.11",
            "platform": "Android",
            "requestId": str(uuid.uuid4()),
        }
        if data is not None:
            pairs["postData"] = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
        if gid:
            pairs["gid"] = gid
        if requires_sid:
            pairs["sid"] = self.sid

        parts = []
        for key in sorted(pairs):
            if key not in SIGN_KEYS:
                continue
            value = pairs.get(key)
            if value is None or value == "":
                continue
            if key == "postData":
                value = _mobile_hash(str(value))
            parts.append(f"{key}={value}")
        to_sign = "||".join(parts)
        hmac_key = f"{self.profile['cert_sign']}_{self.profile['secret2']}_{self.profile['secret']}"
        pairs["sign"] = hmac.new(hmac_key.encode(), to_sign.encode(), hashlib.sha256).hexdigest()

        url = self.endpoint + ("&" if "?" in self.endpoint else "?") + urllib.parse.urlencode(pairs)
        req = urllib.request.Request(url, headers={
            "User-Agent": "MP-Tuya/1.1",
            "Accept": "application/json",
        })
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                payload = json.loads(response.read().decode("utf-8", errors="replace"))
        except Exception as exc:
            raise TuyaCloudError(f"Tuya Cloud nicht erreichbar: {exc}") from exc

        if not isinstance(payload, dict):
            raise TuyaCloudError("Ungültige Antwort der Tuya Cloud")
        if payload.get("success") is False:
            code = payload.get("errorCode") or payload.get("code") or "Cloud-Fehler"
            message = payload.get("errorMsg") or payload.get("msg") or "Unbekannter Fehler"
            raise TuyaCloudError(f"{code}: {message}")
        return payload.get("result")

    def login(self) -> dict[str, Any]:
        if not self.username or not self.password:
            raise TuyaCloudError("Cloud-Benutzername oder Passwort fehlt")

        token = self.request(
            "tuya.m.user.email.token.create",
            data={"countryCode": self.region, "email": self.username},
            requires_sid=False,
        )
        if not isinstance(token, dict):
            raise TuyaCloudError("Tuya Cloud lieferte keinen Login-Token")

        encrypted = _rsa_no_padding_encrypt(
            _md5(self.password).encode("ascii"),
            token.get("publicKey"),
            token.get("exponent") or 65537,
        )
        result = self.request(
            "tuya.m.user.email.password.login",
            data={
                "countryCode": self.region,
                "email": self.username,
                "passwd": encrypted,
                "ifencrypt": 1,
                "options": {"group": 1},
                "token": token.get("token"),
            },
            requires_sid=False,
        )
        if not isinstance(result, dict) or not result.get("sid"):
            raise TuyaCloudError("Cloud-Login ohne Session-ID")

        domain = result.get("domain") or {}
        mobile_url = str(domain.get("mobileApiUrl") or "").rstrip("/")
        if mobile_url and not self.endpoint.startswith(mobile_url):
            self.endpoint = mobile_url + "/api.json"
            self.region = str(domain.get("regionCode") or self.region)
        self.sid = str(result["sid"])
        self.last_login = result
        return result

    def locations(self) -> list[dict[str, Any]]:
        result = self.request("tuya.m.location.list", version="2.1")
        return result if isinstance(result, list) else []

    def group_devices(self, group_id: str) -> list[dict[str, Any]]:
        result = self.request("tuya.m.my.group.device.list", gid=str(group_id), version="2.0")
        return result if isinstance(result, list) else []


def _device_id(item: dict[str, Any]) -> str:
    for key in ("id", "devId", "deviceId", "gwId"):
        value = str(item.get(key) or "").strip()
        if value:
            return value
    return ""


def _device_name(item: dict[str, Any], fallback: str) -> str:
    for key in ("name", "devName", "deviceName"):
        value = str(item.get(key) or "").strip()
        if value:
            return value
    return fallback


def _local_key(item: dict[str, Any]) -> str:
    for key in ("localKey", "local_key", "key"):
        value = str(item.get(key) or "")
        if value:
            return value
    return ""


def _location_id(item: dict[str, Any]) -> str:
    for key in ("groupId", "gid", "id"):
        value = str(item.get(key) or "").strip()
        if value:
            return value
    return ""


def local_scan(timeout: int = 8) -> dict[str, dict[str, str]]:
    """Return device-id -> {ip, version} using TinyTuya's passive LAN scanner."""
    try:
        import tinytuya
        result = tinytuya.deviceScan(False, int(timeout))
    except Exception:
        return {}
    found: dict[str, dict[str, str]] = {}
    if not isinstance(result, dict):
        return found
    for ip, data in result.items():
        if not isinstance(data, dict):
            continue
        dev_id = str(data.get("gwId") or data.get("id") or "").strip()
        if not dev_id:
            continue
        found[dev_id] = {
            "ip": str(data.get("ip") or ip or ""),
            "version": str(data.get("version") or ""),
        }
    return found


def sync_devices(cfg: dict[str, Any], logger=None) -> tuple[dict[str, Any], dict[str, Any]]:
    cloud_cfg = dict(cfg.get("cloud") or {})
    client = TuyaAppCloud(
        cloud_cfg.get("username", ""),
        cloud_cfg.get("password", ""),
        cloud_cfg.get("region", "EU"),
        cloud_cfg.get("app_type", "smart_life"),
        cloud_cfg.get("device_id", ""),
        cloud_cfg.get("sid", ""),
        cloud_cfg.get("endpoint", ""),
        cloud_cfg.get("app_region", ""),
    )
    login = client.login()
    groups = client.locations()
    imported: dict[str, dict[str, Any]] = {}
    for group in groups:
        gid = _location_id(group)
        if not gid:
            continue
        for raw in client.group_devices(gid):
            if not isinstance(raw, dict):
                continue
            dev_id = _device_id(raw)
            if not dev_id:
                continue
            entry = imported.setdefault(dev_id, {
                "enabled": True,
                "name": _device_name(raw, dev_id),
                "device_id": dev_id,
                "ip": "",
                "local_key": _local_key(raw),
                "version": "3.3",
                "profile": "auto",
            })
            # Prefer non-empty cloud values if the same device appears more than once.
            key = _local_key(raw)
            if key:
                entry["local_key"] = key
            name = _device_name(raw, "")
            if name:
                entry["name"] = name

    scan = local_scan(int(cloud_cfg.get("scan_seconds", 8) or 8))
    for dev_id, local in scan.items():
        if dev_id in imported:
            if local.get("ip"):
                imported[dev_id]["ip"] = local["ip"]
            if local.get("version"):
                imported[dev_id]["version"] = local["version"]

    existing = {str(x.get("device_id") or ""): dict(x) for x in cfg.get("devices") or [] if isinstance(x, dict) and x.get("device_id")}
    added = updated = 0
    for dev_id, cloud_dev in imported.items():
        if dev_id in existing:
            old = existing[dev_id]
            # Cloud owns identity/name/key. Preserve manual/local settings if the
            # cloud/LAN scan has no better value.
            old["name"] = cloud_dev.get("name") or old.get("name") or dev_id
            if cloud_dev.get("local_key"):
                old["local_key"] = cloud_dev["local_key"]
            if cloud_dev.get("ip"):
                old["ip"] = cloud_dev["ip"]
            if cloud_dev.get("version"):
                old["version"] = cloud_dev["version"]
            existing[dev_id] = old
            updated += 1
        else:
            existing[dev_id] = cloud_dev
            added += 1

    # Preserve manually configured devices which are not returned by this cloud account.
    ordered_ids = [str(x.get("device_id") or "") for x in cfg.get("devices") or [] if isinstance(x, dict) and x.get("device_id")]
    for dev_id in imported:
        if dev_id not in ordered_ids:
            ordered_ids.append(dev_id)
    cfg["devices"] = [existing[x] for x in ordered_ids if x in existing]

    cloud_cfg.update({
        "device_id": client.device_id,
        "sid": client.sid,
        "endpoint": client.endpoint,
        "app_region": client.region,
        "last_sync": int(time.time()),
    })
    cfg["cloud"] = cloud_cfg

    missing_ip = sum(1 for x in imported.values() if not x.get("ip"))
    report = {
        "cloud_devices": len(imported),
        "groups": len(groups),
        "added": added,
        "updated": updated,
        "lan_found": len(scan),
        "missing_ip": missing_ip,
    }
    if logger:
        logger.info(
            "MP-Tuya Cloud-Sync: %s Geräte, %s neu, %s aktualisiert, %s LAN-Treffer",
            report["cloud_devices"], added, updated, len(scan),
        )
    return cfg, report
