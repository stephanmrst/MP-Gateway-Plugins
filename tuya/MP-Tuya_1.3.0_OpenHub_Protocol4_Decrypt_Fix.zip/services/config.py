from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from app.engine import port

PLUGIN_DATA_DIR = Path(str(port.CONFIG_DIR)) / "plugin_data" / "tuya"
CONFIG_FILE = PLUGIN_DATA_DIR / "config.json"

DEFAULT_CONFIG: dict[str, Any] = {
    "enabled": True,
    "poll_interval": 15.0,
    "socket_timeout": 1.0,
    "devices": [],
    "cloud": {
        "app_type": "smart_life",
        "region": "EU",
        "username": "",
        "password": "",
        "sync_on_start": False,
        "scan_seconds": 8,
        "device_id": "",
        "sid": "",
        "endpoint": "",
        "app_region": "",
        "last_sync": 0,
    },
    "iot_realtime": {
        "enabled": False,
        "access_id": "",
        "access_secret": "",
        "country_code": "49",
        "app_schema": "smartlife",
        "username": "",
        "password": "",
        "encrypted_version": "2.0",
    },
}


def _normalize_device(item: dict[str, Any], index: int = 0) -> dict[str, Any]:
    return {
        "enabled": bool(item.get("enabled", True)),
        "name": str(item.get("name") or f"Tuya Gerät {index + 1}").strip(),
        "device_id": str(item.get("device_id") or "").strip(),
        "ip": str(item.get("ip") or "").strip(),
        "local_key": str(item.get("local_key") or ""),
        "version": str(item.get("version") or "3.3").strip() or "3.3",
        "profile": str(item.get("profile") or "auto").strip().lower() or "auto",
    }


def load_config() -> dict[str, Any]:
    cfg = dict(DEFAULT_CONFIG)
    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            cfg.update(data)
    except FileNotFoundError:
        pass
    except Exception:
        pass
    devices = cfg.get("devices") or []
    cfg["devices"] = [_normalize_device(x, i) for i, x in enumerate(devices) if isinstance(x, dict)]
    try:
        cfg["poll_interval"] = max(2.0, float(cfg.get("poll_interval", 15.0)))
    except (TypeError, ValueError):
        cfg["poll_interval"] = 15.0
    try:
        cfg["socket_timeout"] = max(0.3, min(5.0, float(cfg.get("socket_timeout", 1.0))))
    except (TypeError, ValueError):
        cfg["socket_timeout"] = 1.0
    cloud = dict(DEFAULT_CONFIG["cloud"])
    if isinstance(cfg.get("cloud"), dict):
        cloud.update(cfg["cloud"])
    cloud["app_type"] = str(cloud.get("app_type") or "smart_life").strip().lower()
    cloud["region"] = str(cloud.get("region") or "EU").strip().upper()
    cloud["username"] = str(cloud.get("username") or "").strip()
    cloud["password"] = str(cloud.get("password") or "")
    cloud["sync_on_start"] = bool(cloud.get("sync_on_start", False))
    try:
        cloud["scan_seconds"] = max(3, min(30, int(cloud.get("scan_seconds", 8))))
    except Exception:
        cloud["scan_seconds"] = 8
    cfg["cloud"] = cloud
    rt = dict(DEFAULT_CONFIG["iot_realtime"])
    if isinstance(cfg.get("iot_realtime"), dict):
        rt.update(cfg["iot_realtime"])
    rt["enabled"] = bool(rt.get("enabled", False))
    rt["access_id"] = str(rt.get("access_id") or "").strip()
    rt["access_secret"] = str(rt.get("access_secret") or "")
    rt["country_code"] = str(rt.get("country_code") or "49").lstrip("+")
    rt["app_schema"] = str(rt.get("app_schema") or "smartlife").strip()
    if rt["app_schema"] == "smart_life":
        rt["app_schema"] = "smartlife"
    rt["username"] = str(rt.get("username") or "").strip()
    rt["password"] = str(rt.get("password") or "")
    cfg["iot_realtime"] = rt
    return cfg


def save_config(cfg: dict[str, Any]) -> None:
    PLUGIN_DATA_DIR.mkdir(parents=True, exist_ok=True)
    normalized = dict(DEFAULT_CONFIG)
    normalized.update(cfg or {})
    normalized["devices"] = [_normalize_device(x, i) for i, x in enumerate(normalized.get("devices") or []) if isinstance(x, dict)]
    cloud = dict(DEFAULT_CONFIG["cloud"])
    if isinstance(normalized.get("cloud"), dict):
        cloud.update(normalized["cloud"])
    normalized["cloud"] = cloud
    rt = dict(DEFAULT_CONFIG["iot_realtime"])
    if isinstance(normalized.get("iot_realtime"), dict):
        rt.update(normalized["iot_realtime"])
    normalized["iot_realtime"] = rt
    CONFIG_FILE.write_text(json.dumps(normalized, indent=2, ensure_ascii=False), encoding="utf-8")
