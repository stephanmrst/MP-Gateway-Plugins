from __future__ import annotations


def register_adapter() -> None:
    from app.services.object_adapter_engine import register_adapter
    from .adapter import TuyaAdapter, adapter_from_form
    register_adapter(TuyaAdapter, form_parser=adapter_from_form, template_name="objects_v33/adapters/tuya.html")


def register(app, core, manager) -> None:
    from .routes import bp
    from .services.config import load_config
    from .services.runtime import TuyaRuntime
    from .services.iot_realtime import TuyaIoTRealtime

    object_service = core.object_core_service
    if bp.name not in app.blueprints:
        app.register_blueprint(bp)

    try:
        object_service.SUPPORTED_ROUTE_PAIRS.update({
            ("tuya", "mqtt"), ("tuya", "loxone"), ("tuya", "knx"),
            ("tuya", "udp"), ("tuya", "influx"), ("tuya", "tuya"),
            ("mqtt", "tuya"), ("loxone", "tuya"), ("knx", "tuya"),
            ("udp", "tuya"), ("http", "tuya"), ("openccu", "tuya"),
            ("composite", "tuya"),
        })
    except Exception:
        app.logger.exception("MP-Tuya routing registration failed")

    def on_value(endpoint, value, timestamp, entry):
        object_service.record_live_value(
            "tuya", value, topic=endpoint, source_endpoint=endpoint,
            timestamp=timestamp, original_source="tuya", route_after_record=True,
        )

    runtime = TuyaRuntime(load_config, app.logger, on_value=on_value)
    app.extensions["tuya_runtime"] = runtime
    realtime = TuyaIoTRealtime(load_config, runtime, app.logger)
    app.extensions["tuya_iot_realtime"] = realtime

    def route_to_tuya(item, adapter, value, original_source, source_ref, route_entry, metadata):
        device_id = str(getattr(adapter, "device_id", "") or "").strip()
        dps = str(getattr(adapter, "dps", "") or "").strip()
        if not device_id or not dps:
            return False
        value_path = str(getattr(adapter, "target_value_path", "") or "").strip()
        target_value = value
        if value_path:
            try:
                target_value = core._target_value_or_skip(item, "tuya", value, value_path)
                if target_value is core._VALUE_PATH_MISSING:
                    return False
            except Exception:
                return False
        ok, message = runtime.write_value(device_id, dps, target_value)
        if not ok:
            core.add_log_entry(f"TUYA TX Fehler object_id={getattr(item, 'id', '')} endpoint={device_id}/{dps}: {message}")
        return ok

    if hasattr(core, "register_plugin_target_handler"):
        core.register_plugin_target_handler("tuya", route_to_tuya)

    runtime.start()
    realtime.start()

    cfg = load_config()
    cloud_cfg = dict(cfg.get("cloud") or {})
    if cloud_cfg.get("sync_on_start") and cloud_cfg.get("username") and cloud_cfg.get("password"):
        import threading
        def _cloud_start_sync():
            try:
                from .services.cloud import sync_devices
                from .services.config import save_config
                refreshed, report = sync_devices(load_config(), app.logger)
                save_config(refreshed)
                runtime.reload(refreshed)
                core.add_log_entry(
                    f"MP-Tuya Auto-Cloud-Sync: {report['cloud_devices']} Geräte, "
                    f"{report['added']} neu, {report['updated']} aktualisiert"
                )
            except Exception as exc:
                app.logger.warning("MP-Tuya Auto-Cloud-Sync fehlgeschlagen: %s", exc)
        threading.Thread(target=_cloud_start_sync, daemon=True, name="mp-tuya-cloud-sync").start()

    core.add_log_entry("MP-Tuya Plugin Runtime gestartet")
