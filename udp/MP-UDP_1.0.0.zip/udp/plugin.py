from __future__ import annotations
from dataclasses import dataclass, field
from typing import ClassVar, Any
from flask import Blueprint, current_app, redirect
from app.services.object_adapter_engine import BaseAdapter

bp=Blueprint("plugin_udp",__name__)

@dataclass
class UDPAdapter(BaseAdapter):
    protocol: ClassVar[str] = "udp"
    source_enabled: bool = False
    source_host: str = ""
    source_port: str = ""
    listen_port: str = ""
    source_payload_mode: str = "value"
    source_topic: str = ""
    source_json_path: str = ""
    target_enabled: bool = False
    target_host: str = ""
    target_ip: str = ""
    target_port: str = ""
    target_payload_mode: str = "topic_value"
    udp_topic: str = ""
    format: str = ""
    payload_mode: str = "topic_value"
    targets: list[dict[str, Any]] = field(default_factory=list)

    @classmethod
    def deserialize(cls, data: dict[str, Any]) -> "UDPAdapter":
        payload = dict(data or {})
        direction = str(payload.get("direction", "both") or "both").strip().lower()
        if "source_enabled" not in payload:
            payload["source_enabled"] = direction in {"in","both"} and any(str(payload.get(f,"") or "").strip() for f in ("listen_port","source_topic","source_json_path","source_host","source_port"))
        payload["source_payload_mode"] = str(payload.get("source_payload_mode") or payload.get("payload_mode") or "value")

        raw = payload.get("targets") if isinstance(payload.get("targets"), list) else []
        targets=[]
        for i,target in enumerate(raw):
            if not isinstance(target,dict): continue
            host=str(target.get("host") or target.get("target_host") or target.get("ip") or target.get("target_ip") or "").strip()
            port=str(target.get("port") or target.get("target_port") or "").strip()
            if not host or not port: continue
            targets.append({
                "id":str(target.get("id") or f"udp_target_{i+1}"), "enabled":bool(target.get("enabled",True)),
                "host":host, "port":port,
                "topic":str(target.get("topic") or target.get("udp_topic") or "").strip(),
                "payload_mode":str(target.get("payload_mode") or target.get("target_payload_mode") or "topic_value").strip() or "topic_value",
                "value_path":str(target.get("value_path") or target.get("target_value_path") or "").strip(),
            })
        legacy_host=str(payload.get("target_host") or payload.get("target_ip") or "").strip(); legacy_port=str(payload.get("target_port") or "").strip()
        if not targets and legacy_host and legacy_port and direction in {"out","both"}:
            targets.append({"id":"udp_target_1","enabled":bool(payload.get("target_enabled",True)),"host":legacy_host,"port":legacy_port,
                            "topic":str(payload.get("udp_topic") or payload.get("target_topic") or "").strip(),
                            "payload_mode":str(payload.get("target_payload_mode") or payload.get("payload_mode") or "topic_value").strip() or "topic_value",
                            "value_path":str(payload.get("target_value_path") or "").strip()})
        payload["targets"]=targets
        first=next((t for t in targets if t.get("enabled")), targets[0] if targets else None)
        if first:
            payload.update({"target_enabled":bool(first.get("enabled",True)),"target_host":first["host"],"target_ip":first["host"],"target_port":first["port"],
                            "udp_topic":first["topic"],"target_payload_mode":first["payload_mode"],"payload_mode":first["payload_mode"],"target_value_path":first["value_path"]})
        else:
            payload["target_enabled"]=False
        adapter=super().deserialize(payload)
        has_enabled_targets=any(bool(t.get("enabled")) for t in adapter.targets)
        adapter.enabled=bool(adapter.source_enabled or has_enabled_targets)
        adapter.direction="both" if adapter.source_enabled and has_enabled_targets else ("in" if adapter.source_enabled else "out")
        return adapter



def register_adapter():
    from app.services.object_adapter_engine import register_adapter as reg
    reg(UDPAdapter,template_name="objects_v33/adapters/udp.html")

def _core(): return current_app.extensions["app_core"]

@bp.route("/udp_input")
@bp.route("/udp_explorer")
@bp.route("/udp_monitor")
def explorer(): return _core().udp_explorer_page()
@bp.route("/udp_input/save",methods=["POST"])
def input_save(): return _core().udp_input_save()
@bp.route("/udp_input/test",methods=["POST"])
def input_test(): return _core().udp_input_test()
@bp.route("/udp_explorer/start",methods=["POST"])
def explorer_start(): return _core().udp_explorer_start()
@bp.route("/udp_explorer/stop",methods=["POST"])
def explorer_stop(): return _core().udp_explorer_stop()
@bp.route("/udp_input_data")
@bp.route("/udp_monitor_data")
def input_data(): return _core().udp_input_data()
@bp.route("/udp_monitor_clear",methods=["POST"])
def monitor_clear(): return _core().udp_monitor_clear()
@bp.route("/udp_discovery_status")
def discovery_status(): return _core().udp_discovery_status()
@bp.route("/udp_discovery_toggle",methods=["POST"])
def discovery_toggle(): return _core().udp_discovery_toggle()
@bp.route("/udp_presets")
def presets(): return _core().udp_presets()
@bp.route("/udp_presets/save",methods=["POST"])
def presets_save(): return _core().udp_presets_save()
@bp.route("/mqtt2udp")
@bp.route("/udp2mqtt")
def legacy_mapping(): return redirect("/objects_v33")

def register(app,core,manager):
    if bp.name not in app.blueprints: app.register_blueprint(bp)
